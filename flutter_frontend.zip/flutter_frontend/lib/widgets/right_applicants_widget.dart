import 'dart:io';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:open_file/open_file.dart';
import 'package:path/path.dart' as path;
import 'package:provider/provider.dart';
import 'package:term_project/providers/applicants_provider.dart';
import 'package:term_project/providers/feedback_provider.dart';
import 'package:term_project/providers/jobs_provider.dart';
import 'package:term_project/providers/portfolio_provider.dart';
import 'package:term_project/providers/posted_job_provider.dart';
import 'package:term_project/providers/shared_pref_profider.dart';
import 'package:term_project/screens/add_some_details_for_worker.dart';
import 'package:term_project/screens/signup_for_employee.dart';
import 'package:term_project/screens/view_all_experience.dart';
import 'package:term_project/screens/view_all_portfolio.dart';

class RightApplicantsWidget extends StatefulWidget {
  const RightApplicantsWidget({super.key, required this.title});
  final String title;

  @override
  State<RightApplicantsWidget> createState() => _RightApplicantsWidgetState();
}

class _RightApplicantsWidgetState extends State<RightApplicantsWidget> {
  List<dynamic>? applicants;
  List<Job>? postedJob;
  String? token;
  Job? job;

  @override
  void initState() {
    super.initState();
    token =
        Provider.of<SharedPreferencesProvider>(context, listen: false).token;
  }

  bool isInit = true;
  bool isLoading = false;
  bool isLoadingOne = false;

  @override
  void didChangeDependencies() async {
    super.didChangeDependencies();
    if (isInit) {
      setState(() {
        isLoading = true;
      });
      await Provider.of<PostedJobsProvider>(context, listen: false)
          .fetchData(token!)
          .then((value) => postedJob =
              Provider.of<PostedJobsProvider>(context, listen: false)
                  .postedJobList);

      isInit = false;
    }
    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return isLoading
        ? const Center(
            child: CircularProgressIndicator(),
          )
        : Column(
            children: [
              Expanded(
                child: Container(
                  width: 960,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  alignment: Alignment.center,
                  color: Colors.deepPurple.shade100,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        widget.title,
                        style:
                            const TextStyle(color: Colors.white, fontSize: 24),
                      ),
                      Container(
                        width: 300,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            border:
                                Border.all(color: Colors.deepPurple.shade500)),
                        child: DropdownButton<Job>(
                          focusColor: Colors.deepPurple.shade100,
                          borderRadius: BorderRadius.circular(10),
                          underline: const SizedBox(
                            height: 0,
                          ),
                          isExpanded: true,
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          icon: Icon(
                            Icons.arrow_forward_ios,
                            color: Colors.deepPurple.shade300,
                          ),
                          value: job,
                          hint: Text(
                            "Choose Job",
                            style: TextStyle(color: Colors.deepPurple.shade400),
                          ),
                          onChanged: (Job? value) {
                            setState(() {
                              job = value!;
                            });
                          },
                          items: postedJob!
                              .map<DropdownMenuItem<Job>>((Job value) {
                            return DropdownMenuItem<Job>(
                              onTap: () async {
                                setState(() {
                                  isLoadingOne = true;
                                });
                                await Provider.of<ApplicantsProvider>(context,
                                        listen: false)
                                    .fetchData(token!, value.id)
                                    .then((value) => applicants =
                                        Provider.of<ApplicantsProvider>(context,
                                                listen: false)
                                            .applicantList);
                                setState(() {
                                  isLoadingOne = false;
                                });
                              },
                              value: value,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    value.title!,
                                    style: TextStyle(
                                        color: Colors.deepPurple.shade400),
                                  ),
                                ],
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Expanded(
                flex: 11,
                child: applicants == null
                    ? const Center(child: Text("Select Vacancy"))
                    : isLoadingOne
                        ? const Center(
                            child: CircularProgressIndicator(),
                          )
                        : Column(
                            children: [
                              const Expanded(
                                  child: Text(
                                      "Click on Vacancy to see applicants")),
                              Expanded(
                                flex: 12,
                                child: ListView.builder(
                                  itemCount: applicants!.length,
                                  itemBuilder: (context, i) {
                                    return InkWell(
                                      onTap: () async {
                                        Provider.of<ApplicantsProvider>(context,
                                                listen: false)
                                            .getWorkerDetails(token!,
                                                applicants![i]["worker"]["id"])
                                            .then((value) =>
                                                showDialogForWorkerDetail(
                                                    Provider.of<ApplicantsProvider>(
                                                            context,
                                                            listen: false)
                                                        .data!,
                                                    applicants![i]["worker"]
                                                        ["id"]));
                                      },
                                      child: Container(
                                        margin: const EdgeInsets.symmetric(
                                            horizontal: 20, vertical: 10),
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 20, vertical: 10),
                                        height: 80,
                                        decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius:
                                                BorderRadius.circular(12),
                                            border: Border.all(
                                                color: Colors
                                                    .deepPurple.shade100)),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Expanded(
                                                flex: 2,
                                                child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceEvenly,
                                                  children: [
                                                    Row(
                                                      children: [
                                                        Text(
                                                          applicants![i]
                                                                  ["worker"]
                                                              ["full_name"],
                                                          style: const TextStyle(
                                                              fontSize: 24,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold),
                                                        ),
                                                        const SizedBox(
                                                            width: 5),
                                                        if (applicants![i]
                                                                ["status"] ==
                                                            "pending") ...{
                                                          status(Colors.grey)
                                                        } else if (applicants![
                                                                i]["status"] ==
                                                            "accepted") ...{
                                                          status(Colors
                                                              .green.shade400)
                                                        } else ...{
                                                          status(Colors
                                                              .red.shade400)
                                                        }
                                                      ],
                                                    ),
                                                  ],
                                                )),
                                            Expanded(
                                              flex: 3,
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.end,
                                                children: [
                                                  InkWell(
                                                    onTap: () async {
                                                      showDialogForScheduleInterview(
                                                          applicants![i]
                                                              ["worker"]["id"],
                                                          job!.id);
                                                    },
                                                    child: button("Schedule",
                                                        40, 120, 16),
                                                  ),
                                                  const SizedBox(width: 10),
                                                  InkWell(
                                                    onTap: () async {
                                                      acceptOrReject(
                                                          applicants![i]["id"],
                                                          "rejected",
                                                          applicants![i]);
                                                    },
                                                    child: button("Reject", 40,
                                                        120, 16, Colors.red),
                                                  ),
                                                  const SizedBox(width: 10),
                                                  InkWell(
                                                    onTap: () async {
                                                      acceptOrReject(
                                                          applicants![i]["id"],
                                                          "accepted",
                                                          applicants![i]);
                                                    },
                                                    child: button("Accept", 40,
                                                        120, 16, Colors.green),
                                                  ),
                                                  const SizedBox(width: 10),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ],
                          ),
              )
            ],
          );
  }

  acceptOrReject(int id, String status, Map<String, dynamic> applicants) async {
    await Provider.of<ApplicantsProvider>(context, listen: false)
        .acceptOrReject(token!, id, status)
        .then((value) {
      if (Provider.of<ApplicantsProvider>(context, listen: false).isError!) {
        showSnackBar(context, "Something went wrong");
      } else {
        setState(() {
          applicants["status"] = status;
        });
        showSnackBar(context, "Success", Colors.green.shade300);
      }
    });
  }

  Widget status(Color color) {
    return CircleAvatar(
      radius: 3,
      backgroundColor: color,
    );
  }

  showDialogForWorkerDetail(Map<String, dynamic> data, int id) async {
    File? file;

    await Provider.of<PortFolioProvider>(context, listen: false)
        .downloadFile(data["resume"])
        .then((value) {
      file = Provider.of<PortFolioProvider>(context, listen: false).file;
    }).then((value) {
      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            contentPadding: const EdgeInsets.all(0),
            content: Container(
              padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 10),
              alignment: Alignment.center,
              height: 600,
              width: 400,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          data["user"]["full_name"],
                          style: TextStyle(
                            color: Colors.deepPurple.shade400,
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 50),
                    richText("Username: ", data["user"]["username"]),
                    const SizedBox(height: 10),
                    richText("Description: ", data["description"]),
                    const SizedBox(height: 10),
                    richText("Region: ", data["region"]),
                    const SizedBox(height: 10),
                    richText("Phone Number: ", data["phone_number"]),
                    const SizedBox(height: 10),
                    richText("Telegram Account: ", data["telegram"]),
                    const SizedBox(height: 10),
                    richText("Native Language: ", data["native_language"]),
                    const SizedBox(height: 10),
                    richText("Status: ", data["status"]),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          "Resume: ",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        InkWell(
                          onTap: file == null
                              ? null
                              : () async {
                                  OpenFile.open(file!.path);
                                },
                          child: file == null
                              ? const Text("null")
                              : Text(path.basename(file!.path),
                                  style: const TextStyle(
                                      decoration: TextDecoration.underline,
                                      fontSize: 18)),
                        )
                      ],
                    ),
                    const SizedBox(height: 10),
                    richText(
                        "Birthdate: ",
                        DateFormat.yMMMd()
                            .format(DateTime.parse(data["birthdate"]))),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          "Employee Portfolios: ",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        IconButton(
                            onPressed: () {
                              Navigator.of(context).pushNamed(
                                  ViewAllPortfolioScreen.routeName,
                                  arguments: {
                                    "portfolio": data["portfoilo"],
                                    "name": data["user"]["full_name"]
                                  });
                            },
                            icon: const Icon(Icons.arrow_forward_ios))
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          "Employee Work Experience: ",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        IconButton(
                            onPressed: () {
                              Navigator.of(context).pushNamed(
                                  ViewAllExperience.routeName,
                                  arguments: {
                                    "experience": data["work_experience"],
                                    "name": data["user"]["full_name"]
                                  });
                            },
                            icon: const Icon(Icons.arrow_forward_ios))
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          "Languages: ",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        IconButton(
                            onPressed: () {
                              showDialogForLanguages(data["languages"]);
                            },
                            icon: const Icon(Icons.arrow_forward_ios))
                      ],
                    ),
                    const SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        InkWell(
                          onTap: () async {
                            showDialogForFeedBack(id);
                          },
                          child: button("Give Feedback"),
                        ),
                      ],
                    )
                  ],
                ),
              ),
            ),
          );
        },
      );
    });
  }

  void showDialogForScheduleInterview(int workerId, int jobId) {
    showDialog(
      context: context,
      builder: (context) {
        TextEditingController controller = TextEditingController();
        DateTime? date;
        return AlertDialog(
          contentPadding: const EdgeInsets.all(0),
          content: StatefulBuilder(
            builder: (context, setState) {
              return Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 40, horizontal: 10),
                alignment: Alignment.center,
                height: 250,
                width: 302,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextFormField(
                      validator: (value) {
                        if (value!.isEmpty) {
                          return "Please Fill Forms";
                        }

                        return null;
                      },
                      controller: controller,
                      decoration: InputDecoration(
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Colors.deepPurple.shade200,
                          ),
                          borderRadius: const BorderRadius.all(
                            Radius.circular(20),
                          ),
                        ),
                        border: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Colors.deepPurple.shade200,
                          ),
                          borderRadius: const BorderRadius.all(
                            Radius.circular(20),
                          ),
                        ),
                        label: Text(
                          'Link',
                          style: TextStyle(
                            color: Colors.deepPurple.shade200,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        date == null
                            ? const Text("Pick Date")
                            : Text(DateFormat.yMMMd().format(date!)),
                        InkWell(
                          onTap: () async {
                            DateTime? tempDate = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now(),
                                firstDate: DateTime.now(),
                                lastDate: DateTime(2025));
                            setState(() {
                              date = tempDate;
                            });
                          },
                          child: button(
                              "Pick Date", 40, 100, 12, Colors.deepPurple),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    InkWell(
                        onTap: () {
                          if (controller.text.isEmpty || date == null) {
                            showSnackBar(context, "Please Fill Forms");
                            return;
                          }
                          final data = {
                            "worker": workerId.toString(),
                            "vacancy": jobId.toString(),
                            "link": controller.text,
                            "date": date!.toString()
                          };
                          Provider.of<ApplicantsProvider>(context,
                                  listen: false)
                              .scheduleInterview(token!, data)
                              .then(
                            (value) {
                              if (Provider.of<ApplicantsProvider>(context,
                                      listen: false)
                                  .isError!) {
                                showSnackBar(context, "Something went wrong");
                              } else {
                                showSnackBar(
                                    context, "Success", Colors.green.shade300);
                              }
                            },
                          );
                        },
                        child: button("Schedule", 50, 100, 16))
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }

  Widget richText(String text, String text2) {
    return RichText(
      text: TextSpan(
        text: text,
        style: const TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            fontFamily: "Montserrat"),
        children: [
          TextSpan(
            text: text2,
            style: const TextStyle(
              color: Colors.black,
              fontWeight: FontWeight.normal,
            ),
          )
        ],
      ),
    );
  }

  showDialogForLanguages(List? languageceData) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: Theme.of(context).colorScheme.background,
          contentPadding: const EdgeInsets.all(0),
          content: Container(
            width: 400,
            height: 600,
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
            child: Column(
              children: [
                Expanded(
                  flex: 5,
                  child: ListView.builder(
                    itemCount: languageceData!.length,
                    itemBuilder: (context, index) {
                      return Container(
                        height: 80,
                        margin: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                            color: Colors.deepPurple.shade100,
                            borderRadius: BorderRadius.circular(20)),
                        child: Row(
                          children: [
                            Expanded(
                              flex: 3,
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  Text(
                                    languageceData[index]["language"],
                                    style: TextStyle(
                                        color: Colors.deepPurple.shade400,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 24),
                                  ),
                                  Text(
                                    languageceData[index]["level"],
                                    style: TextStyle(
                                        color: Colors.deepPurple.shade300,
                                        fontWeight: FontWeight.normal,
                                        fontSize: 18),
                                  )
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  showDialogForFeedBack(int id) {
    showDialog(
      context: context,
      builder: (context) {
        TextEditingController controller = TextEditingController();
        int? rank;
        return AlertDialog(
          contentPadding: const EdgeInsets.all(0),
          content: StatefulBuilder(
            builder: (context, setState) {
              return Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 40, horizontal: 10),
                alignment: Alignment.center,
                height: 250,
                width: 302,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextFormField(
                      validator: (value) {
                        if (value!.isEmpty) {
                          return "Please Fill Forms";
                        }

                        return null;
                      },
                      controller: controller,
                      decoration: InputDecoration(
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Colors.deepPurple.shade200,
                          ),
                          borderRadius: const BorderRadius.all(
                            Radius.circular(20),
                          ),
                        ),
                        border: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Colors.deepPurple.shade200,
                          ),
                          borderRadius: const BorderRadius.all(
                            Radius.circular(20),
                          ),
                        ),
                        label: Text(
                          'Feedback',
                          style: TextStyle(
                            color: Colors.deepPurple.shade200,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        for (int i = 1; i <= 5; i++) ...{
                          InkWell(
                            onTap: () {
                              setState(() {
                                rank = i;
                              });
                            },
                            child: button(
                                i.toString(),
                                20,
                                20,
                                12,
                                rank == i
                                    ? Colors.green.shade300
                                    : Colors.deepPurple.shade300),
                          ),
                        }
                      ],
                    ),
                    const SizedBox(height: 10),
                    InkWell(
                      onTap: () async {
                        if (controller.text.isEmpty || rank == null) {
                          showSnackBar(context, "Please Fill Forms");
                          return;
                        }
                        final data = {
                          "worker": id.toString(),
                          "text": controller.text,
                          "rating": rank!.toString()
                        };
                        await Provider.of<FeedbackProvider>(context,
                                listen: false)
                            .addFeedbackForWorker(data, token!)
                            .then((value) {
                          if (Provider.of<FeedbackProvider>(context,
                                  listen: false)
                              .isError!) {
                            String? msg = Provider.of<FeedbackProvider>(context,
                                    listen: false)
                                .msg;
                            if (msg != null) {
                              showSnackBar(context, msg);
                            } else {
                              showSnackBar(context, "Something went wrong");
                            }
                          } else {
                            showSnackBar(
                                context, "Success", Colors.green.shade300);
                          }
                        });
                      },
                      child: button("Submit"),
                    )
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }
}
