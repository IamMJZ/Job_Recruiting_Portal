import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:term_project/main.dart';
import 'package:term_project/providers/applicants_provider.dart';
import 'package:term_project/providers/interviews_provider.dart';
import 'package:term_project/providers/shared_pref_profider.dart';
import 'package:term_project/screens/add_some_details_for_worker.dart';
import 'package:term_project/screens/signup_for_employee.dart';
import 'package:url_launcher/url_launcher.dart';

class InterviewsScreen extends StatefulWidget {
  static const routeName = "/interviews-screen";
  const InterviewsScreen({super.key});

  @override
  State<InterviewsScreen> createState() => _InterviewsScreenState();
}

class _InterviewsScreenState extends State<InterviewsScreen> {
  List<dynamic>? data;

  String? token;
  UserType? userType;

  @override
  void initState() {
    super.initState();
    token =
        Provider.of<SharedPreferencesProvider>(context, listen: false).token;
    userType =
        Provider.of<SharedPreferencesProvider>(context, listen: false).userType;
  }

  bool? isLoading = false;
  bool? isInit = true;

  @override
  void didChangeDependencies() async {
    super.didChangeDependencies();
    if (isInit!) {
      setState(() {
        isLoading = true;
      });
      if (userType == UserType.employee) {
        await Provider.of<InterviewProvider>(context, listen: false)
            .fetchData(token!)
            .then(
              (value) => data =
                  Provider.of<InterviewProvider>(context, listen: false).data,
            );
      } else {
        await Provider.of<InterviewProvider>(context, listen: false)
            .fetchDataForEmployer(token!)
            .then((value) => data =
                Provider.of<InterviewProvider>(context, listen: false).data);
      }

      setState(() {
        isLoading = false;
      });
    }
    setState(() {
      isInit = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        width: 1200,
        height: 800,
        child: Column(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      style: const ButtonStyle(
                          overlayColor:
                              MaterialStatePropertyAll(Colors.transparent)),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: Icon(
                        Icons.arrow_back_ios,
                        color: Colors.deepPurple.shade300,
                      ),
                    ),
                    Text(
                      "Interviews",
                      style: TextStyle(
                        color: Colors.deepPurple.shade400,
                        fontSize: 24,
                      ),
                    ),
                    const SizedBox()
                  ],
                ),
              ),
            ),
            Expanded(
              flex: 11,
              child: isLoading!
                  ? const Center(
                      child: CircularProgressIndicator(),
                    )
                  : Container(
                      alignment: Alignment.center,
                      child: SizedBox(
                        width: 500,
                        child: ListView.builder(
                          itemCount: data!.length,
                          itemBuilder: (context, index) {
                            return InkWell(
                              onTap: userType == UserType.employer
                                  ? () {
                                      showDialog(
                                        context: context,
                                        builder: (context) {
                                          TextEditingController controller =
                                              TextEditingController(
                                                  text: data!.firstWhere(
                                                      (element) =>
                                                          element["id"] ==
                                                          data![index]
                                                              ["id"])["link"]);
                                          DateTime? date = DateTime.parse(data!
                                              .firstWhere((element) =>
                                                  element["id"] ==
                                                  data![index]["id"])["date"]);
                                          return AlertDialog(
                                              contentPadding:
                                                  const EdgeInsets.all(0),
                                              content: Container(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        vertical: 40,
                                                        horizontal: 10),
                                                alignment: Alignment.center,
                                                height: 250,
                                                width: 302,
                                                child: Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    TextFormField(
                                                      validator: (value) {
                                                        if (value!.isEmpty) {
                                                          return "Please Fill Forms";
                                                        }

                                                        return null;
                                                      },
                                                      controller: controller,
                                                      decoration:
                                                          InputDecoration(
                                                        floatingLabelBehavior:
                                                            FloatingLabelBehavior
                                                                .never,
                                                        enabledBorder:
                                                            OutlineInputBorder(
                                                          borderSide:
                                                              BorderSide(
                                                            color: Colors
                                                                .deepPurple
                                                                .shade200,
                                                          ),
                                                          borderRadius:
                                                              const BorderRadius
                                                                  .all(
                                                            Radius.circular(20),
                                                          ),
                                                        ),
                                                        border:
                                                            OutlineInputBorder(
                                                          borderSide:
                                                              BorderSide(
                                                            color: Colors
                                                                .deepPurple
                                                                .shade200,
                                                          ),
                                                          borderRadius:
                                                              const BorderRadius
                                                                  .all(
                                                            Radius.circular(20),
                                                          ),
                                                        ),
                                                        label: Text(
                                                          'Link',
                                                          style: TextStyle(
                                                            color: Colors
                                                                .deepPurple
                                                                .shade200,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    const SizedBox(height: 10),
                                                    Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      children: [
                                                        Text(DateFormat.yMMMd()
                                                            .format(date)),
                                                        InkWell(
                                                          onTap: () async {
                                                            DateTime? tempDate =
                                                                await showDatePicker(
                                                                    context:
                                                                        context,
                                                                    initialDate:
                                                                        DateTime
                                                                            .now(),
                                                                    firstDate:
                                                                        DateTime
                                                                            .now(),
                                                                    lastDate:
                                                                        DateTime(
                                                                            2025));
                                                            setState(() {
                                                              date = tempDate;
                                                            });
                                                          },
                                                          child: button(
                                                              "Pick Date",
                                                              40,
                                                              100,
                                                              12,
                                                              Colors
                                                                  .deepPurple),
                                                        ),
                                                      ],
                                                    ),
                                                    const SizedBox(height: 10),
                                                    InkWell(
                                                        onTap: () {
                                                          if (controller.text
                                                                  .isEmpty ||
                                                              date == null) {
                                                            showSnackBar(
                                                                context,
                                                                "Please Fill Forms");
                                                            return;
                                                          }
                                                          final dataOne = {
                                                            "worker": data![index]
                                                                        [
                                                                        "worker"]
                                                                    ["id"]
                                                                .toString(),
                                                            "vacancy": data![
                                                                        index][
                                                                    "vacancy"]["id"]
                                                                .toString(),
                                                            "link":
                                                                controller.text,
                                                            "date":
                                                                date!.toString()
                                                          };
                                                          Provider.of<ApplicantsProvider>(
                                                                  context,
                                                                  listen: false)
                                                              .updateInterviews(
                                                                  token!,
                                                                  data![index]
                                                                      ["id"],
                                                                  dataOne)
                                                              .then(
                                                            (value) {
                                                              if (Provider.of<
                                                                          ApplicantsProvider>(
                                                                      context,
                                                                      listen:
                                                                          false)
                                                                  .isError!) {
                                                                showSnackBar(
                                                                    context,
                                                                    "Something went wrong");
                                                              } else {
                                                                setState(() {
                                                                  data!.firstWhere((element) =>
                                                                      element[
                                                                          "id"] ==
                                                                      data![index]
                                                                          [
                                                                          "id"])["link"] = controller
                                                                      .text;
                                                                  data!.firstWhere((element) =>
                                                                      element[
                                                                          "id"] ==
                                                                      data![index]
                                                                          [
                                                                          "id"])["date"] = date!
                                                                      .toString();
                                                                });
                                                                showSnackBar(
                                                                    context,
                                                                    "Success",
                                                                    Colors.green
                                                                        .shade300);
                                                                Navigator.of(
                                                                        context)
                                                                    .pop();
                                                              }
                                                            },
                                                          );
                                                        },
                                                        child: button(
                                                            "Schedule",
                                                            50,
                                                            100,
                                                            16))
                                                  ],
                                                ),
                                              ));
                                        },
                                      );
                                    }
                                  : null,
                              child: Container(
                                height: 120,
                                padding: const EdgeInsets.all(10),
                                margin: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                    color: Colors.deepPurple.shade50,
                                    border: Border.all(
                                        color: Colors.deepPurple.shade400),
                                    borderRadius: BorderRadius.circular(15)),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      data![index]["vacancy"]['title'],
                                      style: TextStyle(
                                          color: Colors.deepPurple.shade400,
                                          fontSize: 20),
                                    ),
                                    if (userType == UserType.employee)
                                      Text(
                                        data![index]["vacancy"]["company"]
                                            ["title"],
                                        style: TextStyle(
                                            color: Colors.deepPurple.shade200,
                                            fontSize: 14),
                                      ),
                                    if (userType == UserType.employer)
                                      Text(
                                        data![index]["worker"]["full_name"],
                                        style: TextStyle(
                                            color: Colors.deepPurple.shade200,
                                            fontSize: 14),
                                      ),
                                    Text(
                                        DateFormat.yMMMd().format(
                                            DateTime.parse(
                                                data![index]["date"])),
                                        style: TextStyle(
                                            color: Colors.deepPurple.shade200,
                                            fontSize: 14)),
                                    InkWell(
                                      onTap: () async {
                                        final url =
                                            Uri.parse(data![index]["link"]);
                                        if (!await launchUrl(url,
                                            mode: LaunchMode
                                                .externalApplication)) {
                                          throw Exception(
                                              'Could not launch $url');
                                        }
                                      },
                                      child: Text(data![index]["link"],
                                          style: TextStyle(
                                              color: Colors.deepPurple.shade400,
                                              fontSize: 14,
                                              decoration:
                                                  TextDecoration.underline)),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ),
            )
          ],
        ),
      ),
    );
  }

  void showDialogForScheduleInterview(
      int workerId, int jobId, int interviewId, List<dynamic> list) {}
}
