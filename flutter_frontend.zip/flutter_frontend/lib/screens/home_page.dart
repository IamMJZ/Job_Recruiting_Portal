import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:term_project/main.dart';
import 'package:term_project/providers/notifications_provider.dart';
import 'package:term_project/providers/shared_pref_profider.dart';
import 'package:term_project/providers/sign_up_provider.dart';
import 'package:term_project/screens/add_some_details_for_worker.dart';
import 'package:term_project/screens/create_job.dart';
import 'package:term_project/screens/sign_up_page.dart';
import 'package:term_project/screens/signup_for_employee.dart';
import 'package:term_project/widgets/chat_right_widget.dart';
import 'package:term_project/widgets/notification_right_widget.dart';
import 'package:term_project/widgets/right_applicants_widget.dart';
import 'package:term_project/widgets/right_home_widget.dart';
import 'package:term_project/widgets/right_posted_jobs_widget.dart';
import 'package:term_project/widgets/right_profile_widget.dart';
import 'package:term_project/widgets/right_applied_jobs_widget.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final Future<SharedPreferences> _prefs = SharedPreferences.getInstance();

  PageName? page;
  bool? isLoading = false;
  bool? auth;
  UserType? userType;
  int notificationSize = 0;

  @override
  void initState() {
    super.initState();
    setState(() {
      isLoading = true;
    });
    Future.delayed(
        const Duration(
          milliseconds: 0,
        ), () async {
      await Provider.of<SharedPreferencesProvider>(context, listen: false)
          .fetchData()
          .then((value) {
        page = Pages(
                name: Provider.of<SharedPreferencesProvider>(context,
                        listen: false)
                    .pageName!)
            .page;
        auth =
            Provider.of<SharedPreferencesProvider>(context, listen: false).auth;
        userType =
            Provider.of<SharedPreferencesProvider>(context, listen: false)
                .userType;
      }).then((value) async {
        String? token =
            Provider.of<SharedPreferencesProvider>(context, listen: false)
                .token;
        if (token != null) {
          await Provider.of<NotificationProvider>(context, listen: false)
              .getData(token)
              .then((value) => notificationSize =
                  Provider.of<NotificationProvider>(context, listen: false)
                      .data!
                      .length);
        }
      });
    }).then((value) {
      setState(() {
        isLoading = false;
      });
    });
  }

  void setPage(PageName page) async {
    setState(() {
      this.page = page;
    });
    final SharedPreferences prefs = await _prefs;
    prefs.setString("page", page.name);
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        return false;
      },
      child: Scaffold(
        body: isLoading!
            ? const Center(child: CircularProgressIndicator())
            : SizedBox(
                height: 800,
                child: Row(
                  children: [
                    Expanded(
                      flex: 2,
                      child: Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.deepPurple.shade50,
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                if (userType == UserType.employee) ...{
                                  InkWell(
                                    onTap: () {
                                      setPage(PageName.home);
                                    },
                                    child: containerForMenuBar("Home"),
                                  ),
                                  if (auth!) ...{
                                    const SizedBox(height: 10),
                                    InkWell(
                                      onTap: () {
                                        setPage(PageName.appliedJobs);
                                      },
                                      child:
                                          containerForMenuBar("Applied Jobs"),
                                    ),
                                  }
                                },
                                if (userType == UserType.employer) ...{
                                  InkWell(
                                    onTap: () {
                                      setPage(PageName.applicants);
                                    },
                                    child: containerForMenuBar("Applicants"),
                                  ),
                                  const SizedBox(height: 10),
                                  InkWell(
                                    onTap: () {
                                      setPage(PageName.postedJobs);
                                    },
                                    child: containerForMenuBar("Posted Jobs"),
                                  ),
                                  const SizedBox(height: 9.9),
                                  InkWell(
                                    onTap: () {
                                      Navigator.of(context)
                                          .pushNamed(CreateJob.routeName);
                                    },
                                    child:
                                        containerForMenuBar("Create Vacancy"),
                                  )
                                },
                                const SizedBox(height: 10),
                                InkWell(
                                  onTap: () {
                                    setPage(PageName.profile);
                                  },
                                  child: containerForMenuBar("Profile"),
                                ),
                                const SizedBox(height: 10),
                                InkWell(
                                  onTap: () {
                                    setPage(PageName.notifications);
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.all(10),
                                    height: 50,
                                    width: 200,
                                    decoration: BoxDecoration(
                                      boxShadow: [
                                        BoxShadow(
                                            color: Colors.grey.shade400,
                                            offset: const Offset(0, 5),
                                            blurRadius: 10)
                                      ],
                                      borderRadius: BorderRadius.circular(15),
                                      color: Colors.deepPurple.shade100,
                                    ),
                                    alignment: Alignment.centerLeft,
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        const Text(
                                          "Notifications",
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 20,
                                          ),
                                        ),
                                        if (auth!) ...{
                                          Container(
                                            alignment: Alignment.center,
                                            height: 20,
                                            width: 20,
                                            decoration: BoxDecoration(
                                                boxShadow: [
                                                  BoxShadow(
                                                      color:
                                                          Colors.grey.shade500,
                                                      offset:
                                                          const Offset(3, 1),
                                                      blurRadius: 5),
                                                  BoxShadow(
                                                      color:
                                                          Colors.grey.shade500,
                                                      offset:
                                                          const Offset(-3, 1),
                                                      blurRadius: 5)
                                                ],
                                                color:
                                                    Colors.deepPurple.shade200,
                                                borderRadius:
                                                    BorderRadius.circular(6)),
                                            child: Text(
                                              notificationSize.toString(),
                                              style: const TextStyle(
                                                  fontSize: 10,
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          )
                                        }
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Column(
                              children: [
                                if (auth!) ...{
                                  TextButton(
                                    style: const ButtonStyle(
                                        overlayColor: MaterialStatePropertyAll(
                                            Colors.transparent)),
                                    onPressed: () {
                                      showDialog(
                                          context: context,
                                          builder: (context) {
                                            return AlertDialog(
                                              content: Container(
                                                width: 200,
                                                height: 160,
                                                alignment: Alignment.center,
                                                child: const Text(
                                                  "Are You Sure?",
                                                  style:
                                                      TextStyle(fontSize: 20),
                                                ),
                                              ),
                                              actions: [
                                                TextButton(
                                                    style: const ButtonStyle(
                                                        overlayColor:
                                                            MaterialStatePropertyAll(
                                                                Colors
                                                                    .transparent)),
                                                    onPressed: () {
                                                      Navigator.of(context)
                                                          .pop();
                                                    },
                                                    child: const Text("Cancel",
                                                        style: TextStyle(
                                                            decoration:
                                                                TextDecoration
                                                                    .underline))),
                                                TextButton(
                                                    style: const ButtonStyle(
                                                        overlayColor:
                                                            MaterialStatePropertyAll(
                                                                Colors
                                                                    .transparent)),
                                                    onPressed: () async {
                                                      setState(() {
                                                        auth = false;
                                                      });

                                                      await SharedPreferences
                                                              .getInstance()
                                                          .then((value) {
                                                        value.remove("auth");
                                                        value
                                                            .remove("userType");
                                                        value.remove("token");
                                                        value.setString(
                                                            "page", "profile");
                                                        Navigator.of(context)
                                                            .pushNamed("/");
                                                      });
                                                    },
                                                    child: const Text(
                                                      "Yes",
                                                      style: TextStyle(
                                                          decoration:
                                                              TextDecoration
                                                                  .underline),
                                                    ))
                                              ],
                                            );
                                          });
                                    },
                                    child: const Text(
                                      "Log Out",
                                      style: TextStyle(
                                          fontSize: 18,
                                          decoration: TextDecoration.underline),
                                    ),
                                  ),
                                },
                                if (!auth!)
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      TextButton(
                                        style: const ButtonStyle(
                                            overlayColor:
                                                MaterialStatePropertyAll(
                                                    Colors.transparent)),
                                        onPressed: () async {
                                          showDialogForLogin(context);
                                          final pref = await SharedPreferences
                                              .getInstance();
                                          pref.remove("userType");
                                        },
                                        child: const Text(
                                          "Sign Up",
                                          style: TextStyle(
                                              fontSize: 18,
                                              decoration:
                                                  TextDecoration.underline),
                                        ),
                                      ),
                                      
                                    ],
                                  ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 8,
                      child: Container(
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.background,
                        ),
                        child: rightContainerBody(page!),
                      ),
                    ),
                  ],
                ),
              ),
      ),
    );
  }

  Widget containerForMenuBar(String name) {
    return Container(
      padding: const EdgeInsets.all(10),
      height: 50,
      width: 200,
      decoration: BoxDecoration(
        boxShadow: [
          BoxShadow(
              color: Colors.grey.shade400,
              offset: const Offset(0, 5),
              blurRadius: 10)
        ],
        borderRadius: BorderRadius.circular(15),
        color: Colors.deepPurple.shade100,
      ),
      alignment: Alignment.centerLeft,
      child: Text(
        name,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 20,
        ),
      ),
    );
  }

  Widget rightContainerBody(PageName pageName) {
    return pageName == PageName.home
        ? const RightHomeWidget(title: "Home")
        : pageName == PageName.profile
            ? const RightProfileWidget(title: "Profile")
            : pageName == PageName.applicants
                ? const RightApplicantsWidget(title: "Applicants")
                : pageName == PageName.postedJobs
                    ? const RightPostedJobsWidget(title: "Posted Jobs")
                    : pageName == PageName.notifications
                        ? const NotificationRightWidget(title: "Notifications")
                        : pageName == PageName.chat
                            ? const ChatRightWidget(title: "Chat")
                            : const RightAppliedJobsWidget(
                                title: "Applied Jobs");
  }
}

void showDialogForLogin(BuildContext context) {
  showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        contentPadding: const EdgeInsets.all(0),
        content: Container(
          padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 10),
          alignment: Alignment.center,
          height: 240,
          width: 302,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              TextButton(
                  style: const ButtonStyle(
                      overlayColor:
                          MaterialStatePropertyAll(Colors.transparent)),
                  onPressed: () {
                    Navigator.of(context).pushNamed(SignUpPage.routeName);
                  },
                  child: const Text(
                    "Sign Up",
                    style: TextStyle(
                        decoration: TextDecoration.underline, fontSize: 18),
                  )),
              TextButton(
                  style: const ButtonStyle(
                      overlayColor:
                          MaterialStatePropertyAll(Colors.transparent)),
                  onPressed: () {
                    login(context);
                  },
                  child: const Text(
                    "Log In",
                    style: TextStyle(
                        decoration: TextDecoration.underline, fontSize: 18),
                  ))
            ],
          ),
        ),
      );
    },
  );
}

Widget containerForLogIn(String text) {
  return Container(
    width: 260,
    height: 75,
    alignment: Alignment.center,
    decoration: BoxDecoration(
        color: Colors.deepPurple.shade100,
        borderRadius: BorderRadius.circular(30)),
    child: Text(
      text,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 24,
      ),
    ),
  );
}

void login(BuildContext context) {
  final key = GlobalKey<FormState>();
  TextEditingController usernameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  FocusNode passwordNode = FocusNode();

  Navigator.of(context).pop();
  showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        backgroundColor: Colors.deepPurple.shade100,
        contentPadding: const EdgeInsets.all(0),
        content: Container(
          width: 300,
          height: 242,
          alignment: Alignment.center,
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Form(
                key: key,
                child: Column(
                  children: [
                    TextFormField(
                      validator: (value) {
                        if (value!.isEmpty) {
                          return "Please Fill Forms";
                        }
                        if (!value.contains("@")) {
                          return "Please, enter your valid email";
                        }
                        return null;
                      },
                      controller: usernameController,
                      decoration: const InputDecoration(
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.white),
                            borderRadius:
                                BorderRadius.all(Radius.circular(20))),
                        border: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.white),
                            borderRadius:
                                BorderRadius.all(Radius.circular(20))),
                        label: Text(
                          'Email',
                          style: TextStyle(
                            color: Colors.white,
                          ),
                        ),
                      ),
                      onFieldSubmitted: (value) {
                        FocusScope.of(context).requestFocus(passwordNode);
                      },
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      validator: (value) {
                        if (value!.isEmpty) {
                          return "Please Fill Forms";
                        }
                        return null;
                      },
                      controller: passwordController,
                      obscureText: true,
                      focusNode: passwordNode,
                      decoration: const InputDecoration(
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.white),
                            borderRadius:
                                BorderRadius.all(Radius.circular(20))),
                        border: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.white),
                            borderRadius:
                                BorderRadius.all(Radius.circular(20))),
                        label: Text(
                          'Password',
                          style: TextStyle(
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              InkWell(
                  onTap: () async {
                    showDialogForSendCode(context);
                  },
                  child: Text(
                    "reset Password",
                    style: TextStyle(
                        color: Colors.deepPurple.shade300,
                        decoration: TextDecoration.underline,
                        fontSize: 14),
                  )),
              TextButton(
                style: const ButtonStyle(
                  overlayColor: MaterialStatePropertyAll(Colors.transparent),
                ),
                onPressed: () async {
                  if (!key.currentState!.validate()) {
                    return;
                  }
                  Map<String, dynamic> data = {
                    "email": usernameController.text,
                    "password": passwordController.text
                  };
                  await Provider.of<SignUpProvider>(context, listen: false)
                      .login(data)
                      .then((value) async {
                    if (Provider.of<SignUpProvider>(context, listen: false)
                        .isError!) {
                      if (Provider.of<SignUpProvider>(context, listen: false)
                              .message ==
                          null) {
                        showSnackBar(context, "Something went wrong");
                      } else {
                        showSnackBar(
                            context,
                            Provider.of<SignUpProvider>(context, listen: false)
                                .message!);
                      }
                    } else {
                      Navigator.of(context).pop();
                      SharedPreferences prefs =
                          await SharedPreferences.getInstance();
                      prefs.setBool("auth", true).then(
                          (value) => Navigator.of(context).pushNamed("/"));
                    }
                  });
                },
                child: const Text(
                  "Login",
                  style: TextStyle(
                      decoration: TextDecoration.underline, fontSize: 20),
                ),
              )
            ],
          ),
        ),
      );
    },
  );
}

void showDialogForSendCode(BuildContext context) {
  showDialog(
    context: context,
    builder: (context) {
      TextEditingController textEditingController = TextEditingController();
      return AlertDialog(
          backgroundColor: Colors.deepPurple.shade100,
          contentPadding: const EdgeInsets.all(0),
          content: Container(
              width: 300,
              height: 242,
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
              child: Column(
                children: [
                  TextFormField(
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Please Fill Forms";
                      }
                      return null;
                    },
                    controller: textEditingController,
                    decoration: const InputDecoration(
                      floatingLabelBehavior: FloatingLabelBehavior.never,
                      enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                          borderRadius: BorderRadius.all(Radius.circular(20))),
                      border: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                          borderRadius: BorderRadius.all(Radius.circular(20))),
                      label: Text(
                        'Email',
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  InkWell(
                      onTap: () async {
                        if (textEditingController.text.isEmpty) {
                          showSnackBar(context, "Please, fill form");
                          return;
                        }
                        await Provider.of<SignUpProvider>(context,
                                listen: false)
                            .send(textEditingController.text)
                            .then((value) {
                          if (Provider.of<SignUpProvider>(context,
                                  listen: false)
                              .isError!) {
                            if (Provider.of<SignUpProvider>(context,
                                        listen: false)
                                    .message ==
                                null) {
                              showSnackBar(context, "Something went wrong");
                            } else {
                              showSnackBar(
                                  context,
                                  Provider.of<SignUpProvider>(context,
                                          listen: false)
                                      .message!);
                            }
                          } else {
                            Navigator.of(context).pop();
                            showDialogForResetPassword(
                                context,
                                Provider.of<SignUpProvider>(context,
                                        listen: false)
                                    .data!);
                          }
                        });
                      },
                      child: button("Send code"))
                ],
              )));
    },
  );
}

void showDialogForResetPassword(
    BuildContext context, Map<String, dynamic> data) {
  showDialog(
    context: context,
    builder: (context) {
      TextEditingController textEditingController = TextEditingController();
      return AlertDialog(
          backgroundColor: Colors.deepPurple.shade100,
          contentPadding: const EdgeInsets.all(0),
          content: Container(
              width: 300,
              height: 242,
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
              child: Column(
                children: [
                  TextFormField(
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Please Fill Forms";
                      }
                      return null;
                    },
                    controller: textEditingController,
                    decoration: const InputDecoration(
                      floatingLabelBehavior: FloatingLabelBehavior.never,
                      enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                          borderRadius: BorderRadius.all(Radius.circular(20))),
                      border: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                          borderRadius: BorderRadius.all(Radius.circular(20))),
                      label: Text(
                        'Code',
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  InkWell(
                      onTap: () async {
                        if (textEditingController.text.isEmpty) {
                          showSnackBar(context, "Please, fill form");
                          return;
                        }
                        await Provider.of<SignUpProvider>(context,
                                listen: false)
                            .submitCode(data, textEditingController.text)
                            .then((value) {
                          if (Provider.of<SignUpProvider>(context,
                                  listen: false)
                              .isError!) {
                            if (Provider.of<SignUpProvider>(context,
                                        listen: false)
                                    .message ==
                                null) {
                              showSnackBar(context, "Something went wrong");
                            } else {
                              showSnackBar(
                                  context,
                                  Provider.of<SignUpProvider>(context,
                                          listen: false)
                                      .message!);
                            }
                          } else {
                            Navigator.of(context).pop();
                            showDialogForRecoverPassword(
                                context,
                                Provider.of<SignUpProvider>(context,
                                        listen: false)
                                    .data);
                          }
                        });
                      },
                      child: button("Enter code"))
                ],
              )));
    },
  );
}

void showDialogForRecoverPassword(
    BuildContext context, Map<String, dynamic>? data) {
  showDialog(
    context: context,
    builder: (context) {
      TextEditingController textEditingController = TextEditingController();
      return AlertDialog(
          backgroundColor: Colors.deepPurple.shade100,
          contentPadding: const EdgeInsets.all(0),
          content: Container(
              width: 300,
              height: 242,
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
              child: Column(
                children: [
                  TextFormField(
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Please Fill Forms";
                      }
                      return null;
                    },
                    controller: textEditingController,
                    obscureText: true,
                    decoration: const InputDecoration(
                      floatingLabelBehavior: FloatingLabelBehavior.never,
                      enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                          borderRadius: BorderRadius.all(Radius.circular(20))),
                      border: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                          borderRadius: BorderRadius.all(Radius.circular(20))),
                      label: Text(
                        'Password',
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  InkWell(
                      onTap: () async {
                        if (textEditingController.text.isEmpty) {
                          showSnackBar(context, "Please, fill form");
                          return;
                        }
                        await Provider.of<SignUpProvider>(context,
                                listen: false)
                            .recoverPassword(data!, textEditingController.text)
                            .then((value) {
                          if (Provider.of<SignUpProvider>(context,
                                  listen: false)
                              .isError!) {
                            if (Provider.of<SignUpProvider>(context,
                                        listen: false)
                                    .message ==
                                null) {
                              showSnackBar(context, "Something went wrong");
                            } else {
                              showSnackBar(
                                  context,
                                  Provider.of<SignUpProvider>(context,
                                          listen: false)
                                      .message!);
                            }
                          } else {
                            Navigator.of(context).pop();
                          }
                        });
                      },
                      child: button("Change Password"))
                ],
              )));
    },
  );
}
