import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:term_project/providers/profile_provider.dart';
import 'package:term_project/providers/shared_pref_profider.dart';
import 'package:term_project/screens/jobs_full_details.dart';
import 'package:term_project/screens/signup_for_employee.dart';

import '../providers/jobs_provider.dart';

class RightHomeWidget extends StatefulWidget {
  const RightHomeWidget({super.key, required this.title});
  final String title;

  @override
  State<RightHomeWidget> createState() => _RightHomeWidgetState();
}

class _RightHomeWidgetState extends State<RightHomeWidget> {
  List<Job>? jobList;
  List<Category>? list;
  final searchController = TextEditingController();

  bool isLoading = false;
  String? token;

  @override
  void initState() {
    super.initState();
    setState(() {
      isLoading = true;
    });
    Future.delayed(Duration.zero, () async {
      try {
        token = Provider.of<SharedPreferencesProvider>(context, listen: false)
            .token;
        await Provider.of<JobsProvider>(context, listen: false)
            .getAllCategories()
            .then((value) async {
          list = Provider.of<JobsProvider>(context, listen: false).categoryList;
          await Provider.of<JobsProvider>(context, listen: false)
              .fetchData()
              .then((value) async =>
                  await Provider.of<SharedPreferencesProvider>(context,
                          listen: false)
                      .fetchData())
              .then((value) async {
            jobList = Provider.of<JobsProvider>(context, listen: false).jobList;
            if (token != null) {
              await Provider.of<ProfileProvider>(context, listen: false)
                  .getWorkerPage(token!)
                  .then((value) {
                List<dynamic>? savedJobs =
                    Provider.of<ProfileProvider>(context, listen: false)
                        .workerData!["saved_jobs"];
                jobList!.map((e) {
                  for (var element in savedJobs!) {
                    if (e.id == element["id"]) {
                      e.isFavorite = true;
                      break;
                    } else {
                      e.isFavorite = false;
                    }
                  }
                }).toList();
              });
            }
          });
        });
      } finally {
        list!.add(Category("Default", "", 0));
      }
      setState(() {
        isLoading = false;
      });
    });
  }

  Category? dropdownValue;

  @override
  Widget build(BuildContext context) {
    return isLoading
        ? const Center(
            child: CircularProgressIndicator(),
          )
        : Column(
            children: [
              Expanded(
                  child: Container(
                width: 960,
                padding: const EdgeInsets.symmetric(horizontal: 20),
                alignment: Alignment.center,
                color: Colors.deepPurple.shade100,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      widget.title,
                      style: const TextStyle(color: Colors.white, fontSize: 24),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(0.0),
                      child: Row(
                        children: [
                          Container(
                            width: 300,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                    color: Colors.deepPurple.shade500)),
                            child: DropdownButton<Category>(
                              focusColor: Colors.deepPurple.shade100,
                              borderRadius: BorderRadius.circular(10),
                              underline: const SizedBox(
                                height: 0,
                              ),
                              isExpanded: true,
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 20),
                              icon: Icon(
                                Icons.arrow_forward_ios,
                                color: Colors.deepPurple.shade300,
                              ),
                              value: dropdownValue,
                              hint: Text(
                                "Choose Category",
                                style: TextStyle(
                                    color: Colors.deepPurple.shade400),
                              ),
                              onChanged: (Category? value) {
                                setState(() {
                                  dropdownValue = value!;
                                });
                              },
                              items: list!.map<DropdownMenuItem<Category>>(
                                  (Category value) {
                                return DropdownMenuItem<Category>(
                                    onTap: () {
                                      jobList = Provider.of<JobsProvider>(
                                              context,
                                              listen: false)
                                          .jobList;
                                      if (value.title != "Default") {
                                        jobList = jobList!
                                            .where((element) => element.title!
                                                .contains(value.title))
                                            .toList();
                                      }
                                    },
                                    value: value,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          value.title,
                                          style: TextStyle(
                                              color:
                                                  Colors.deepPurple.shade400),
                                        ),
                                        if (value.title != "Default")
                                          Text(
                                            "${value.salary} \$",
                                            style:
                                                const TextStyle(fontSize: 12),
                                          ),
                                      ],
                                    ));
                              }).toList(),
                            ),
                          ),
                          const SizedBox(
                            width: 10,
                          ),
                          SizedBox(
                            width: 200,
                            child: TextFormField(
                              controller: searchController,
                              decoration: InputDecoration(
                                floatingLabelBehavior:
                                    FloatingLabelBehavior.never,
                                enabledBorder: const OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.white),
                                  borderRadius: BorderRadius.all(
                                    Radius.circular(20),
                                  ),
                                ),
                                suffix: InkWell(
                                  onTap: () {
                                    searchController.clear();
                                    setState(() {
                                      jobList = Provider.of<JobsProvider>(
                                              context,
                                              listen: false)
                                          .jobList;
                                    });
                                  },
                                  child: Icon(
                                    Icons.clear,
                                    color: Colors.deepPurple.shade300,
                                  ),
                                ),
                                border: const OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.white),
                                  borderRadius: BorderRadius.all(
                                    Radius.circular(20),
                                  ),
                                ),
                                label: const Text(
                                  "Job Vacancy",
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          InkWell(
                            onTap: () async {
                              await Provider.of<JobsProvider>(context,
                                      listen: false)
                                  .search(
                                    searchController.text,
                                  )
                                  .then(
                                    (value) => setState(
                                      () {
                                        jobList = Provider.of<JobsProvider>(
                                                context,
                                                listen: false)
                                            .jobSearchedList;
                                      },
                                    ),
                                  );
                            },
                            child: Container(
                              height: 50,
                              width: 80,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: Colors.deepPurple.shade300,
                                borderRadius: BorderRadius.circular(15),
                              ),
                              child: const Text(
                                "Search",
                                style: TextStyle(
                                    color: Colors.white, fontSize: 16),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              )),
              Expanded(
                flex: 11,
                child: isLoading
                    ? const CircularProgressIndicator()
                    : ListView.builder(
                        itemCount: jobList!.length,
                        itemBuilder: (context, index) {
                          return InkWell(
                            onTap: !jobList![index].isActive
                                ? null
                                : () {
                                    Navigator.of(context).pushNamed(
                                        JobFullDetailsScreen.routeName,
                                        arguments: {"job": jobList![index]});
                                  },
                            child: Container(
                              height: 120,
                              margin: const EdgeInsets.symmetric(
                                vertical: 10,
                                horizontal: 20,
                              ),
                              padding: const EdgeInsets.symmetric(
                                vertical: 10,
                                horizontal: 20,
                              ),
                              decoration: BoxDecoration(
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.shade300,
                                    offset: const Offset(0, 5),
                                    blurRadius: 10,
                                  )
                                ],
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15),
                              ),
                              child: Row(
                                children: [
                                  Expanded(
                                    flex: 4,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          jobList![index].isActive
                                              ? jobList![index].title!
                                              : "${jobList![index].title!} - is not Active",
                                          maxLines: 1,
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 20,
                                              color: jobList![index].isActive
                                                  ? Colors.black
                                                  : Colors.grey),
                                        ),
                                        const SizedBox(height: 10),
                                        SingleChildScrollView(
                                          scrollDirection: Axis.horizontal,
                                          child: Row(
                                            children: [
                                              Text(
                                                  jobList![index].companyName!),
                                              const SizedBox(width: 5),
                                              const Icon(
                                                Icons.verified_outlined,
                                                size: 15,
                                              )
                                            ],
                                          ),
                                        ),
                                        Text("${jobList![index].salary} \$"),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    flex: 1,
                                    child: InkWell(
                                      onTap: !jobList![index].isActive
                                          ? () {
                                              showSnackBar(
                                                  context, "Job is Not Active");
                                            }
                                          : () async {
                                              await Provider.of<JobsProvider>(
                                                      context,
                                                      listen: false)
                                                  .apply(jobList![index].id,
                                                      token!)
                                                  .then((value) {
                                                if (Provider.of<JobsProvider>(
                                                        context,
                                                        listen: false)
                                                    .isError!) {
                                                  showSnackBar(context,
                                                      "Something went wrong");
                                                } else {
                                                  showSnackBar(
                                                      context,
                                                      Provider.of<JobsProvider>(
                                                              context,
                                                              listen: false)
                                                          .message!,
                                                      Colors.green.shade300);
                                                }
                                              });
                                            },
                                      child: Container(
                                        height: 60,
                                        margin: const EdgeInsets.symmetric(
                                            vertical: 20),
                                        alignment: Alignment.center,
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(20),
                                            color: Colors.green.shade50),
                                        child: const Text(
                                          "Apply",
                                          style: TextStyle(fontSize: 16),
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                      child: IconButton(
                                    onPressed: () async {
                                      await Provider.of<JobsProvider>(context,
                                              listen: false)
                                          .save(jobList![index].id, token!)
                                          .then((value) {
                                        if (Provider.of<JobsProvider>(context,
                                                    listen: false)
                                                .message ==
                                            "Successfully saved") {
                                          setState(() {
                                            jobList![index].isFavorite = true;
                                          });
                                        } else {
                                          setState(() {
                                            jobList![index].isFavorite = !true;
                                          });
                                        }
                                      });
                                    },
                                    icon: Icon(
                                      (jobList![index].isFavorite == null ||
                                              !jobList![index].isFavorite!)
                                          ? Icons.favorite_border
                                          : Icons.favorite,
                                      color: Colors.red,
                                    ),
                                  ))
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          );
  }
}
