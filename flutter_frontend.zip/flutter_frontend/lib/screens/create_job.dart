import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:term_project/providers/posted_job_provider.dart';
import 'package:term_project/providers/shared_pref_profider.dart';
import 'package:term_project/region.dart';
import 'package:term_project/screens/signup_for_employee.dart';
import 'package:term_project/widgets/right_profile_widget.dart';

import '../providers/jobs_provider.dart';

class CreateJob extends StatefulWidget {
  static const routeName = "/create-job";
  const CreateJob({super.key});

  @override
  State<CreateJob> createState() => _CreateJobState();
}

class _CreateJobState extends State<CreateJob> {
  final key = GlobalKey<FormState>();

  TextEditingController jobTitleController = TextEditingController();
  TextEditingController jobDescriptionController = TextEditingController();

  TextEditingController minSalaryContr = TextEditingController();
  TextEditingController maxSalaryController = TextEditingController();

  Region? region;
  bool? isActive = false;
  bool? isRemote = false;

  FocusNode minSalaryNode = FocusNode();
  FocusNode maxSalaryNode = FocusNode();
  FocusNode jobDescriptionNode = FocusNode();

  Category? dropdownValue;

  List<Category>? listOne;

  bool isLoading = false;

  @override
  void dispose() {
    super.dispose();
    jobTitleController.dispose();
    minSalaryContr.dispose();
    maxSalaryController.dispose();
    jobDescriptionController.dispose();

    minSalaryNode.dispose();
    maxSalaryNode.dispose();
    jobDescriptionNode.dispose();
  }

  bool isSearched = false;
  bool isInit = true;

  String? token;

  @override
  void initState() {
    super.initState();
    token =
        Provider.of<SharedPreferencesProvider>(context, listen: false).token;
  }

  Job? modalData;

  @override
  void didChangeDependencies() async {
    super.didChangeDependencies();
    if (isInit) {
      setState(() {
        isLoading = true;
      });
      modalData = ModalRoute.of(context)!.settings.arguments as Job?;
      await Provider.of<JobsProvider>(context, listen: false)
          .getAllCategories()
          .then((value) {
        listOne =
            Provider.of<JobsProvider>(context, listen: false).categoryList;
      });
      setState(() {
        isLoading = false;
      });
      if (modalData != null) {
        List<String> jobDetails = modalData!.title!.split("/");
        List<String> salaries = modalData!.salary!.split("~");
        jobTitleController = TextEditingController(text: jobDetails[0]);
        minSalaryContr = TextEditingController(text: salaries[0]);
        maxSalaryController = TextEditingController(text: salaries[1]);
        jobDescriptionController =
            TextEditingController(text: modalData!.description!);
        isActive = modalData!.isActive;
        isRemote = modalData!.employementTypeAndSchedule == "Remote";
        region =
            list.firstWhere((element) => element.value == modalData!.region);
        dropdownValue =
            listOne!.firstWhere((element) => element.title == jobDetails[1]);
      }
    }
    isInit = false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        height: 800,
        width: 1200,
        child: Column(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      style: const ButtonStyle(
                        overlayColor:
                            MaterialStatePropertyAll(Colors.transparent),
                      ),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: Icon(
                        Icons.arrow_back_ios,
                        color: Colors.deepPurple.shade300,
                      ),
                    ),
                    const Text(
                      "Create Job",
                      style: TextStyle(fontSize: 24),
                    ),
                    const SizedBox()
                  ],
                ),
              ),
            ),
            Expanded(
              flex: 11,
              child: isLoading
                  ? const Center(
                      child: CircularProgressIndicator(),
                    )
                  : SizedBox(
                      width: 400,
                      child: SingleChildScrollView(
                        padding: const EdgeInsets.all(0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Form(
                              key: key,
                              child: Column(
                                children: [
                                  TextFormField(
                                    validator: (value) {
                                      if (value!.isEmpty) {
                                        return "Please Fill Forms";
                                      }
                                      return null;
                                    },
                                    controller: jobTitleController,
                                    decoration: InputDecoration(
                                      floatingLabelBehavior:
                                          FloatingLabelBehavior.never,
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: Colors.deepPurple.shade200),
                                        borderRadius: const BorderRadius.all(
                                          Radius.circular(20),
                                        ),
                                      ),
                                      border: const OutlineInputBorder(
                                        borderSide:
                                            BorderSide(color: Colors.white),
                                        borderRadius: BorderRadius.all(
                                          Radius.circular(20),
                                        ),
                                      ),
                                      label: Text(
                                        'Job Title',
                                        style: TextStyle(
                                            color: Colors.deepPurple.shade200),
                                      ),
                                    ),
                                    onFieldSubmitted: (value) {
                                      FocusScope.of(context)
                                          .requestFocus(minSalaryNode);
                                    },
                                  ),
                                  const SizedBox(height: 10),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: TextFormField(
                                          validator: (value) {
                                            if (value!.isEmpty) {
                                              return "Please Fill Forms";
                                            }
                                            return null;
                                          },
                                          controller: minSalaryContr,
                                          focusNode: minSalaryNode,
                                          keyboardType: TextInputType.number,
                                          decoration: InputDecoration(
                                            floatingLabelBehavior:
                                                FloatingLabelBehavior.never,
                                            enabledBorder: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Colors
                                                      .deepPurple.shade200),
                                              borderRadius:
                                                  const BorderRadius.all(
                                                Radius.circular(20),
                                              ),
                                            ),
                                            border: const OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Colors.white),
                                              borderRadius: BorderRadius.all(
                                                Radius.circular(20),
                                              ),
                                            ),
                                            label: Text(
                                              'Min Salary',
                                              style: TextStyle(
                                                  color: Colors
                                                      .deepPurple.shade200),
                                            ),
                                          ),
                                          onFieldSubmitted: (value) {
                                            FocusScope.of(context)
                                                .requestFocus(maxSalaryNode);
                                          },
                                        ),
                                      ),
                                      const SizedBox(width: 5),
                                      Expanded(
                                        child: TextFormField(
                                          validator: (value) {
                                            if (value!.isEmpty) {
                                              return "Please Fill Forms";
                                            }
                                            return null;
                                          },
                                          keyboardType: TextInputType.number,
                                          controller: maxSalaryController,
                                          focusNode: maxSalaryNode,
                                          decoration: InputDecoration(
                                            floatingLabelBehavior:
                                                FloatingLabelBehavior.never,
                                            enabledBorder: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Colors
                                                      .deepPurple.shade200),
                                              borderRadius:
                                                  const BorderRadius.all(
                                                Radius.circular(20),
                                              ),
                                            ),
                                            border: const OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Colors.white),
                                              borderRadius: BorderRadius.all(
                                                Radius.circular(20),
                                              ),
                                            ),
                                            label: Text(
                                              'Max Salary',
                                              style: TextStyle(
                                                  color: Colors
                                                      .deepPurple.shade200),
                                            ),
                                          ),
                                          onFieldSubmitted: (value) {
                                            FocusScope.of(context).requestFocus(
                                                jobDescriptionNode);
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 10),
                                  Container(
                                    width: 300,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(12),
                                        border: Border.all(
                                            color: Colors.deepPurple.shade500)),
                                    child: DropdownButton<Category>(
                                      focusColor: Colors.deepPurple.shade100,
                                      borderRadius: BorderRadius.circular(10),
                                      underline: const SizedBox(
                                        height: 0,
                                      ),
                                      isExpanded: true,
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 20),
                                      icon: Icon(
                                        Icons.arrow_forward_ios,
                                        color: Colors.deepPurple.shade300,
                                      ),
                                      value: dropdownValue,
                                      hint: Text(
                                        "Choose Category",
                                        style: TextStyle(
                                            color: Colors.deepPurple.shade400),
                                      ),
                                      onChanged: (Category? value) {
                                        setState(() {
                                          dropdownValue = value!;
                                        });
                                      },
                                      items: listOne!
                                          .map<DropdownMenuItem<Category>>(
                                              (Category value) {
                                        return DropdownMenuItem<Category>(
                                            value: value,
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  value.title,
                                                  style: TextStyle(
                                                      color: Colors
                                                          .deepPurple.shade400),
                                                ),
                                                if (value.title != "Default")
                                                  Text(
                                                    "${value.salary} \$",
                                                    style: const TextStyle(
                                                        fontSize: 12),
                                                  ),
                                              ],
                                            ));
                                      }).toList(),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Container(
                                    height: 40,
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Colors.deepPurple.shade200,
                                            width: 1),
                                        borderRadius:
                                            BorderRadius.circular(15)),
                                    child: DropdownButton<Region>(
                                      focusColor: Colors.deepPurple.shade100,
                                      borderRadius: BorderRadius.circular(10),
                                      underline: const SizedBox(
                                        height: 0,
                                      ),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 20),
                                      isExpanded: true,
                                      icon: Icon(
                                        Icons.more_horiz,
                                        color: Colors.deepPurple.shade300,
                                      ),
                                      value: region,
                                      hint: Text(
                                        "Region",
                                        style: TextStyle(
                                            color: Colors.deepPurple.shade400),
                                      ),
                                      onChanged: (Region? value) {
                                        setState(() {
                                          region = value!;
                                        });
                                      },
                                      items: list.map<DropdownMenuItem<Region>>(
                                          (Region value) {
                                        return DropdownMenuItem<Region>(
                                            value: value,
                                            child: Text(value.name,
                                                style: TextStyle(
                                                    color: Colors
                                                        .deepPurple.shade400)));
                                      }).toList(),
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  SizedBox(
                                    width: 200,
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          "Is is active?",
                                          style: TextStyle(
                                            color: Colors.deepPurple.shade300,
                                            fontSize: 16,
                                          ),
                                        ),
                                        Checkbox(
                                          value: isActive,
                                          onChanged: (value) {
                                            setState(
                                              () {
                                                isActive = value;
                                              },
                                            );
                                          },
                                        ),
                                      ],
                                    ),
                                  ),
                                  space(),
                                  SizedBox(
                                    width: 200,
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          "Is is Remote?",
                                          style: TextStyle(
                                            color: Colors.deepPurple.shade300,
                                            fontSize: 16,
                                          ),
                                        ),
                                        Checkbox(
                                          value: isRemote,
                                          onChanged: (value) {
                                            setState(
                                              () {
                                                isRemote = value;
                                              },
                                            );
                                          },
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  TextFormField(
                                    validator: (value) {
                                      if (value!.isEmpty) {
                                        return "Please Fill Forms";
                                      }
                                      return null;
                                    },
                                    maxLines: 5,
                                    focusNode: jobDescriptionNode,
                                    controller: jobDescriptionController,
                                    decoration: InputDecoration(
                                      floatingLabelBehavior:
                                          FloatingLabelBehavior.never,
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: Colors.deepPurple.shade200),
                                        borderRadius: const BorderRadius.all(
                                          Radius.circular(20),
                                        ),
                                      ),
                                      border: const OutlineInputBorder(
                                        borderSide:
                                            BorderSide(color: Colors.white),
                                        borderRadius: BorderRadius.all(
                                          Radius.circular(20),
                                        ),
                                      ),
                                      label: Text(
                                        'Job Description',
                                        style: TextStyle(
                                            color: Colors.deepPurple.shade200),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 20),
                            InkWell(
                              onTap: () async {
                                if (!key.currentState!.validate()) {
                                  return;
                                }
                                if (dropdownValue == null) {
                                  showSnackBar(context, "Choose Category");
                                  return;
                                }
                                if (region == null) {
                                  showSnackBar(context, "Choose Region");
                                  return;
                                }
                                if (int.tryParse(minSalaryContr.text) == null) {
                                  showSnackBar(
                                      context, "Min Salary must be integer");
                                  return;
                                }
                                if (int.tryParse(maxSalaryController.text) ==
                                    null) {
                                  showSnackBar(
                                      context, "Max Salary must be integer");
                                  return;
                                }

                                int jobId = listOne!.indexOf(dropdownValue!);
                                jobId++;
                                Map<String, dynamic> data = {
                                  "title": jobTitleController.text,
                                  "description": jobDescriptionController.text,
                                  "min_salary": minSalaryContr.text,
                                  "max_salary": maxSalaryController.text,
                                  "is_active": isActive.toString(),
                                  "is_remote": isRemote.toString(),
                                  "job": (jobId).toString(),
                                  "region": region!.value
                                };
                                if (modalData != null) {
                                  await Provider.of<PostedJobsProvider>(context,
                                          listen: false)
                                      .updateData(token!, data, modalData!.id)
                                      .then((value) {
                                    if (Provider.of<PostedJobsProvider>(context,
                                            listen: false)
                                        .isError!) {
                                      showSnackBar(context, "Error");
                                      return;
                                    } else {
                                      showSnackBar(context, "Success",
                                          Colors.green.shade300);
                                      Navigator.of(context).pushNamed("/");
                                    }
                                  });
                                } else {
                                  await Provider.of<PostedJobsProvider>(context,
                                          listen: false)
                                      .addData(token!, data)
                                      .then((value) {
                                    if (Provider.of<PostedJobsProvider>(context,
                                            listen: false)
                                        .isError!) {
                                      showSnackBar(context, "Error");
                                      return;
                                    } else {
                                      showSnackBar(context, "Success",
                                          Colors.green.shade300);
                                      Navigator.of(context).pushNamed("/");
                                    }
                                  });
                                }
                              },
                              child: Container(
                                alignment: Alignment.center,
                                height: 60,
                                width: 200,
                                decoration: BoxDecoration(
                                  color: Colors.deepPurple.shade300,
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                child: const Text(
                                  "Submit",
                                  style: TextStyle(
                                      color: Colors.white, fontSize: 24),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
