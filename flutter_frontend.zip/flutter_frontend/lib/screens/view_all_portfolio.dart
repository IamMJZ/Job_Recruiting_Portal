import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:term_project/providers/shared_pref_profider.dart';
import 'package:term_project/screens/add_new_portfolio.dart';
import 'package:term_project/screens/add_some_details_for_worker.dart';
import 'package:term_project/screens/signup_for_employee.dart';

import '../providers/portfolio_provider.dart';

class ViewAllPortfolioScreen extends StatefulWidget {
  static const routeName = "/view-all-portfolio";
  const ViewAllPortfolioScreen({super.key});

  @override
  State<ViewAllPortfolioScreen> createState() => _ViewAllPortfolioScreenState();
}

class _ViewAllPortfolioScreenState extends State<ViewAllPortfolioScreen> {
  List<dynamic>? portfolioData;
  String? token;

  Map<String, dynamic>? modalData;

  @override
  void initState() {
    super.initState();
    portfolioData = Provider.of<PortFolioProvider>(context, listen: false).data;
    token =
        Provider.of<SharedPreferencesProvider>(context, listen: false).token;
  }

  bool isInit = true;
  String name = "Your";

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (isInit) {
      modalData =
          ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>?;
      if (modalData != null) {
        portfolioData = modalData!["portfolio"];
        name = modalData!["name"];
      }
      isInit = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        width: 1200,
        height: 800,
        child: Column(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      style: const ButtonStyle(
                          overlayColor:
                              MaterialStatePropertyAll(Colors.transparent)),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: Icon(
                        Icons.arrow_back_ios,
                        color: Colors.deepPurple.shade300,
                      ),
                    ),
                    Text(
                      "$name portfolio",
                      style: TextStyle(
                        color: Colors.deepPurple.shade400,
                        fontSize: 24,
                      ),
                    ),
                    const SizedBox()
                  ],
                ),
              ),
            ),
            Expanded(
                flex: 11,
                child: Container(
                  alignment: Alignment.center,
                  width: 1200,
                  child: SizedBox(
                    width: 800,
                    child: ListView.builder(
                      itemCount: portfolioData!.length,
                      itemBuilder: (context, index) => Stack(
                        alignment: Alignment.center,
                        children: [
                          Container(
                            width: 800,
                            height: 300,
                            margin: const EdgeInsets.all(5),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(15),
                              child: Image.network(
                                portfolioData![index]["image"],
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              showDialog(
                                context: context,
                                builder: (context) {
                                  return AlertDialog(
                                    backgroundColor: Theme.of(context)
                                        .colorScheme
                                        .background,
                                    contentPadding: const EdgeInsets.all(0),
                                    content: Container(
                                      width: 400,
                                      height: 600,
                                      alignment: Alignment.center,
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 20, horizontal: 10),
                                      child: SingleChildScrollView(
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Text(
                                              portfolioData![index]
                                                  ["description"],
                                              style: TextStyle(
                                                  color: Colors
                                                      .deepPurple.shade400),
                                            ),
                                            const SizedBox(height: 20),
                                            ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                              child: Image.network(
                                                  portfolioData![index]
                                                      ["image"]),
                                            ),
                                            const SizedBox(height: 20),
                                            if(modalData==null)
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                InkWell(
                                                    onTap: () {
                                                      Navigator.of(context)
                                                          .pushNamed(
                                                              AddNewPortfolio
                                                                  .routeName,
                                                              arguments:
                                                                  portfolioData![
                                                                      index]);
                                                    },
                                                    child: button(
                                                        "Update", 40, 80)),
                                                InkWell(
                                                    onTap: () async {
                                                      await Provider.of<
                                                                  PortFolioProvider>(
                                                              context,
                                                              listen: false)
                                                          .delete(
                                                              token!,
                                                              portfolioData![
                                                                  index]["id"])
                                                          .then((value) {
                                                        if (Provider.of<
                                                                    PortFolioProvider>(
                                                                context,
                                                                listen: false)
                                                            .isError!) {
                                                          showSnackBar(context,
                                                              "Something went wrong");
                                                        } else {
                                                          showSnackBar(
                                                              context,
                                                              "Successfully deleted",
                                                              Colors.green
                                                                  .shade300);
                                                          setState(() {
                                                            portfolioData!.remove(
                                                                portfolioData![
                                                                    index]);
                                                          });
                                                          Navigator.of(context)
                                                              .pop();
                                                        }
                                                      });
                                                    },
                                                    child: button(
                                                        "Delete",
                                                        40,
                                                        80,
                                                        16,
                                                        Colors.red.shade400)),
                                              ],
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              );
                            },
                            child: Container(
                              margin: const EdgeInsets.all(5),
                              height: 300,
                              decoration: BoxDecoration(
                                color: Colors.black38,
                                borderRadius: BorderRadius.circular(15),
                                border: Border.all(
                                  color: Colors.deepPurple.shade200,
                                ),
                              ),
                              alignment: Alignment.center,
                              padding: const EdgeInsets.all(10),
                              child: Text(
                                "${(portfolioData![index]["description"] as String).substring(0, (portfolioData![index]["description"] as String).length < 100 ? (portfolioData![index]["description"] as String).length : (portfolioData![index]["description"] as String).length - 200)} ...",
                                style: const TextStyle(color: Colors.white),
                                maxLines: 2,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                )),
          ],
        ),
      ),
    );
  }
}
