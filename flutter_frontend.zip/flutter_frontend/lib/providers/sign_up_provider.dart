import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:term_project/main.dart';
import 'package:term_project/providers/profile_provider.dart';
import 'package:term_project/static_const.dart';
import 'package:http/http.dart' as http;

class SignUpProvider extends ChangeNotifier {
  String? _token;
  String? get token => _token;

  bool? _isError = false;
  bool? get isError => _isError;

  String? _message;
  String? get message => _message;

  Map<String, dynamic>? _data;
  Map<String, dynamic>? get data => _data; 

  Future<void> signUp(Map<String, dynamic> data) async {
    _isError = false;
    final url = Uri.parse("$staticUrl/users/register");
    final response = await http.post(url, body: data);
    Map<String, dynamic> responseBody = json.decode(response.body);
    _token = responseBody["tokens"] != null
        ? responseBody["tokens"]["access"]
        : null;
    if (_token == null) {
      _isError = true;
      return;
    }
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }

    final prefs = await SharedPreferences.getInstance();
    prefs.setString("token", _token!);
  }

  Future<void> addCompanyDetails(
      Map<String, dynamic> data, String token) async {
    _isError = false;
    final url = Uri.parse("$staticUrl/api/company/create");
    final response =
        await http.post(url, headers: getHeaders(token), body: data);
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
  }

  Future<void> addWorkerDetails(
      Map<String, dynamic> data, String? token) async {
    _isError = false;
    final url = Uri.parse("$staticUrl/api/worker/");
    final response =
        await http.post(url, body: data, headers: getHeaders(token!));
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
  }

  Future<void> login(Map<String, dynamic> data) async {
    _isError = false;
    _token = null;
    final url = Uri.parse("$staticUrl/users/token");
    try {
      final response = await http.post(url, body: data);
      Map<String, dynamic> responseData = json.decode(response.body);

      if (responseData.containsKey("detail")) {
        _isError = true;
        _message = responseData["detail"];
        return;
      }
      if (response.statusCode >= 400) {
        _isError = true;
        return;
      }
      _token = responseData["access"];
      if (_token == null) {
        _isError;
        return;
      }
      final urlOne = Uri.parse("$staticUrl/users/profile");
      final responseOne = await http.get(urlOne, headers: getHeaders(_token!));
      final dataOne = json.decode(responseOne.body);

      final prefs = await SharedPreferences.getInstance();
      prefs.setString("token", _token!);
      if (dataOne["is_company"]) {
        prefs.setString("userType", UserType.employer.name);
        return;
      }
      if (dataOne["is_worker"]) {
        prefs.setString("userType", UserType.employee.name);
        return;
      }
      _isError = true;
    } catch (e) {
      rethrow;
    }
  }

  Future send(String email) async {
    _isError = false;
    final url = Uri.parse("$staticUrl/confirmation/code/send/");
    final response = await http.post(url, body: {"email": email});
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
    _data = json.decode(response.body);
  }

  Future submitCode(Map<String, dynamic>data,String code ) async{
    _isError = false;
    _data = {};
    final url = Uri.parse("$staticUrl/confirmation/code/verify/");
    Map<String, dynamic> theData ={
      "signature": data["signature"],
      "code": code,
      "email": data["email"]
    };
    final response = await http.post(url, body: theData);
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
    _data = json.decode(response.body);
  }

  Future recoverPassword(Map<String, dynamic> data, String newPassword) async {
    _isError = false;
    final url = Uri.parse("$staticUrl/users/recover-password");
    final response = await http.post(url, body: {
      "email": data["email"],
      "signature": data["signature"],
      "password": newPassword
    });
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
  }
}
