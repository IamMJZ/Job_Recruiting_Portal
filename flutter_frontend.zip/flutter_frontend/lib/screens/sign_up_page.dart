import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:term_project/providers/sign_up_provider.dart';
import 'package:term_project/screens/filling_extra_details_for_employee.dart';
import 'package:term_project/screens/signup_for_employee.dart';

class SignUpPage extends StatefulWidget {
  static const String routeName = "/sign-up";
  const SignUpPage({super.key});

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final key = GlobalKey<FormState>();

  final fullNameController = TextEditingController();
  final password = TextEditingController();
  final email = TextEditingController();

  final passwordNode = FocusNode();
  final emailNode = FocusNode();
  bool? isEmployer;

  bool isLoading = false;

  @override
  void dispose() {
    super.dispose();
    fullNameController.dispose();
    password.dispose();
    email.dispose();
    passwordNode.dispose();
    emailNode.dispose();
  }

  DateTime? time;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        width: 1200,
        height: 800,
        child: Column(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    IconButton(
                      style: const ButtonStyle(
                          overlayColor:
                              MaterialStatePropertyAll(Colors.transparent)),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: Icon(
                        Icons.arrow_back_ios,
                        color: Colors.deepPurple.shade300,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              flex: 11,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 600,
                    child: Form(
                      key: key,
                      child: Column(
                        children: [
                          TextFormField(
                            validator: (value) {
                              if (value!.isEmpty) {
                                return "Please Fill Forms";
                              }
                              return null;
                            },
                            controller: fullNameController,
                            decoration: InputDecoration(
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.never,
                              enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Colors.deepPurple.shade200),
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(20))),
                              border: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Colors.deepPurple.shade200),
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(20))),
                              label: Text(
                                'Fullname',
                                style: TextStyle(
                                    color: Colors.deepPurple.shade200),
                              ),
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            validator: (value) {
                              if (value!.isEmpty) {
                                return "Please Fill Forms";
                              }
                              if (value.length < 8) {
                                return "Password must be at least 8 characters";
                              }
                              return null;
                            },
                            controller: password,
                            obscureText: true,
                            focusNode: passwordNode,
                            decoration: InputDecoration(
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.never,
                              enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Colors.deepPurple.shade200),
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(20))),
                              border: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Colors.deepPurple.shade200),
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(20))),
                              label: Text(
                                'Password',
                                style: TextStyle(
                                  color: Colors.deepPurple.shade200,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            validator: (value) {
                              if (value!.isEmpty) {
                                return "Please Fill Forms";
                              }
                              if (!value.contains("@")) {
                                return "Please Enter valid e-mail";
                              }
                              return null;
                            },
                            controller: email,
                            focusNode: emailNode,
                            decoration: InputDecoration(
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.never,
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Colors.deepPurple.shade200,
                                ),
                                borderRadius: const BorderRadius.all(
                                  Radius.circular(20),
                                ),
                              ),
                              border: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Colors.deepPurple.shade200,
                                ),
                                borderRadius: const BorderRadius.all(
                                  Radius.circular(20),
                                ),
                              ),
                              label: Text(
                                'Email',
                                style: TextStyle(
                                  color: Colors.deepPurple.shade200,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 40),
                  SizedBox(
                    width: 600,
                    child: Row(
                      children: [
                        Expanded(
                          child: InkWell(
                            onTap: () {
                              setState(() {
                                isEmployer = true;
                              });
                            },
                            child: Container(
                              height: 150,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: isEmployer == null
                                    ? Colors.white
                                    : isEmployer!
                                        ? Colors.deepPurple.shade100
                                        : Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                border: Border.all(
                                    color: Colors.deepPurple.shade200,
                                    width: 1),
                              ),
                              child: Text(
                                "Employer",
                                style: TextStyle(
                                    color: Colors.deepPurple.shade400,
                                    fontSize: 24),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 20),
                        Expanded(
                          child: InkWell(
                            onTap: () {
                              setState(() {
                                isEmployer = false;
                              });
                            },
                            child: Container(
                              height: 150,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: isEmployer == null
                                    ? Colors.white
                                    : !isEmployer!
                                        ? Colors.deepPurple.shade100
                                        : Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                border: Border.all(
                                    color: Colors.deepPurple.shade200,
                                    width: 1),
                              ),
                              child: Text("Employee",
                                  style: TextStyle(
                                      color: Colors.deepPurple.shade400,
                                      fontSize: 24)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 40),
                  InkWell(
                    onTap: isLoading
                        ? null
                        : () async {
                            if (!key.currentState!.validate()) {
                              return;
                            }
                            Map<String, dynamic> data = {
                              "full_name": fullNameController.text,
                              "password": password.text,
                              "email": email.text
                            };
                            if (isEmployer == null) {
                              showSnackBar(context, "Select your role");
                              return;
                            }
                            setState(() {
                              isLoading = true;
                            });
                            await Provider.of<SignUpProvider>(context,
                                    listen: false)
                                .signUp(data)
                                .then((value) {
                              if (Provider.of<SignUpProvider>(context,
                                      listen: false)
                                  .isError!) {
                                showSnackBar(context, "Something went wrong");
                                setState(
                                    () {
                                      isLoading = false;
                                    },
                                  );
                              } else {
                                if (isEmployer!) {
                                  Navigator.of(context).pushNamed(
                                      FillingExtraDetailsForExmployee
                                          .routeName);
                                  setState(
                                    () {
                                      isLoading = false;
                                    },
                                  );
                                } else {
                                  Navigator.of(context)
                                      .pushNamed(SignUpForEmployer.routeName);
                                  setState(
                                    () {
                                      isLoading = false;
                                    },
                                  );
                                }
                              }
                            });
                          },
                    child: Container(
                      height: 50,
                      width: 200,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          color: Colors.deepPurple.shade300,
                          borderRadius: BorderRadius.circular(15)),
                      child: isLoading
                          ? const CircularProgressIndicator()
                          : const Text(
                              "Sign Up",
                              style:
                                  TextStyle(color: Colors.white, fontSize: 24),
                            ),
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
