import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:open_file/open_file.dart';
import 'package:path/path.dart' as path;
import 'package:provider/provider.dart';
import 'package:term_project/providers/experience_provider.dart';
import 'package:term_project/providers/language_provider.dart';
import 'package:term_project/providers/portfolio_provider.dart';
import 'package:term_project/providers/shared_pref_profider.dart';
import 'package:term_project/screens/add_new_experience.dart';
import 'package:term_project/screens/add_new_language.dart';
import 'package:term_project/screens/add_new_portfolio.dart';
import 'package:term_project/screens/signup_for_employee.dart';
import 'package:term_project/screens/view_all_experience.dart';
import 'package:term_project/screens/view_all_portfolio.dart';

class AddSomeDetailesForWorker extends StatefulWidget {
  static const routeName = "/add-some-details-for-worker";
  const AddSomeDetailesForWorker({super.key});

  @override
  State<AddSomeDetailesForWorker> createState() =>
      _AddSomeDetailesForWorkerState();
}

class _AddSomeDetailesForWorkerState extends State<AddSomeDetailesForWorker> {
  List<dynamic>? portfolioData;
  List<dynamic>? languageceData;
  List<dynamic>? experienceData;
  String? token;
  bool? isLoading;

  bool isLoadingOne = false;

  File? resumeFile;

  @override
  void initState() {
    super.initState();
    token =
        Provider.of<SharedPreferencesProvider>(context, listen: false).token;
  }

  @override
  void didChangeDependencies() async {
    super.didChangeDependencies();
    setState(() {
      isLoading = true;
    });
    await Provider.of<PortFolioProvider>(context, listen: false)
        .fetchData(token!)
        .then((value) async =>
            await Provider.of<LanguageProvider>(context, listen: false)
                .getData(token!))
        .then((value) async =>
            await Provider.of<ExperienceProvider>(context, listen: false)
                .getData(token!))
        .then((value) {
      portfolioData =
          Provider.of<PortFolioProvider>(context, listen: false).data;
      languageceData =
          Provider.of<LanguageProvider>(context, listen: false).data;
      experienceData =
          Provider.of<ExperienceProvider>(context, listen: false).data;
    }).then((value) async {
      await Provider.of<PortFolioProvider>(context, listen: false)
          .getResume(token!)
          .then((value) async {
        await Provider.of<PortFolioProvider>(context, listen: false)
            .downloadFile(
                Provider.of<PortFolioProvider>(context, listen: false).resume)
            .then(
          (value) {
            resumeFile =
                Provider.of<PortFolioProvider>(context, listen: false).file;
          },
        );
      });
    });
    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        width: 1200,
        height: 800,
        child: Column(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    IconButton(
                      style: const ButtonStyle(
                          overlayColor:
                              MaterialStatePropertyAll(Colors.transparent)),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: Icon(
                        Icons.arrow_back_ios,
                        color: Colors.deepPurple.shade300,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
                flex: 11,
                child: isLoading!
                    ? const Center(
                        child: CircularProgressIndicator(),
                      )
                    : Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          InkWell(
                            onTap: () {
                              dialogForPortfolio();
                            },
                            child: Container(
                              padding: const EdgeInsets.all(10),
                              width: 600,
                              height: 80,
                              decoration: BoxDecoration(
                                color: Colors.deepPurple.shade50,
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                    color: Colors.deepPurple.shade400),
                              ),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text("Your Portfolio:"),
                                  Text(portfolioData!.length.toString())
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 10),
                          InkWell(
                            onTap: () {
                              dialogForExperience();
                            },
                            child: Container(
                              padding: const EdgeInsets.all(10),
                              width: 600,
                              height: 80,
                              decoration: BoxDecoration(
                                color: Colors.deepPurple.shade50,
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                    color: Colors.deepPurple.shade400),
                              ),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text("Your Experience:"),
                                  Text(experienceData!.length.toString())
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 10),
                          InkWell(
                            onTap: () {
                              dialogForLanguage(languageceData!, token!);
                            },
                            child: Container(
                              padding: const EdgeInsets.all(10),
                              width: 600,
                              height: 80,
                              decoration: BoxDecoration(
                                color: Colors.deepPurple.shade50,
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                    color: Colors.deepPurple.shade400),
                              ),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text("Your Languages:"),
                                  Text(languageceData!.length.toString())
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          SizedBox(
                            width: 500,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                resumeFile == null
                                    ? Text("No Resume",
                                        style: TextStyle(
                                            color: Colors.deepPurple.shade400))
                                    : InkWell(
                                        onTap: () {
                                          OpenFile.open(resumeFile!.path,
                                              type: "application/pdf",
                                              uti: "com.adobe.pdf");
                                        },
                                        child: Text(
                                          path.basename(resumeFile!.path),
                                          style: TextStyle(
                                              color: Colors.deepPurple.shade400,
                                              decoration:
                                                  TextDecoration.underline),
                                        ),
                                      ),
                                InkWell(
                                    onTap: () async {
                                      setState(() {
                                        isLoadingOne = true;
                                      });

                                      FilePicker.platform
                                          .pickFiles()
                                          .then((value) async {
                                        if (value != null) {
                                          resumeFile =
                                              File(value.files.single.path!);
                                        }
                                        setState(() {
                                          isLoadingOne = false;
                                        });
                                        await Provider.of<PortFolioProvider>(
                                                context,
                                                listen: false)
                                            .updateResume(token!, resumeFile!)
                                            .then((value) {
                                          if (Provider.of<PortFolioProvider>(
                                                  context,
                                                  listen: false)
                                              .isError!) {
                                            showSnackBar(context,
                                                "Something went wrong");
                                          } else {
                                            setState(() {
                                              resumeFile = Provider.of<
                                                          PortFolioProvider>(
                                                      context,
                                                      listen: false)
                                                  .file;
                                            });
                                          }
                                        });
                                      });
                                    },
                                    child: isLoadingOne
                                        ? Container(
                                            height: 50,
                                            width: 200,
                                            alignment: Alignment.center,
                                            decoration: BoxDecoration(
                                                color: const Color.fromRGBO(
                                                    149, 117, 205, 1),
                                                borderRadius:
                                                    BorderRadius.circular(15)),
                                            child:
                                                const CircularProgressIndicator(),
                                          )
                                        : button(resumeFile == null
                                            ? "Upload"
                                            : "Update"))
                              ],
                            ),
                          ),
                        ],
                      )),
          ],
        ),
      ),
    );
  }

  void dialogForExperience() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: Theme.of(context).colorScheme.background,
          contentPadding: const EdgeInsets.all(0),
          content: Container(
            width: 300,
            height: 242,
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                InkWell(
                    onTap: () {
                      Navigator.of(context)
                          .pushNamed(AddNewExperience.routeName);
                    },
                    child: button("Add New Experience")),
                const SizedBox(height: 20),
                InkWell(
                    onTap: () {
                      Navigator.of(context)
                          .pushNamed(ViewAllExperience.routeName);
                    },
                    child: button("View all Experience")),
              ],
            ),
          ),
        );
      },
    );
  }

  void dialogForPortfolio() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: Theme.of(context).colorScheme.background,
          contentPadding: const EdgeInsets.all(0),
          content: Container(
            width: 300,
            height: 242,
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                InkWell(
                    onTap: () {
                      Navigator.of(context)
                          .pushNamed(AddNewPortfolio.routeName);
                    },
                    child: button("Add New Portfolio")),
                const SizedBox(height: 20),
                InkWell(
                    onTap: () {
                      Navigator.of(context)
                          .pushNamed(ViewAllPortfolioScreen.routeName);
                    },
                    child: button("View all Portfolios")),
              ],
            ),
          ),
        );
      },
    );
  }

  void dialogForLanguage(List<dynamic> data, String token) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: Theme.of(context).colorScheme.background,
          contentPadding: const EdgeInsets.all(0),
          content: Container(
            width: 300,
            height: 242,
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                InkWell(
                    onTap: () {
                      Navigator.of(context).pushNamed(AddNewLanguage.routeName);
                    },
                    child: button("Add New Language")),
                const SizedBox(height: 20),
                InkWell(
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (context) {
                        return AlertDialog(
                          backgroundColor:
                              Theme.of(context).colorScheme.background,
                          contentPadding: const EdgeInsets.all(0),
                          content: Container(
                            width: 400,
                            height: 600,
                            alignment: Alignment.center,
                            padding: const EdgeInsets.symmetric(
                                vertical: 20, horizontal: 10),
                            child: Column(
                              children: [
                                Expanded(
                                  flex: 5,
                                  child: ListView.builder(
                                    itemCount: languageceData!.length,
                                    itemBuilder: (context, index) {
                                      return InkWell(
                                        onTap: () {
                                          Navigator.of(context).pushNamed(
                                            AddNewLanguage.routeName,
                                            arguments: languageceData![index],
                                          );
                                        },
                                        child: Container(
                                          height: 80,
                                          margin: const EdgeInsets.all(10),
                                          decoration: BoxDecoration(
                                              color: Colors.deepPurple.shade100,
                                              borderRadius:
                                                  BorderRadius.circular(20)),
                                          child: Row(
                                            children: [
                                              Expanded(
                                                flex: 3,
                                                child: Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceEvenly,
                                                  children: [
                                                    Text(
                                                      languageceData![index]
                                                          ["language"],
                                                      style: TextStyle(
                                                          color: Colors
                                                              .deepPurple
                                                              .shade400,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: 24),
                                                    ),
                                                    Text(
                                                      languageceData![index]
                                                          ["level"],
                                                      style: TextStyle(
                                                          color: Colors
                                                              .deepPurple
                                                              .shade300,
                                                          fontWeight:
                                                              FontWeight.normal,
                                                          fontSize: 18),
                                                    )
                                                  ],
                                                ),
                                              ),
                                              Expanded(
                                                child: InkWell(
                                                  onTap: () async {
                                                    await Provider.of<
                                                                LanguageProvider>(
                                                            context,
                                                            listen: false)
                                                        .delete(
                                                            token,
                                                            languageceData![
                                                                index]["id"])
                                                        .then((value) {
                                                      if (!Provider.of<
                                                                  LanguageProvider>(
                                                              context,
                                                              listen: false)
                                                          .isError!) {
                                                        setState(() {
                                                          languageceData!.remove(
                                                              languageceData![
                                                                  index]);
                                                        });
                                                        Navigator.of(context)
                                                            .pop();
                                                      }
                                                    });
                                                  },
                                                  child: CircleAvatar(
                                                    radius: 20,
                                                    backgroundColor:
                                                        Colors.red.shade200,
                                                    child: const Icon(
                                                      Icons
                                                          .delete_outline_rounded,
                                                      color: Colors.red,
                                                    ),
                                                  ),
                                                ),
                                              )
                                            ],
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                                const Expanded(
                                  child: Text("Click to update language"),
                                )
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  },
                  child: button("View All Languages"),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

Widget button(String text,
    [double height = 50,
    double width = 200,
    double fontSize = 16,
    color = const Color.fromRGBO(149, 117, 205, 1)]) {
  return Container(
    height: height,
    width: width,
    alignment: Alignment.center,
    decoration:
        BoxDecoration(color: color, borderRadius: BorderRadius.circular(15)),
    child: Text(
      text,
      style: TextStyle(color: Colors.white, fontSize: fontSize),
    ),
  );
}
