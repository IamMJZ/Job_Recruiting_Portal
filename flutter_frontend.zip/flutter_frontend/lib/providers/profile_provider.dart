import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:term_project/main.dart';
import 'package:term_project/static_const.dart';
import 'package:http/http.dart' as http;

class ProfileProvider extends ChangeNotifier {
  Map<String, dynamic>? _data;
  Map<String, dynamic>? get data => _data;

  Map<String, dynamic>? _workerData;
  Map<String, dynamic>? get workerData => _workerData;

  bool? _isError;
  bool? get isError => _isError;

  Future fetchDataForEmployee(String token, UserType? userType) async {
    _data = {};
    _isError = false;
    final url = Uri.parse("$staticUrl/users/profile");
    final response = await http.get(url, headers: getHeaders(token));
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
    _data = json.decode(response.body);
    return;
  }

  Future fetchDataForEmployer(String token) async {
    _data = {};
    _isError = false;
    final url = Uri.parse("$staticUrl/api/company/profile");
    final response = await http.get(url, headers: getHeaders(token));
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
    _data = json.decode(response.body);
  }

  Future updateData(String token, Map<String, dynamic> data) async {
    _isError = false;
    final url = Uri.parse("$staticUrl/api/company/update");
    final response =
        await http.put(url, body: data, headers: getHeaders(token));
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
  }

  Future getWorkerPage(String token) async {
    _isError = false;
    _workerData = {};
    final url = Uri.parse("$staticUrl/api/worker/profile");
    final response = await http.get(url, headers: getHeaders(token));
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
    _workerData = json.decode(response.body);
  }

  Future editWorkerPage(String token, Map<String, dynamic> data) async {
    _isError = false;
    Map<String, String> headers = getHeaders(token);
    headers.putIfAbsent("Content-type", () => "application/json");
    final url = Uri.parse("$staticUrl/api/worker/profile");
    final response =
        await http.put(url, body: json.encode(data), headers: headers);
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
  }
}

Map<String, String> getHeaders(String token) {
  return {
    "Authorization": "Bearer $token",
  };
}
