import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:term_project/main.dart';

class SharedPreferencesProvider extends ChangeNotifier {
  bool? _auth;
  bool? get auth => _auth;

  String? _pageName;
  String? get pageName => _pageName;

  UserType? _userType;
  UserType? get userType => _userType;

  String? _token;
  String? get token=> _token;

  Future fetchData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    _pageName = prefs.getString("page") ?? "";
    _auth = prefs.getBool("auth") ?? false;
    _token = prefs.getString("token");
    _userType = prefs.getString("userType") == null
        ? null
        : prefs.getString("userType") == UserType.employer.name
            ? UserType.employer
            : UserType.employee;
  }
}
