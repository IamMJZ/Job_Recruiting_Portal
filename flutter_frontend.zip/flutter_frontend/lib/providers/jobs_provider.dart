import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:term_project/providers/profile_provider.dart';
import 'package:term_project/static_const.dart';
import 'package:http/http.dart' as http;

class Job {
  int id;
  int companyId;
  String? title;
  String? companyName;
  String? employementTypeAndSchedule;
  String? salary;
  bool? isFavorite;
  String? description;
  bool isActive;
  String? region;
  Job(
      {required this.id,
      required this.title,
      required this.companyId,
      required this.companyName,
      required this.employementTypeAndSchedule,
      required this.salary,
      required this.isFavorite,
      required this.description,
      required this.isActive,
      required this.region});
}

class JobsProvider extends ChangeNotifier {
  List<Job>? _jobList;
  List<Job>? get jobList => _jobList;

  List<Job>? _jobSearchedList;
  List<Job>? get jobSearchedList => _jobSearchedList;

  List<AppliedJobs>? _appliedJobs;
  List<AppliedJobs>? get appliedJobs => _appliedJobs;

  List<Category>? _categoryList;
  List<Category>? get categoryList => _categoryList;

  bool? _isError;
  bool? get isError => _isError;

  String? _message;
  String? get message => _message;

  Future<void> fetchData() async {
    final url = Uri.parse("$staticUrl/api/vacancy/all");
    final response = await http.get(url);
    List<dynamic> theJobs = json.decode(response.body);
    _jobList = List.empty(growable: true);
    for (int i = 0; i < theJobs.length; i++) {
      String employementTypeAndSchedule = "";
      if (theJobs[i]["is_remote"]) {
        employementTypeAndSchedule = "Remote";
      } else {
        employementTypeAndSchedule = "On-Site";
      }
      
      _jobList!.add(Job(
          isActive: theJobs[i]["is_active"] as bool,
          id: theJobs[i]["id"] as int,
          title: "${theJobs[i]["title"]}/${theJobs[i]["job"]["name"]}",
          companyId: theJobs[i]["company"]["id"] as int,
          companyName: theJobs[i]["company"]["title"] as String?,
          employementTypeAndSchedule: employementTypeAndSchedule,
          salary: "${theJobs[i]["min_salary"]}~${theJobs[i]["max_salary"]}",
          isFavorite: theJobs[i]["created_at"] as bool?,
          description: theJobs[i]["description"] as String?,
          region: theJobs[i]["region"] as String?));
    }
  }

  Future<void> apply(int id, String token) async {
    _isError = false;
    final url = Uri.parse("$staticUrl/api/vacancy/$id/apply");
    final respone = await http.post(url, headers: getHeaders(token));
    if (respone.statusCode >= 400) {
      _isError = true;
      return;
    }
    _message = json.decode(respone.body)["msg"];
  }

  Future cancel(int id, String token) async {
    _isError = false;
    final url = Uri.parse("$staticUrl/api/worker/applied_job/$id/cancel");
    final response = await http.delete(url, headers: getHeaders(token));
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
  }

  Future save(int id, String token) async {
    _isError = false;
    _message = null;
    final url = Uri.parse("$staticUrl/api/vacancy/$id/save");
    final response = await http.post(url, headers: getHeaders(token));
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
    _message = json.decode(response.body)["msg"];
  }

  Future getAppliedJobs(String token) async {
    _appliedJobs = List.empty(growable: true);
    _isError = false;
    final url = Uri.parse("$staticUrl/api/worker/applied_jobs");
    final response = await http.get(url, headers: getHeaders(token));
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
    List<dynamic> data = json.decode(response.body);
    for (int i = 0; i < data.length; i++) {
      _appliedJobs!.add(AppliedJobs(
          data[i]["vacancy"]["title"],
          data[i]["id"],
          data[i]["vacancy"]["id"],
          data[i]["vacancy"]["company"]["id"],
          data[i]["vacancy"]["company"]["title"],
          "${data[i]["vacancy"]["min_salary"]}~${data[i]["vacancy"]["max_salary"]}",
          data[i]["status"]));
    }
  }

  Future getAllCategories() async {
    _isError = false;
    _categoryList = List.empty(growable: true);
    final url = Uri.parse("$staticUrl/api/category/");
    final response = await http.get(url);
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
    List<dynamic> data = json.decode(response.body);
    for (int i = 0; i < data.length; i++) {
      _categoryList!.add(Category(
        data[i]["name"] as String,
        "${data[i]["min_salary"]}~${data[i]["max_salary"]}",
        data[i]["vacancy_count"],
      ));
    }
  }

  Future search(String title) async {
    _isError = false;
    final url = Uri.parse("$staticUrl/api/search/vacancy?search=$title");
    final response = await http.get(url);
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
    List<dynamic> data = json.decode(response.body);
    _jobSearchedList = List.empty(growable: true);
    for (int i = 0; i < data.length; i++) {
      String employementTypeAndSchedule = "";
      if (data[i]["is_remote"]) {
        employementTypeAndSchedule = "Remote";
      } else {
        employementTypeAndSchedule = "On-Site";
      }
      _jobSearchedList!.add(Job(
          isActive: data[i]["is_active"] as bool,
          id: data[i]["id"] as int,
          title: "${data[i]["title"]}/${data[i]["job"]["name"]}",
          companyId: data[i]["company"]["id"] as int,
          companyName: data[i]["company"]["title"] as String?,
          employementTypeAndSchedule: employementTypeAndSchedule,
          salary: "${data[i]["min_salary"]}~${data[i]["max_salary"]}",
          isFavorite: data[i]["created_at"] as bool?,
          description: data[i]["description"] as String?,
          region: data[i]["region"] as String?));
    }
  }
}

class Category {
  String title;
  String salary;
  int vacancyCount;
  Category(
    this.title,
    this.salary,
    this.vacancyCount,
  );
}

class AppliedJobs {
  String title;
  int id;
  int vacancyId;
  String companyName;
  int companyId;
  String salary;
  String status;
  AppliedJobs(
    this.title,
    this.id,
    this.vacancyId,
    this.companyId,
    this.companyName,
    this.salary,
    this.status,
  );
}
