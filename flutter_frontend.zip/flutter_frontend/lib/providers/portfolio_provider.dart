import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:term_project/providers/profile_provider.dart';
import 'package:term_project/static_const.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

class PortFolioProvider extends ChangeNotifier {
  List<dynamic>? _data;

  List<dynamic>? get data => _data;

  String? _resume;
  String? get resume => _resume;

  bool? _isError;
  bool? get isError => _isError;

  File? _file;
  File? get file => _file;

  Future fetchData(String token) async {
    _isError = false;
    _data = [];
    final url = Uri.parse("$staticUrl/api/worker/portfoilo");
    final response = await http.get(url, headers: getHeaders(token));
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
    _data = json.decode(response.body);
  }

  Future<void> add(String token, Map<String, dynamic> data) async {
    _isError = false;

    Dio dio = Dio();
    try {
      FormData formData = FormData();
      formData.files.add(MapEntry("image",
          await MultipartFile.fromFile((data["image"] as File?)!.path)));
      formData.fields.add(MapEntry("description", data["description"]));
      formData.fields.add(MapEntry("worker", data["worker"]));

      Options options = Options(headers: getHeaders(token));

      await dio.post("$staticUrl/api/worker/portfoilo",
          data: formData, options: options);
    } catch (e) {
      _isError = true;
    }
  }

  Future updateData(int id, String token, Map<String, dynamic> data) async {
    _isError = false;
    try {
      Dio dio = Dio();
      FormData formData = FormData();
      formData.files.add(MapEntry("image",
          await MultipartFile.fromFile((data["image"] as File?)!.path)));
      formData.fields.add(MapEntry("description", data["description"]));
      formData.fields.add(MapEntry("worker", data["worker"]));

      Options options = Options(headers: getHeaders(token));

      await dio.put("$staticUrl/api/worker/portfoilo/$id",
          data: formData, options: options);
    } catch (e) {
      _isError = true;
    }
  }

  Future delete(String token, int id) async {
    _isError = false;
    final url = Uri.parse("$staticUrl/api/worker/portfoilo/$id");
    final response = await http.delete(url, headers: getHeaders(token));
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
  }

  Future getResume(String token) async {
    _isError = false;
    _resume = null;
    final url = Uri.parse("$staticUrl/api/worker/resume");
    final response = await http.get(url, headers: getHeaders(token));
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
    _resume = json.decode(response.body)["resume"];
  }

  Future updateResume(String token, File resume) async {
    _isError = false;
    try {
      Dio dio = Dio();
      FormData formData = FormData();
      formData.files.add(MapEntry(
          "resume", await MultipartFile.fromFile((resume as File?)!.path)));
      await dio
          .put("$staticUrl/api/worker/resume",
              data: formData, options: Options(headers: getHeaders(token)))
          .then((value) async {
        _resume = value.data["resume"];
        await downloadFile(_resume);
      });
    } catch (e) {
      _isError = true;
    }
  }

  Future downloadFile(String? resumeOne) async {
    _isError = false;
    String url;
    if(resumeOne ==null ){
      _file = null;
      return;
    }
    if (resumeOne.contains("http")) {
      url = resumeOne;
    } else {
      url = "$staticUrl$resumeOne";
    }
    String filename = resumeOne.split("/").last;
    var response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      var bytes = response.bodyBytes;
      var dir = await getApplicationDocumentsDirectory();
      _file = File('${dir.path}/$filename');

      await _file!.writeAsBytes(bytes);
    } else {
      throw Exception('Error while downloading file');
    }
  }
}
