import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:term_project/providers/profile_provider.dart';
import 'package:term_project/static_const.dart';
import 'package:http/http.dart' as http;

class ApplicantsProvider extends ChangeNotifier {
  List<dynamic>? _applicantList;
  List<dynamic>? get applicantList => _applicantList;

  Map<String, dynamic>? _data;
  Map<String, dynamic>? get data => _data;

  bool? _isError;
  bool? get isError => _isError;

  Future fetchData(String token, int id) async {
    _isError = false;
    _applicantList = [];
    final url = Uri.parse("$staticUrl/api/company/vacancy/$id/applied_users");
    final response = await http.get(url, headers: getHeaders(token));
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
    _applicantList = json.decode(response.body);
  }

  Future acceptOrReject(String token, int id, String status) async {
    _isError = false;
    final url = Uri.parse("$staticUrl/api/company/job_application/$id");
    final response = await http
        .post(url, headers: getHeaders(token), body: {"status": status});
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
  }

  Future getWorkerDetails(String token, int id) async {
    _isError = false;
    _data = {};
    final url = Uri.parse("$staticUrl/api/worker/$id/detail");
    final response = await http.get(url, headers: getHeaders(token));
    if (response.statusCode >= 400) {
      _isError = true;
      return null;
    }
    _data = json.decode(response.body);
  }

  Future scheduleInterview(String token, Map<String, dynamic> data) async {
    _isError = false;
    final url = Uri.parse("$staticUrl/api/company/schedule_interview");
    final response =
        await http.post(url, headers: getHeaders(token), body: data);
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
  }

  Future updateInterviews(String token, int interviewId, Map<String, dynamic> data) async {
    _isError = false;
    final url  = Uri.parse("$staticUrl/api/company/interview/$interviewId/update");
    final response = await http.put(url, headers: getHeaders(token), body: data);
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
  }
}
