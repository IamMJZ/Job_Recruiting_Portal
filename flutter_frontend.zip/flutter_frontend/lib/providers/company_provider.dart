import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:term_project/providers/jobs_provider.dart';
import 'package:term_project/static_const.dart';
import 'package:http/http.dart';

class CompanyProvider extends ChangeNotifier {
  Map<String, dynamic>? _data;
  Map<String, dynamic>? get data => _data;

  List<Job>? _jobList;
  List<Job>? get jobList => _jobList;

  bool? _isError;
  bool? get isError => _isError;

  Future fetchAllCompanies(int id) async {
    _isError = false;
    final url = Uri.parse("$staticUrl/api/company/$id/detail");
    final response = await get(url);
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
    _data = json.decode(response.body);

    _jobList = List.empty(growable: true);
    for (int i = 0; i < _data!["company_vacancy"].length; i++) {
      String employementTypeAndSchedule = "";
      if (_data!["company_vacancy"][i]["is_remote"]) {
        employementTypeAndSchedule = "Remote";
      } else {
        employementTypeAndSchedule = "Office";
      }
      _jobList!.add(Job(
          id: _data!["company_vacancy"][i]["id"],
          title: _data!["company_vacancy"][i]["title"],
          companyId: _data!["id"],
          companyName: _data!["title"],
          employementTypeAndSchedule: employementTypeAndSchedule,
          salary: "${_data!["company_vacancy"][i]["min_salary"]}~${_data!["company_vacancy"][i]["max_salary"]}",
          isFavorite: _data!["company_vacancy"][i]["date_posted"],
          description: _data!["company_vacancy"][i]["description"],
          isActive: _data!["company_vacancy"][i]["is_active"],
          region: _data!["company_vacancy"][i]["region"]));
    }
  }
}
