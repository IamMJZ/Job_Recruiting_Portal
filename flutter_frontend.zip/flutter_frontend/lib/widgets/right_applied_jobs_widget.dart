import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:term_project/screens/jobs_full_details.dart';
import 'package:term_project/screens/signup_for_employee.dart';

import '../providers/jobs_provider.dart';
import '../providers/shared_pref_profider.dart';

class RightAppliedJobsWidget extends StatefulWidget {
  const RightAppliedJobsWidget({super.key, required this.title});
  final String title;

  @override
  State<RightAppliedJobsWidget> createState() => _RightAppliedJobsWidgetState();
}

class _RightAppliedJobsWidgetState extends State<RightAppliedJobsWidget> {
  List<AppliedJobs>? jobList;

  bool isLoading = false;

  String? token;

  @override
  void initState() {
    super.initState();
    setState(() {
      isLoading = true;
    });
    Future.delayed(Duration.zero, () async {
      await Provider.of<SharedPreferencesProvider>(context, listen: false)
          .fetchData()
          .then((value) async {
        await Provider.of<JobsProvider>(context, listen: false).getAppliedJobs(
            Provider.of<SharedPreferencesProvider>(context, listen: false)
                .token!);
      });

      setState(() {
        isLoading = false;
      });
    }).then((value) {
      jobList = Provider.of<JobsProvider>(context, listen: false).appliedJobs!;
    });
    token =
        Provider.of<SharedPreferencesProvider>(context, listen: false).token;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: Container(
            width: 960,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            alignment: Alignment.center,
            color: Colors.deepPurple.shade100,
            child: Text(
              widget.title,
              style: const TextStyle(color: Colors.white, fontSize: 24),
            ),
          ),
        ),
        Expanded(
          flex: 11,
          child: isLoading
              ? const Center(child: CircularProgressIndicator())
              : ListView.builder(
                  itemCount: jobList!.length,
                  itemBuilder: (context, index) {
                    return InkWell(
                      onTap: () async {
                        await Provider.of<JobsProvider>(context, listen: false)
                            .fetchData()
                            .then((value) {
                          final tempData =
                              Provider.of<JobsProvider>(context, listen: false)
                                  .jobList;
                          Navigator.of(context).pushNamed(
                              JobFullDetailsScreen.routeName,
                              arguments: {"job": tempData![index]});
                        });
                      },
                      child: Container(
                          height: 120,
                          margin: const EdgeInsets.symmetric(
                            vertical: 10,
                            horizontal: 20,
                          ),
                          padding: const EdgeInsets.symmetric(
                            vertical: 10,
                            horizontal: 20,
                          ),
                          decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.shade300,
                                offset: const Offset(0, 5),
                                blurRadius: 10,
                              )
                            ],
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          jobList![index].title,
                                          maxLines: 1,
                                          style: const TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 20),
                                        ),
                                        const SizedBox(width: 5),
                                        if (jobList![index].status ==
                                            "pending") ...{
                                          const CircleAvatar(
                                            radius: 3,
                                            backgroundColor: Colors.grey,
                                          ),
                                        } else if (jobList![index].status ==
                                            "accepted") ...{
                                          CircleAvatar(
                                            radius: 3,
                                            backgroundColor:
                                                Colors.green.shade400,
                                          ),
                                        } else ...{
                                          CircleAvatar(
                                            radius: 3,
                                            backgroundColor:
                                                Colors.red.shade400,
                                          ),
                                        }
                                      ],
                                    ),
                                    const SizedBox(height: 10),
                                    SingleChildScrollView(
                                      scrollDirection: Axis.horizontal,
                                      child: Row(
                                        children: [
                                          Text(jobList![index].companyName),
                                          const SizedBox(width: 5),
                                          const Icon(
                                            Icons.verified_outlined,
                                            size: 15,
                                          )
                                        ],
                                      ),
                                    ),
                                    Text(jobList![index].salary.toString()),
                                    SingleChildScrollView(
                                      scrollDirection: Axis.horizontal,
                                      child: Row(
                                        children: [
                                          Text(jobList![index].companyName),
                                          const SizedBox(width: 5),
                                          const Icon(
                                            Icons.shopping_bag_outlined,
                                            size: 15,
                                          )
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Expanded(
                                  flex: 1,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      InkWell(
                                        onTap: () async {
                                          await Provider.of<JobsProvider>(
                                                  context,
                                                  listen: false)
                                              .cancel(
                                                  jobList![index].id, token!)
                                              .then((value) {
                                            if (Provider.of<JobsProvider>(
                                                    context,
                                                    listen: false)
                                                .isError!) {
                                              showSnackBar(context,
                                                  "Some error occured");
                                            } else {
                                              showSnackBar(
                                                  context,
                                                  "Job cancelled",
                                                  Colors.green.shade300);
                                              setState(() {
                                                jobList!.removeAt(index);
                                              });
                                            }
                                          });
                                        },
                                        child: Container(
                                          height: 60,
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 20, horizontal: 10),
                                          margin: const EdgeInsets.symmetric(
                                              vertical: 20),
                                          alignment: Alignment.center,
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                              color: Colors.red.shade50,
                                              boxShadow: [
                                                BoxShadow(
                                                    color: Colors.grey.shade200,
                                                    offset: const Offset(2, 5),
                                                    blurRadius: 5),
                                                BoxShadow(
                                                    color: Colors.grey.shade200,
                                                    offset: const Offset(-2, 5),
                                                    blurRadius: 5)
                                              ]),
                                          child: const Text(
                                            "Cancel",
                                            style: TextStyle(fontSize: 16),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ))
                            ],
                          )),
                    );
                  },
                ),
        ),
      ],
    );
  }
}
