import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:term_project/providers/experience_provider.dart';
import 'package:term_project/providers/language_provider.dart';
import 'package:term_project/providers/shared_pref_profider.dart';
import 'package:term_project/screens/add_new_experience.dart';
import 'package:term_project/screens/signup_for_employee.dart';

class ViewAllExperience extends StatefulWidget {
  static const routeName = "/view-all-experience";
  const ViewAllExperience({super.key});

  @override
  State<ViewAllExperience> createState() => _ViewAllExperienceState();
}

class _ViewAllExperienceState extends State<ViewAllExperience> {
  List<dynamic>? data;

  String? token;

  Map<String, dynamic>? modalData;

  @override
  void initState() {
    super.initState();
    data = Provider.of<ExperienceProvider>(context, listen: false).data;

    token =
        Provider.of<SharedPreferencesProvider>(context, listen: false).token;
  }

  bool isInit = true;
  String name = "Your";

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (isInit) {
      modalData =
          ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>?;
      if (modalData != null) {
        data = modalData!["experience"];
        name = modalData!["name"];
      }
      isInit = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        width: 1200,
        height: 800,
        child: Column(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      style: const ButtonStyle(
                          overlayColor:
                              MaterialStatePropertyAll(Colors.transparent)),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: Icon(
                        Icons.arrow_back_ios,
                        color: Colors.deepPurple.shade300,
                      ),
                    ),
                    Text(
                      "$name Experiences",
                      style: TextStyle(
                        color: Colors.deepPurple.shade400,
                        fontSize: 24,
                      ),
                    ),
                    const SizedBox()
                  ],
                ),
              ),
            ),
            Expanded(
                flex: 11,
                child: Container(
                  width: 1200,
                  alignment: Alignment.center,
                  child: SizedBox(
                    width: 600,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        if (modalData == null) const Text("Click To Update"),
                        SizedBox(
                          height: 687,
                          child: ListView.builder(
                            itemCount: data!.length,
                            itemBuilder: (context, index) {
                              return InkWell(
                                onTap: modalData != null
                                    ? null
                                    : () {
                                        Navigator.of(context).pushNamed(
                                            AddNewExperience.routeName,
                                            arguments: data![index]);
                                      },
                                child: Container(
                                    margin: const EdgeInsets.all(10),
                                    padding: const EdgeInsets.all(20),
                                    height: 180,
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(20),
                                        border: Border.all(
                                            color: Colors.deepPurple.shade400)),
                                    child: Row(
                                      children: [
                                        Expanded(
                                            flex: 3,
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceEvenly,
                                              children: [
                                                Text(
                                                  data![index]["position"],
                                                  style: TextStyle(
                                                      color: Colors
                                                          .deepPurple.shade400,
                                                      fontSize: 24,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                                Text(
                                                    data![index]
                                                        ["organization"],
                                                    style:
                                                        TextStyle(
                                                            color: Colors
                                                                .deepPurple
                                                                .shade200,
                                                            fontSize: 18,
                                                            fontWeight:
                                                                FontWeight
                                                                    .normal)),
                                                Text(
                                                    data![index]["end_date"] !=
                                                            null
                                                        ? "${data![index]["start_date"]}~${data![index]["end_date"]}"
                                                        : "${data![index]["start_date"]}~current",
                                                    style: TextStyle(
                                                        color: Colors.deepPurple
                                                            .shade200,
                                                        fontSize: 18,
                                                        fontWeight:
                                                            FontWeight.normal)),
                                              ],
                                            )),
                                        if(modalData == null)
                                        Expanded(
                                            child: SizedBox(
                                          child: InkWell(
                                            onTap: () async {
                                              await Provider.of<
                                                          ExperienceProvider>(
                                                      context,
                                                      listen: false)
                                                  .deleteData(token!,
                                                      data![index]["id"])
                                                  .then((value) {
                                                if (Provider.of<
                                                            LanguageProvider>(
                                                        context,
                                                        listen: false)
                                                    .isError!) {
                                                  showSnackBar(context,
                                                      "Something went wrong");
                                                } else {
                                                  setState(() {
                                                    data!.removeAt(data!
                                                        .indexOf(data![index]));
                                                  });
                                                  showSnackBar(
                                                      context,
                                                      "Successfully deleted",
                                                      Colors.green.shade300);
                                                }
                                              });
                                            },
                                            child: CircleAvatar(
                                              radius: 40,
                                              backgroundColor:
                                                  Colors.red.shade200,
                                              child: const Icon(
                                                Icons.delete_outline_rounded,
                                                color: Colors.red,
                                                size: 40,
                                              ),
                                            ),
                                          ),
                                        ))
                                      ],
                                    )),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ))
          ],
        ),
      ),
    );
  }
}
