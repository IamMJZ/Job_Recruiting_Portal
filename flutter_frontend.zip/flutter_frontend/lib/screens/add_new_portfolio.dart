import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:term_project/providers/portfolio_provider.dart';
import 'package:term_project/screens/add_some_details_for_worker.dart';
import 'package:term_project/screens/signup_for_employee.dart';
import 'package:path/path.dart' as path;

import '../providers/profile_provider.dart';
import '../providers/shared_pref_profider.dart';

class AddNewPortfolio extends StatefulWidget {
  static const routeName = "/add-new-portfolio";
  const AddNewPortfolio({super.key});

  @override
  State<AddNewPortfolio> createState() => _AddNewPortfolioState();
}

class _AddNewPortfolioState extends State<AddNewPortfolio> {
  final key = GlobalKey<FormState>();
  String? token;
  int? id;

  File? image;

  TextEditingController descriptionController = TextEditingController();

  bool? isLoading;

  bool isLoadingOne = false;

  @override
  void dispose() {
    super.dispose();
    descriptionController.dispose();
  }

  @override
  void initState() {
    super.initState();
    token =
        Provider.of<SharedPreferencesProvider>(context, listen: false).token;
  }

  Map<String, dynamic>? modalData;

  @override
  void didChangeDependencies() async {
    super.didChangeDependencies();
    setState(() {
      isLoading = true;
    });
    modalData =
        ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>?;
    if (modalData != null) {
      descriptionController =
          TextEditingController(text: modalData!["description"]);
      // image = File() ;
    }

    await Provider.of<ProfileProvider>(context, listen: false)
        .getWorkerPage(token!)
        .then((value) {
      final data =
          Provider.of<ProfileProvider>(context, listen: false).workerData;
      id = data!["id"];
    });
    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        width: 1200,
        height: 800,
        child: Column(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      style: const ButtonStyle(
                          overlayColor:
                              MaterialStatePropertyAll(Colors.transparent)),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: Icon(
                        Icons.arrow_back_ios,
                        color: Colors.deepPurple.shade300,
                      ),
                    ),
                    Text(
                      "Add New Portfolio",
                      style: TextStyle(
                          color: Colors.deepPurple.shade300,
                          fontSize: 24,
                          fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(),
                  ],
                ),
              ),
            ),
            Expanded(
              flex: 11,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  const SizedBox(height: 100),
                  SizedBox(
                    width: 400,
                    child: Row(
                      children: [
                        Text(
                          "Enter description: ",
                          style: TextStyle(
                              fontSize: 18, color: Colors.deepPurple.shade400),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: 400,
                    child: Form(
                      key: key,
                      child: TextFormField(
                        validator: (value) {
                          List<String> values = value!.split(" ");
                          if (values.length < 50) {
                            return "Your description must be at 50 words";
                          }
                          return null;
                        },
                        maxLines: 5,
                        controller: descriptionController,
                        decoration: InputDecoration(
                          floatingLabelBehavior: FloatingLabelBehavior.never,
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Colors.deepPurple.shade200,
                            ),
                            borderRadius: const BorderRadius.all(
                              Radius.circular(20),
                            ),
                          ),
                          border: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Colors.deepPurple.shade200,
                            ),
                            borderRadius: const BorderRadius.all(
                              Radius.circular(20),
                            ),
                          ),
                          label: Text(
                            'Description',
                            style: TextStyle(
                              color: Colors.deepPurple.shade200,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  InkWell(
                      onTap: isLoadingOne
                          ? null
                          : () async {
                              setState(() {
                                isLoadingOne = true;
                              });
                              FilePickerResult? result =
                                  await FilePicker.platform.pickFiles();
                              if (result != null) {
                                image = File(result.files.single.path!);
                              } else {
                                // User canceled the picker
                              }
                              setState(() {
                                isLoadingOne = false;
                              });
                            },
                      child: isLoadingOne
                          ? Container(
                              height: 40,
                              width: 150,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                  color: Colors.deepPurple.shade300,
                                  borderRadius: BorderRadius.circular(15)),
                              child: const CircularProgressIndicator())
                          : button(
                              image != null
                                  ? path.basename(image!.path)
                                  : "Pick Image",
                              40,
                              150)),
                  const SizedBox(height: 20),
                  InkWell(
                      onTap: () async {
                        if (!key.currentState!.validate()) {
                          return;
                        }
                        if (image == null) {
                          showSnackBar(context, "Please Pick Image");
                        }
                        Map<String, dynamic> data = {
                          "worker": id.toString(),
                          "description": descriptionController.text,
                          "image": image
                        };
                        if (modalData == null) {
                          await Provider.of<PortFolioProvider>(context,
                                  listen: false)
                              .add(token!, data)
                              .then((value) {
                            if (Provider.of<PortFolioProvider>(context,
                                    listen: false)
                                .isError!) {
                              showSnackBar(context, "Something went wrong");
                            } else {
                              showSnackBar(context, "Successfully Added",
                                  Colors.green.shade300);
                            }
                          });
                        } else {
                          await Provider.of<PortFolioProvider>(context,
                                  listen: false)
                              .updateData(modalData!["id"], token!, data)
                              .then((value) {
                            if (Provider.of<PortFolioProvider>(context,
                                    listen: false)
                                .isError!) {
                              showSnackBar(context, "Something went wrong");
                            } else {
                              showSnackBar(context, "Successfully Added",
                                  Colors.green.shade300);
                              Navigator.of(context).pushNamed("/");
                            }
                          });
                        }
                      },
                      child: button("Add"))
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
