import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:term_project/providers/experience_provider.dart';
import 'package:term_project/providers/shared_pref_profider.dart';
import 'package:term_project/screens/add_some_details_for_worker.dart';
import 'package:term_project/screens/signup_for_employee.dart';

import '../providers/jobs_provider.dart';
import '../providers/profile_provider.dart';

class AddNewExperience extends StatefulWidget {
  static const routeName = "/add-new-experience";
  const AddNewExperience({super.key});

  @override
  State<AddNewExperience> createState() => _AddNewExperienceState();
}

class _AddNewExperienceState extends State<AddNewExperience> {
  final key = GlobalKey<FormState>();
  TextEditingController positionController = TextEditingController();
  TextEditingController organizationController = TextEditingController();

  DateTime? startDate;
  DateTime? endDate;
  bool? isActive = false;

  Category? dropdownValue;

  List<Category>? list;

  bool isLoading = false;
  String? token;
  int? id;

  @override
  void initState() {
    super.initState();
    token =
        Provider.of<SharedPreferencesProvider>(context, listen: false).token;
  }

  bool isInit = true;

  Map<String, dynamic>? data;

  @override
  void didChangeDependencies() async {
    super.didChangeDependencies();
    data = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>?;
    if (isInit) {
      try {
        setState(() {
          isLoading = true;
        });
        await Provider.of<JobsProvider>(context, listen: false)
            .getAllCategories()
            .then((value) async {
          await Provider.of<ProfileProvider>(context, listen: false)
              .getWorkerPage(token!)
              .then((value) {
            list =
                Provider.of<JobsProvider>(context, listen: false).categoryList;
            id = Provider.of<ProfileProvider>(context, listen: false)
                .workerData!["id"];
          });
        });
      } finally {
        setState(() {
          isLoading = false;
        });
        if (data != null) {
          setState(() {
            positionController = TextEditingController(text: data!["position"]);
            organizationController =
                TextEditingController(text: data!["organization"]);
            dropdownValue = list!.elementAt(data!["organization_category"] - 1);
            isActive = data!["is_active"];
            startDate = DateTime.parse(data!["start_date"]);
            endDate = data!["end_date"] == null
                ? null
                : DateTime.parse(data!["end_date"]);
          });
        }
      }
      setState(() {
        isInit = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        width: 1200,
        height: 800,
        child: Column(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      style: const ButtonStyle(
                          overlayColor:
                              MaterialStatePropertyAll(Colors.transparent)),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: Icon(
                        Icons.arrow_back_ios,
                        color: Colors.deepPurple.shade300,
                      ),
                    ),
                    Text(
                      "Add new experience",
                      style: TextStyle(
                        color: Colors.deepPurple.shade400,
                        fontSize: 24,
                      ),
                    ),
                    const SizedBox()
                  ],
                ),
              ),
            ),
            Expanded(
              flex: 11,
              child: isLoading
                  ? const Center(
                      child: CircularProgressIndicator(),
                    )
                  : Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        const SizedBox(height: 100),
                        Container(
                          width: 300,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                  color: Colors.deepPurple.shade500)),
                          child: DropdownButton<Category>(
                            focusColor: Colors.deepPurple.shade100,
                            borderRadius: BorderRadius.circular(10),
                            underline: const SizedBox(
                              height: 0,
                            ),
                            isExpanded: true,
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            icon: Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.deepPurple.shade300,
                            ),
                            value: dropdownValue,
                            hint: Text(
                              "Choose Category",
                              style:
                                  TextStyle(color: Colors.deepPurple.shade400),
                            ),
                            onChanged: (Category? value) {
                              setState(
                                () {
                                  dropdownValue = value!;
                                },
                              );
                            },
                            items: list!.map<DropdownMenuItem<Category>>(
                              (Category value) {
                                return DropdownMenuItem<Category>(
                                  value: value,
                                  child: Text(
                                    value.title,
                                    style: TextStyle(
                                        color: Colors.deepPurple.shade400),
                                  ),
                                );
                              },
                            ).toList(),
                          ),
                        ),
                        const SizedBox(height: 20),
                        Form(
                          key: key,
                          child: SizedBox(
                            width: 400,
                            child: Column(
                              children: [
                                TextFormField(
                                  validator: (value) {
                                    if (value!.isEmpty) {
                                      return "Please Fill Forms";
                                    }

                                    return null;
                                  },
                                  controller: positionController,
                                  decoration: InputDecoration(
                                    floatingLabelBehavior:
                                        FloatingLabelBehavior.never,
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                        color: Colors.deepPurple.shade200,
                                      ),
                                      borderRadius: const BorderRadius.all(
                                        Radius.circular(20),
                                      ),
                                    ),
                                    border: OutlineInputBorder(
                                      borderSide: BorderSide(
                                        color: Colors.deepPurple.shade200,
                                      ),
                                      borderRadius: const BorderRadius.all(
                                        Radius.circular(20),
                                      ),
                                    ),
                                    label: Text(
                                      'Position',
                                      style: TextStyle(
                                        color: Colors.deepPurple.shade200,
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 10),
                                TextFormField(
                                  validator: (value) {
                                    if (value!.isEmpty) {
                                      return "Please Fill Forms";
                                    }

                                    return null;
                                  },
                                  controller: organizationController,
                                  decoration: InputDecoration(
                                    floatingLabelBehavior:
                                        FloatingLabelBehavior.never,
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                        color: Colors.deepPurple.shade200,
                                      ),
                                      borderRadius: const BorderRadius.all(
                                        Radius.circular(20),
                                      ),
                                    ),
                                    border: OutlineInputBorder(
                                      borderSide: BorderSide(
                                        color: Colors.deepPurple.shade200,
                                      ),
                                      borderRadius: const BorderRadius.all(
                                        Radius.circular(20),
                                      ),
                                    ),
                                    label: Text(
                                      'Organization',
                                      style: TextStyle(
                                        color: Colors.deepPurple.shade200,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        SizedBox(
                          width: 200,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "Are you working?",
                                style: TextStyle(
                                  color: Colors.deepPurple.shade300,
                                  fontSize: 16,
                                ),
                              ),
                              Checkbox(
                                value: isActive,
                                onChanged: (value) {
                                  setState(
                                    () {
                                      isActive = value;
                                    },
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),
                        SizedBox(
                          width: 300,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                startDate == null
                                    ? "Start date: "
                                    : DateFormat.yMEd().format(startDate!),
                                style: TextStyle(
                                  color: Colors.deepPurple.shade300,
                                  fontSize: 16,
                                ),
                              ),
                              InkWell(
                                  onTap: () async {
                                    DateTime? temp = await pickDate();
                                    setState(() {
                                      startDate = temp;
                                    });
                                  },
                                  child: button("Pick a date", 50, 100, 14))
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),
                        SizedBox(
                          width: 300,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                endDate == null
                                    ? "End date: "
                                    : DateFormat.yMEd().format(endDate!),
                                style: TextStyle(
                                  color: Colors.deepPurple.shade300,
                                  fontSize: 16,
                                ),
                              ),
                              InkWell(
                                onTap: () async {
                                  DateTime? temp = await pickDate();
                                  setState(
                                    () {
                                      endDate = temp;
                                    },
                                  );
                                },
                                child: button("Pick a date", 50, 100, 14),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),
                        InkWell(
                            onTap: () async {
                              if (!key.currentState!.validate()) {
                                return;
                              }
                              if (dropdownValue == null) {
                                showSnackBar(context, "Select your role");
                                return;
                              }

                              if (startDate == null) {
                                showSnackBar(context, "Select start date");
                                return;
                              }

                              if (!isActive! && endDate == null) {
                                showSnackBar(context, "Select end date");
                                return;
                              }
                              DateFormat dateFormat = DateFormat("yyyy-MM-dd");
                              String startDateOne =
                                  dateFormat.format(startDate!).toString();

                              int i = list!.indexOf(dropdownValue!) + 1;

                              Map<String, dynamic> data = {
                                "position": positionController.text,
                                "organization": organizationController.text,
                                "start_date": startDateOne,
                                "is_active": isActive.toString(),
                                "worker": id.toString(),
                                "organization_category": i.toString()
                              };

                              if (!isActive!) {
                                data.putIfAbsent(
                                    "end_date",
                                    () =>
                                        dateFormat.format(endDate!).toString());
                              }

                              await Provider.of<ExperienceProvider>(context,
                                      listen: false)
                                  .addData(token!, data)
                                  .then((value) {
                                if (Provider.of<ExperienceProvider>(context,
                                        listen: false)
                                    .isError!) {
                                  showSnackBar(context, "Something went wrong");
                                } else {
                                  showSnackBar(context, "uccessfully added",
                                      Colors.green.shade300);
                                  Navigator.of(context).pushNamed("/");
                                }
                              });
                            },
                            child: button("Submit"))
                      ],
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Future<DateTime?> pickDate() async {
    return showDatePicker(
        context: context,
        initialDate: DateTime(2023, 12),
        firstDate: DateTime(1900),
        lastDate: DateTime.now());
  }
}
