import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:term_project/providers/profile_provider.dart';
import 'package:term_project/screens/signup_for_employee.dart';

import '../providers/shared_pref_profider.dart';
import '../region.dart';

class EditWorkerPage extends StatefulWidget {
  static const routeName = "/editWorkerPage";
  const EditWorkerPage({super.key});

  @override
  State<EditWorkerPage> createState() => _EditWorkerPageState();
}

class _EditWorkerPageState extends State<EditWorkerPage> {
  final key = GlobalKey<FormState>();
  TextEditingController descriptionController = TextEditingController();
  TextEditingController telegramController = TextEditingController();
  TextEditingController contactController = TextEditingController();
  DateTime? birthDate;

  FocusNode nameNode = FocusNode();
  FocusNode contactNode = FocusNode();
  FocusNode passwordNode = FocusNode();

  List<Region> list = [
    Region("Tashkent", "Toshkent"),
    Region("Fergana", "Farg'ona"),
    Region("Andizhan", "Andijon"),
    Region("Samarkand", "Samarqand"),
    Region("Bukhara", "Buxoro"),
    Region("Navoi", "Navoiy"),
    Region("Karshi", "Qarshi"),
    Region("Nukus", "Nukus"),
    Region("Khorezm", "Xorazm"),
  ];

  List<String> languages = ["Uzbek", "Russian", "English"];

  Region? dropdownValue;
  String? language;

  String? token;

  bool? isLoading = false;

  String? character;
  int? id;

  List<String> statusList = ["active", "open", "closed"];

  @override
  void initState() {
    super.initState();
    token =
        Provider.of<SharedPreferencesProvider>(context, listen: false).token;
    id = Provider.of<ProfileProvider>(context, listen: false).data!["id"];
  }

  @override
  void didChangeDependencies() async {
    super.didChangeDependencies();
    setState(() {
      isLoading = true;
    });
    await Provider.of<ProfileProvider>(context, listen: false)
        .getWorkerPage(token!)
        .then(
      (value) {
        final data =
            Provider.of<ProfileProvider>(context, listen: false).workerData;
        descriptionController =
            TextEditingController(text: data!["description"]);
        telegramController = TextEditingController(text: data["telegram"]);
        contactController = TextEditingController(text: data["phone_number"]);
        birthDate = DateTime.parse(data["birthdate"]);
        character = data["status"];
        setState(() {
          language = data["native_language"];
          dropdownValue =
              list.firstWhere((element) => element.value == data["region"]);
        });
      },
    );
    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        width: 1200,
        height: 800,
        child: Column(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    IconButton(
                      style: const ButtonStyle(
                          overlayColor:
                              MaterialStatePropertyAll(Colors.transparent)),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: Icon(
                        Icons.arrow_back_ios,
                        color: Colors.deepPurple.shade300,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              flex: 11,
              child: isLoading!
                  ? const Center(
                      child: CircularProgressIndicator(),
                    )
                  : Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Form(
                            key: key,
                            child: SizedBox(
                              width: 400,
                              child: Column(
                                children: [
                                  TextFormField(
                                    validator: (value) {
                                      if (value!.isEmpty) {
                                        return "Please Fill Forms";
                                      }
                                      return null;
                                    },
                                    controller: descriptionController,
                                    decoration: InputDecoration(
                                      floatingLabelBehavior:
                                          FloatingLabelBehavior.never,
                                      enabledBorder: OutlineInputBorder(
                                          borderSide: BorderSide(
                                              color:
                                                  Colors.deepPurple.shade200),
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(20))),
                                      border: const OutlineInputBorder(
                                          borderSide:
                                              BorderSide(color: Colors.white),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(20))),
                                      label: Text(
                                        'Summary',
                                        style: TextStyle(
                                            color: Colors.deepPurple.shade200),
                                      ),
                                    ),
                                    onFieldSubmitted: (value) {
                                      FocusScope.of(context)
                                          .requestFocus(nameNode);
                                    },
                                  ),
                                  const SizedBox(height: 10),
                                  TextFormField(
                                    validator: (value) {
                                      if (value!.isEmpty) {
                                        return "Please Fill Forms";
                                      }
                                      return null;
                                    },
                                    focusNode: nameNode,
                                    controller: telegramController,
                                    decoration: InputDecoration(
                                      floatingLabelBehavior:
                                          FloatingLabelBehavior.never,
                                      enabledBorder: OutlineInputBorder(
                                          borderSide: BorderSide(
                                              color:
                                                  Colors.deepPurple.shade200),
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(20))),
                                      border: const OutlineInputBorder(
                                          borderSide:
                                              BorderSide(color: Colors.white),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(20))),
                                      label: Text(
                                        'Telegram Account',
                                        style: TextStyle(
                                            color: Colors.deepPurple.shade200),
                                      ),
                                    ),
                                    onFieldSubmitted: (value) {
                                      FocusScope.of(context)
                                          .requestFocus(contactNode);
                                    },
                                  ),
                                  const SizedBox(height: 10),
                                  TextFormField(
                                    validator: (value) {
                                      if (value!.isEmpty) {
                                        return "Please Fill Forms";
                                      }
                                      return null;
                                    },
                                    focusNode: contactNode,
                                    controller: contactController,
                                    decoration: InputDecoration(
                                      floatingLabelBehavior:
                                          FloatingLabelBehavior.never,
                                      enabledBorder: OutlineInputBorder(
                                          borderSide: BorderSide(
                                              color:
                                                  Colors.deepPurple.shade200),
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(20))),
                                      border: const OutlineInputBorder(
                                          borderSide:
                                              BorderSide(color: Colors.white),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(20))),
                                      label: Text(
                                        'Phone Number',
                                        style: TextStyle(
                                            color: Colors.deepPurple.shade200),
                                      ),
                                    ),
                                    onFieldSubmitted: (value) {
                                      FocusScope.of(context)
                                          .requestFocus(passwordNode);
                                    },
                                  ),
                                  const SizedBox(height: 20),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 20),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        birthDate == null
                                            ? Text("N/A",
                                                style: TextStyle(
                                                    color: Colors
                                                        .deepPurple.shade400))
                                            : Text(
                                                DateFormat.yMMMEd()
                                                    .format(birthDate!)
                                                    .toString(),
                                                style: TextStyle(
                                                    color: Colors
                                                        .deepPurple.shade400)),
                                        InkWell(
                                          onTap: () async {
                                            DateTime? temp =
                                                await showDatePicker(
                                                    context: context,
                                                    initialDate:
                                                        DateTime(2023, 12),
                                                    firstDate: DateTime(1900),
                                                    lastDate: DateTime(2030));
                                            setState(() {
                                              birthDate = temp;
                                            });
                                          },
                                          child: Container(
                                            height: 40,
                                            width: 70,
                                            alignment: Alignment.center,
                                            decoration: BoxDecoration(
                                                color:
                                                    Colors.deepPurple.shade200,
                                                borderRadius:
                                                    BorderRadius.circular(12)),
                                            child: const Text(
                                              "Select",
                                              style: TextStyle(
                                                  color: Colors.white),
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  SizedBox(
                                    height: 40,
                                    child: DropdownButton<Region>(
                                      focusColor: Colors.deepPurple.shade100,
                                      borderRadius: BorderRadius.circular(10),
                                      underline: const SizedBox(
                                        height: 0,
                                      ),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 20),
                                      isExpanded: true,
                                      icon: Icon(
                                        Icons.more_horiz,
                                        color: Colors.deepPurple.shade300,
                                      ),
                                      value: dropdownValue,
                                      onChanged: (Region? value) {
                                        setState(() {
                                          dropdownValue = value!;
                                        });
                                      },
                                      items: list.map<DropdownMenuItem<Region>>(
                                          (Region value) {
                                        return DropdownMenuItem<Region>(
                                            value: value,
                                            child: Text(value.name,
                                                style: TextStyle(
                                                    color: Colors
                                                        .deepPurple.shade400)));
                                      }).toList(),
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  SizedBox(
                                    height: 40,
                                    child: DropdownButton<String>(
                                      focusColor: Colors.deepPurple.shade200,
                                      borderRadius: BorderRadius.circular(10),
                                      underline: const SizedBox(
                                        height: 0,
                                      ),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 20),
                                      isExpanded: true,
                                      icon: Icon(
                                        Icons.more_horiz,
                                        color: Colors.deepPurple.shade300,
                                      ),
                                      value: language,
                                      onChanged: (String? value) {
                                        setState(() {
                                          language = value!;
                                        });
                                      },
                                      items: languages
                                          .map<DropdownMenuItem<String>>(
                                              (String value) {
                                        return DropdownMenuItem<String>(
                                            value: value,
                                            child: Text(value,
                                                style: TextStyle(
                                                    color: Colors
                                                        .deepPurple.shade400)));
                                      }).toList(),
                                    ),
                                  ),
                                  const SizedBox(height: 20),
                                  SizedBox(
                                    width: 600,
                                    height: 40,
                                    child: ListView.builder(
                                      scrollDirection: Axis.horizontal,
                                      itemCount: statusList.length,
                                      itemBuilder: (context, index) {
                                        return SizedBox(
                                          width: 130,
                                          child: Row(
                                            children: [
                                              Radio<String>(
                                                value: statusList[index],
                                                groupValue: character,
                                                onChanged: (String? value) {
                                                  setState(() {
                                                    character = value;
                                                  });
                                                },
                                              ),
                                              Text(statusList[index])
                                            ],
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                  const SizedBox(height: 20),
                                  InkWell(
                                    onTap: isLoading!
                                        ? null
                                        : () async {
                                            if (!key.currentState!.validate()) {
                                              return;
                                            }
                                            if (birthDate == null) {
                                              showSnackBar(context,
                                                  "Select your birthdate");
                                              return;
                                            }
                                            if (language == null) {
                                              showSnackBar(context,
                                                  "Select your language");
                                              return;
                                            }
                                            if (dropdownValue == null) {
                                              showSnackBar(context,
                                                  "Select your region");
                                              return;
                                            }
                                            DateFormat dateFormat =
                                                DateFormat("yyyy-MM-dd");
                                            String birthDateOne = dateFormat
                                                .format(birthDate!)
                                                .toString();

                                            Map<String, dynamic> data = {
                                              "description":
                                                  descriptionController.text,
                                              "birthdate": birthDateOne,
                                              "phone_number":
                                                  contactController.text,
                                              "telegram":
                                                  telegramController.text,
                                              "region": dropdownValue!.value,
                                              "native_language": language,
                                              "status": character,
                                              "user": id.toString()
                                            };
                                            if (token == null) {
                                              return;
                                            }
                                            await Provider.of<ProfileProvider>(
                                                    context,
                                                    listen: false)
                                                .editWorkerPage(token!, data)
                                                .then((value) {
                                              if (Provider.of<ProfileProvider>(
                                                      context,
                                                      listen: false)
                                                  .isError!) {
                                                showSnackBar(context,
                                                    "Something went wrong");
                                              } else {
                                                showSnackBar(
                                                    context,
                                                    "Successfully changed",
                                                    Colors.green.shade200);
                                              }
                                            });
                                          },
                                    child: Container(
                                      height: 50,
                                      width: 200,
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                          color: Colors.deepPurple.shade300,
                                          borderRadius:
                                              BorderRadius.circular(15)),
                                      child: isLoading!
                                          ? const CircularProgressIndicator()
                                          : const Text(
                                              "Submit",
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 24),
                                            ),
                                    ),
                                  )
                                ],
                              ),
                            ))
                      ],
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
