# Job search platform

1. main_gateway - gateway service - reverse proxy
