import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:term_project/providers/notifications_provider.dart';

import '../providers/shared_pref_profider.dart';

class NotificationRightWidget extends StatefulWidget {
  const NotificationRightWidget({super.key, required this.title});
  final String title;

  @override
  State<NotificationRightWidget> createState() =>
      _NotificationRightWidgetState();
}

class _NotificationRightWidgetState extends State<NotificationRightWidget> {
  bool? auth;
  String? token;
  List<dynamic>? data;

  @override
  void initState() {
    super.initState();
    auth = Provider.of<SharedPreferencesProvider>(context, listen: false).auth;
    token =
        Provider.of<SharedPreferencesProvider>(context, listen: false).token;
  }

  bool? isInit = true;
  bool? isLoading = false;

  @override
  void didChangeDependencies() async {
    super.didChangeDependencies();
    if (isInit!) {
      setState(() {
        isLoading = true;
      });
      await Provider.of<NotificationProvider>(context, listen: false)
          .getData(token!)
          .then((value) => data =
              Provider.of<NotificationProvider>(context, listen: false).data);
      setState(() {
        isLoading = false;
      });
      isInit = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: Container(
              width: 960,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              alignment: Alignment.center,
              color: Colors.deepPurple.shade100,
              child: Text(
                widget.title,
                style: const TextStyle(color: Colors.white, fontSize: 24),
              ),
            ),
          ),
          Expanded(
              flex: 11,
              child: !auth!
                  ? const Center(
                      child: Text("You should sign up"),
                    )
                  : isLoading!
                      ? const Center(
                          child: CircularProgressIndicator(),
                        )
                      : data!.isEmpty
                          ? const Center(child: Text("No Notifications"))
                          : ListView.builder(
                              itemCount: data!.length,
                              itemBuilder: (context, index) {
                                return Card(
                                  child: ListTile(
                                    title: Text(
                                      data![index]["text"] as String,
                                      style: TextStyle(
                                          fontSize: 20,
                                          color: Colors.deepPurple.shade400,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    subtitle: Text(
                                      DateFormat.yMEd().format(DateTime.parse(
                                          data![index]["created_at"])),
                                      style: TextStyle(
                                          fontSize: 12,
                                          color: Colors.grey.shade300),
                                    ),
                                  ),
                                );
                              },
                            ))
        ],
      ),
    );
  }
}
