import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:term_project/providers/profile_provider.dart';
import 'package:term_project/providers/sign_up_provider.dart';
import 'package:term_project/screens/signup_for_employee.dart';

import '../main.dart';
import '../providers/shared_pref_profider.dart';

class FillingExtraDetailsForExmployee extends StatefulWidget {
  static const routeName = "/filling-details-for-employee";
  const FillingExtraDetailsForExmployee({super.key});

  @override
  State<FillingExtraDetailsForExmployee> createState() =>
      _FillingExtraDetailsForExmployeeState();
}

class _FillingExtraDetailsForExmployeeState
    extends State<FillingExtraDetailsForExmployee> {
  final key = GlobalKey<FormState>();

  bool isLoading = false;

  String? token;

  TextEditingController companyNameController = TextEditingController();
  TextEditingController locationController = TextEditingController();
  TextEditingController descriptionContr = TextEditingController();

  FocusNode locationNode = FocusNode();
  FocusNode descriptionNode = FocusNode();

  @override
  void dispose() {
    super.dispose();
    companyNameController.dispose();
    locationController.dispose();
    locationNode.dispose();
    descriptionContr.dispose();
    descriptionNode.dispose();
  }

  @override
  void initState() {
    super.initState();
    setState(() {
      isLoading = true;
    });
    Future.delayed(Duration.zero, () async {
      try {
        await Provider.of<SharedPreferencesProvider>(context, listen: false)
            .fetchData();
      } finally {
        setState(() {
          isLoading = false;
        });
      }
    }).then((value) => {
          token = Provider.of<SharedPreferencesProvider>(context, listen: false)
              .token
        });
  }

  Map<String, dynamic>? modalData;

  bool isInit = true;
  int? vacancy;

  @override
  void didChangeDependencies() async {
    super.didChangeDependencies();
    if (isInit) {
      modalData =
          ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>?;
      if (modalData != null) {
        companyNameController =
            TextEditingController(text: modalData!["title"]);
        locationController =
            TextEditingController(text: modalData!["location"]);
        descriptionContr =
            TextEditingController(text: modalData!["description"]);
        vacancy = modalData!["vacancy_count"];
      }
      isInit = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        height: 800,
        width: 1200,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    IconButton(
                      style: const ButtonStyle(
                          overlayColor:
                              MaterialStatePropertyAll(Colors.transparent)),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: Icon(
                        Icons.arrow_back_ios,
                        color: Colors.deepPurple.shade300,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              flex: 11,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Form(
                    key: key,
                    child: SizedBox(
                      width: 400,
                      child: Column(
                        children: [
                          TextFormField(
                            validator: (value) {
                              if (value!.isEmpty) {
                                return "Please Fill Forms";
                              }
                              return null;
                            },
                            controller: companyNameController,
                            decoration: InputDecoration(
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.never,
                              enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Colors.deepPurple.shade200),
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(20))),
                              border: const OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.white),
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(20))),
                              label: Text(
                                'Company Name',
                                style: TextStyle(
                                    color: Colors.deepPurple.shade200),
                              ),
                            ),
                            onFieldSubmitted: (value) {
                              FocusScope.of(context).requestFocus(locationNode);
                            },
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            validator: (value) {
                              if (value!.isEmpty) {
                                return "Please Fill Forms";
                              }
                              return null;
                            },
                            controller: locationController,
                            focusNode: locationNode,
                            decoration: InputDecoration(
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.never,
                              enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Colors.deepPurple.shade200),
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(20))),
                              border: const OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.white),
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(20))),
                              label: Text(
                                'Location',
                                style: TextStyle(
                                    color: Colors.deepPurple.shade200),
                              ),
                            ),
                            onFieldSubmitted: (value) {
                              FocusScope.of(context)
                                  .requestFocus(descriptionNode);
                            },
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            validator: (value) {
                              if (value!.isEmpty) {
                                return "Please Fill Forms";
                              }
                              return null;
                            },
                            maxLines: 4,
                            controller: descriptionContr,
                            focusNode: descriptionNode,
                            decoration: InputDecoration(
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.never,
                              enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Colors.deepPurple.shade200),
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(20))),
                              border: const OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.white),
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(20))),
                              label: Text(
                                'Description',
                                style: TextStyle(
                                    color: Colors.deepPurple.shade200),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          InkWell(
                            onTap: isLoading
                                ? null
                                : () async {
                                    if (!key.currentState!.validate()) {
                                      return;
                                    }
                                    final data = {
                                      "title": companyNameController.text,
                                      "description": descriptionContr.text,
                                      "location": locationController.text
                                    };
                                    if (token == null) {
                                      showSnackBar(
                                          context, "Something went wrong");
                                      return;
                                    }
                                    setState(() {
                                      isLoading = true;
                                    });
                                    if (modalData == null) {
                                      await Provider.of<SignUpProvider>(context,
                                              listen: false)
                                          .addCompanyDetails(data, token!)
                                          .then((value) async {
                                        if (Provider.of<SignUpProvider>(context,
                                                listen: false)
                                            .isError!) {
                                          setState(() {
                                            isLoading = false;
                                          });
                                          showSnackBar(
                                              context, "Something went wrong");
                                        } else {
                                          setState(() {
                                            isLoading = false;
                                          });
                                          Navigator.of(context).pushNamed("/");
                                          final pref = await SharedPreferences
                                              .getInstance();
                                          pref.setBool("auth", true);
                                          pref.setString("userType",
                                              UserType.employer.name);
                                        }
                                      });
                                    } else {
                                      await Provider.of<ProfileProvider>(
                                              context,
                                              listen: false)
                                          .updateData(token!, data)
                                          .then((value) {
                                        if (Provider.of<ProfileProvider>(
                                                context,
                                                listen: false)
                                            .isError!) {
                                          showSnackBar(
                                              context, "Something went wrong");
                                        } else {
                                          showSnackBar(
                                              context,
                                              "Successfully Updated",
                                              Colors.green.shade400);
                                          Navigator.of(context).pop();
                                        }
                                      });
                                    }
                                  },
                            child: Container(
                              height: 50,
                              width: 200,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                  color: Colors.deepPurple.shade300,
                                  borderRadius: BorderRadius.circular(15)),
                              child: isLoading
                                  ? const CircularProgressIndicator()
                                  : const Text(
                                      "Submit",
                                      style: TextStyle(
                                          color: Colors.white, fontSize: 24),
                                    ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
