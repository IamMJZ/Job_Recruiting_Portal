package handlers

type Handlers struct {
}

func New() *Handlers {
	return &Handlers{}
}
