import 'package:flutter/material.dart';

class ChatRightWidget extends StatefulWidget {
  const ChatRightWidget({super.key, required this.title});
  final String title;

  @override
  State<ChatRightWidget> createState() => _ChatRightWidgetState();
}

class _ChatRightWidgetState extends State<ChatRightWidget> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}