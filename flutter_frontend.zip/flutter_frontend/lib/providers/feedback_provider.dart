import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:term_project/providers/profile_provider.dart';
import 'package:term_project/static_const.dart';
import 'package:http/http.dart' as http;

class FeedbackProvider extends ChangeNotifier {
  List<dynamic>? _data;
  List<dynamic>? get data => _data;

  bool? _isError;
  bool? get isError => _isError;

  String? _msg;
  String? get msg => _msg;

  Future fetchData(String token) async {
    _data = [];
    _isError = false;
    final url = Uri.parse('$staticUrl/api/worker/feedbacks');
    final response = await http.get(url, headers: getHeaders(token));

    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
    _data = json.decode(response.body);
  }

  Future fetchDataForEmployer(String token) async {
    _data = [];
    _isError = false;
    final url = Uri.parse('$staticUrl/api/company/feedbacks');
    final response = await http.get(url, headers: getHeaders(token));
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
    _data = json.decode(response.body);
  }

  Future addFeedback(String token, Map<String, dynamic> data) async {
    _isError = false;
    final url = Uri.parse('$staticUrl/api/worker/feedback/create');
    final response =
        await http.post(url, headers: getHeaders(token), body: data);
    Map<String, dynamic> theData = json.decode(response.body);
    if (theData.keys.contains('non_field_errors')) {
      _isError = true;
      _msg = theData['non_field_errors'][0];
      return;
    }

    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
  }

  Future addFeedbackGeneral(String text, String token) async {
    _isError = false;
    final url = Uri.parse('$staticUrl/api/feedback/');
    final response =
        await http.post(url, headers: getHeaders(token), body: {'text': text});
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
  }

  Future addFeedbackForWorker(Map<String, dynamic> data, String token) async {
    _isError = false;
    _msg = null;
    final url = Uri.parse('$staticUrl/api/company/feedback/create');
    final response =
        await http.post(url, headers: getHeaders(token), body: data);
    Map<String, dynamic> theData = json.decode(response.body);
    if (theData.keys.contains('non_field_errors')) {
      _isError = true;
      _msg = theData['non_field_errors'][0];
      return;
    }
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
  }
}
