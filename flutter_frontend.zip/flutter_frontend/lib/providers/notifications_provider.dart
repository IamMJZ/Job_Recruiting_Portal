import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:term_project/providers/profile_provider.dart';
import 'package:term_project/static_const.dart';
import 'package:http/http.dart' as http;

class NotificationProvider extends ChangeNotifier {
  List<dynamic>? _data;
  List<dynamic>? get data => _data;

  bool? _isError;
  bool? get isError => _isError;

  Future getData(String token) async {
    _isError = false;
    _data = [];
    final url = Uri.parse("$staticUrl/api/worker/notifications/");
    final response = await http.get(url, headers: getHeaders(token));
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
    _data = json.decode(response.body);
  }
}
