cd ./main_gateway
go run cmd/main_gateway/main.go 


# cd ..
# cd employer
# source ./bin/activate
# uvicorn main:app --reload --port 8000 &
# cd ..
# cd job_seeker
# source ./bin/activate
# uvicorn main:app --reload --port 8001 &