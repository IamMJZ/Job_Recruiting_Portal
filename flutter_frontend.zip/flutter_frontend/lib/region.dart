class Region{
  String name;
  String value;
  Region(this.name, this.value);
}