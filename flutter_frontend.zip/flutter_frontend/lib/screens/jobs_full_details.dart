import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:term_project/main.dart';
import 'package:term_project/providers/company_provider.dart';
import 'package:term_project/providers/feedback_provider.dart';
import 'package:term_project/providers/posted_job_provider.dart';
import 'package:term_project/providers/shared_pref_profider.dart';
import 'package:term_project/screens/add_some_details_for_worker.dart';
import 'package:term_project/screens/signup_for_employee.dart';

import '../providers/jobs_provider.dart';

class JobFullDetailsScreen extends StatefulWidget {
  static const routeName = "/job-full";
  const JobFullDetailsScreen({super.key});

  @override
  State<JobFullDetailsScreen> createState() => _JobFullDetailsScreenState();
}

class _JobFullDetailsScreenState extends State<JobFullDetailsScreen> {
  bool? isLoading = false;

  bool isInit = true;
  int randomNum = 0;

  String? token;
  UserType? userType;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (isInit) {
      var random = Random();
      randomNum = random.nextInt(3);
      token = Provider.of<SharedPreferencesProvider>(context).token;
      userType = Provider.of<SharedPreferencesProvider>(context).userType;
    }
    setState(() {
      isInit = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    List<String>? images = [
      "assets/images/image.png",
      "assets/images/imageOne.png",
      "assets/images/imageTwo.png"
    ];

    final data = ModalRoute.of(context)!.settings.arguments;

    Job job = (data as Map<String, dynamic>)["job"];
    return Scaffold(
      backgroundColor: Colors.white,
      body: SizedBox(
        height: 800,
        width: 1200,
        child: Column(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      style: const ButtonStyle(
                          overlayColor:
                              MaterialStatePropertyAll(Colors.transparent)),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: Icon(
                        Icons.arrow_back_ios,
                        color: Colors.deepPurple.shade300,
                      ),
                    ),
                    Text(
                      job.title!,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 30),
                    ),
                    if (userType == UserType.employer) ...{
                      IconButton(
                        onPressed: () async {
                          await Provider.of<PostedJobsProvider>(context,
                                  listen: false)
                              .delete(token!, job.id)
                              .then((value) {
                            if (Provider.of<PostedJobsProvider>(context,
                                    listen: false)
                                .isError!) {
                              showSnackBar(context, "Something went wrong");
                            } else {
                              showSnackBar(context, "Job Deleted Successfully",
                                  Colors.green.shade300);
                              Navigator.of(context).pushNamed("/");
                            }
                          });
                        },
                        icon: const Icon(
                          Icons.delete,
                          color: Colors.red,
                          size: 30,
                        ),
                      ),
                    } else ...{
                      const SizedBox()
                    }
                  ],
                ),
              ),
            ),
            Expanded(
                flex: 11,
                child: SizedBox(
                  width: 600,
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 20),
                        Image.asset(
                          images[randomNum],
                          height: 400,
                          fit: BoxFit.cover,
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            const Text(
                              "Employement Type and Schedule: ",
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(width: 10),
                            Text(
                              job.employementTypeAndSchedule!,
                            )
                          ],
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            const Text(
                              "Salary: ",
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(width: 10),
                            Text(
                              "${job.salary!} \$",
                            )
                          ],
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            InkWell(
                              onTap: isLoading!
                                  ? null
                                  : () async {
                                      setState(() {
                                        isLoading = true;
                                      });
                                      await Provider.of<CompanyProvider>(
                                              context,
                                              listen: false)
                                          .fetchAllCompanies(job.companyId)
                                          .then((value) {
                                        final data =
                                            Provider.of<CompanyProvider>(
                                                    context,
                                                    listen: false)
                                                .data;
                                        setState(() {
                                          isLoading = false;
                                        });
                                        if (!isLoading!) {
                                          showDialog(
                                            context: context,
                                            builder: (context) {
                                              return AlertDialog(
                                                contentPadding:
                                                    const EdgeInsets.all(0),
                                                content: Container(
                                                  padding: const EdgeInsets
                                                      .symmetric(
                                                      vertical: 40,
                                                      horizontal: 10),
                                                  alignment: Alignment.center,
                                                  height: 400,
                                                  width: 302,
                                                  child: Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      Text(
                                                        data!["title"],
                                                        style: TextStyle(
                                                            color: Colors
                                                                .deepPurple
                                                                .shade400,
                                                            fontSize: 24,
                                                            fontWeight:
                                                                FontWeight
                                                                    .bold),
                                                      ),
                                                      const SizedBox(
                                                          height: 50),
                                                      Text(
                                                        data["description"],
                                                      ),
                                                      const SizedBox(
                                                          height: 10),
                                                      Text(
                                                        data["region"],
                                                      ),
                                                      const SizedBox(
                                                          height: 15),
                                                      InkWell(
                                                        onTap: () {
                                                          List<Job> list =
                                                              Provider.of<CompanyProvider>(
                                                                      context,
                                                                      listen:
                                                                          false)
                                                                  .jobList!;
                                                          showDialogForCompanyVacancies(
                                                              list);
                                                        },
                                                        child: Text(
                                                          "View All Vacancies of the company",
                                                          style: TextStyle(
                                                              decoration:
                                                                  TextDecoration
                                                                      .underline,
                                                              color: Colors
                                                                  .deepPurple
                                                                  .shade400),
                                                        ),
                                                      ),
                                                      const SizedBox(
                                                          height: 20),
                                                      if (userType ==
                                                          UserType
                                                              .employee) ...{
                                                        InkWell(
                                                            onTap: () async {
                                                              showDialog(
                                                                context:
                                                                    context,
                                                                builder:
                                                                    (context) {
                                                                  TextEditingController
                                                                      controller =
                                                                      TextEditingController();
                                                                  int? rank;

                                                                  return AlertDialog(
                                                                      contentPadding:
                                                                          const EdgeInsets
                                                                              .all(
                                                                              0),
                                                                      content: StatefulBuilder(builder:
                                                                          (context,
                                                                              setState) {
                                                                        return Container(
                                                                            padding:
                                                                                const EdgeInsets.symmetric(vertical: 40, horizontal: 10),
                                                                            alignment: Alignment.center,
                                                                            height: 250,
                                                                            width: 302,
                                                                            child: Column(
                                                                              mainAxisAlignment: MainAxisAlignment.center,
                                                                              children: [
                                                                                TextFormField(
                                                                                  validator: (value) {
                                                                                    if (value!.isEmpty) {
                                                                                      return "Please Fill Forms";
                                                                                    }

                                                                                    return null;
                                                                                  },
                                                                                  controller: controller,
                                                                                  decoration: InputDecoration(
                                                                                    floatingLabelBehavior: FloatingLabelBehavior.never,
                                                                                    enabledBorder: OutlineInputBorder(
                                                                                      borderSide: BorderSide(
                                                                                        color: Colors.deepPurple.shade200,
                                                                                      ),
                                                                                      borderRadius: const BorderRadius.all(
                                                                                        Radius.circular(20),
                                                                                      ),
                                                                                    ),
                                                                                    border: OutlineInputBorder(
                                                                                      borderSide: BorderSide(
                                                                                        color: Colors.deepPurple.shade200,
                                                                                      ),
                                                                                      borderRadius: const BorderRadius.all(
                                                                                        Radius.circular(20),
                                                                                      ),
                                                                                    ),
                                                                                    label: Text(
                                                                                      'Feedback',
                                                                                      style: TextStyle(
                                                                                        color: Colors.deepPurple.shade200,
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                                const SizedBox(height: 10),
                                                                                Row(
                                                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                                  children: [
                                                                                    for (int i = 1; i <= 5; i++) ...{
                                                                                      InkWell(
                                                                                        onTap: () {
                                                                                          setState(() {
                                                                                            rank = i;
                                                                                          });
                                                                                        },
                                                                                        child: button(i.toString(), 20, 20, 12, rank == i ? Colors.green.shade300 : Colors.deepPurple.shade300),
                                                                                      ),
                                                                                    }
                                                                                  ],
                                                                                ),
                                                                                const SizedBox(height: 10),
                                                                                InkWell(
                                                                                  onTap: () async {
                                                                                    if (controller.text.trim().isNotEmpty && rank != null) {
                                                                                      await Provider.of<FeedbackProvider>(context, listen: false).addFeedback(
                                                                                        token!,
                                                                                        {
                                                                                          "text": controller.text,
                                                                                          "rating": rank.toString(),
                                                                                          "company": data["id"].toString()
                                                                                        },
                                                                                      ).then((value) {
                                                                                        if (Provider.of<FeedbackProvider>(context, listen: false).isError!) {
                                                                                          if (Provider.of<FeedbackProvider>(context, listen: false).msg == null) {
                                                                                            showSnackBar(context, "Something went wrong");
                                                                                          } else {
                                                                                            showSnackBar(context, Provider.of<FeedbackProvider>(context, listen: false).msg!);
                                                                                          }
                                                                                        } else {
                                                                                          showSnackBar(context, "Feedback Added Successfully", Colors.green.shade300);
                                                                                          Navigator.of(context).pop();
                                                                                        }
                                                                                      });
                                                                                    }
                                                                                  },
                                                                                  child: button("Submit"),
                                                                                )
                                                                              ],
                                                                            ));
                                                                      }));
                                                                },
                                                              );
                                                            },
                                                            child: button(
                                                                "Give Feedback"))
                                                      }
                                                    ],
                                                  ),
                                                ),
                                              );
                                            },
                                          );
                                        }
                                      });
                                    },
                              child: Row(
                                children: [
                                  const Text(
                                    "Company Name: ",
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        decoration: TextDecoration.underline),
                                  ),
                                  if (isLoading!) ...{
                                    const CircularProgressIndicator(
                                      value: 2,
                                    )
                                  }
                                ],
                              ),
                            ),
                            const SizedBox(width: 10),
                            Text(
                              job.companyName!,
                            )
                          ],
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            const Text(
                              "Location: ",
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(width: 10),
                            Text(
                              job.region.toString(),
                            )
                          ],
                        ),
                        const SizedBox(height: 10),
                        const Text(
                          "Description: ",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 5),
                        Wrap(
                          children: [
                            const SizedBox(height: 30),
                            Text(
                              job.description.toString(),
                            )
                          ],
                        ),
                        const SizedBox(height: 50)
                      ],
                    ),
                  ),
                ))
          ],
        ),
      ),
    );
  }

  void showDialogForCompanyVacancies(List<Job> list) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          contentPadding: const EdgeInsets.all(0),
          content: Container(
            padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 10),
            alignment: Alignment.center,
            height: 600,
            width: 400,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Company Vacancies",
                  style: TextStyle(
                      color: Colors.deepPurple.shade400,
                      fontSize: 24,
                      fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Expanded(
                  child: ListView.builder(
                    itemCount: list.length,
                    itemBuilder: (context, index) {
                      return Container(
                        padding: const EdgeInsets.all(10),
                        margin: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.deepPurple),
                            borderRadius: BorderRadius.circular(10)),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              list[index].isActive
                                  ? list[index].title!
                                  : "${list[index].title!}Is not Active",
                              style: TextStyle(
                                  color: Colors.deepPurple.shade400,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              "Description: ${list[index].description!}",
                              maxLines: 3,
                            ),
                            const SizedBox(height: 2),
                            Text(
                              "Location: ${list[index].region!}",
                            ),
                            const SizedBox(height: 2),
                            Text(
                              "salary: ${list[index].salary!}\$",
                            ),
                            const SizedBox(height: 2),
                            Text(
                              list[index].employementTypeAndSchedule!,
                            ),
                            const SizedBox(height: 2),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
