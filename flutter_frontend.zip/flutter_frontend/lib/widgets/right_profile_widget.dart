import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:term_project/main.dart';
import 'package:term_project/providers/feedback_provider.dart';
import 'package:term_project/providers/profile_provider.dart';
import 'package:term_project/providers/shared_pref_profider.dart';
import 'package:term_project/screens/add_some_details_for_worker.dart';
import 'package:term_project/screens/edit_worker_page.dart';
import 'package:term_project/screens/filling_extra_details_for_employee.dart';
import 'package:term_project/screens/home_page.dart';
import 'package:term_project/screens/interviews_screen.dart';
import 'package:term_project/screens/signup_for_employee.dart';

class RightProfileWidget extends StatefulWidget {
  const RightProfileWidget({super.key, required this.title});
  final String title;
  @override
  State<RightProfileWidget> createState() => _RightProfileWidgetState();
}

class _RightProfileWidgetState extends State<RightProfileWidget> {
  bool isLoading = false;
  Map<String, dynamic>? userData;
  bool auth = false;
  UserType? userType;
  String? token;

  TextEditingController feedbackController = TextEditingController();

  @override
  void initState() {
    super.initState();
    setState(() {
      auth =
          Provider.of<SharedPreferencesProvider>(context, listen: false).auth!;
      userType = Provider.of<SharedPreferencesProvider>(context, listen: false)
          .userType;
      token =
          Provider.of<SharedPreferencesProvider>(context, listen: false).token;
    });
  }

  @override
  void didChangeDependencies() async {
    super.didChangeDependencies();
    setState(() {
      isLoading = true;
    });
    try {
      if (token != null) {
        await Provider.of<ProfileProvider>(context, listen: false)
            .fetchDataForEmployee(token!, userType!)
            .then((value) {
          userData = Provider.of<ProfileProvider>(context, listen: false).data;
        });
      }
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return isLoading
        ? const Center(
            child: CircularProgressIndicator(),
          )
        : Column(
            children: [
              Expanded(
                child: Container(
                  width: 960,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  alignment: Alignment.center,
                  color: Colors.deepPurple.shade100,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        widget.title,
                        style:
                            const TextStyle(color: Colors.white, fontSize: 24),
                      ),
                      InkWell(
                        onTap: auth
                            ? null
                            : () {
                                showDialogForLogin(
                                  context,
                                );
                              },
                        child: Container(
                          margin: const EdgeInsets.all(15),
                          padding: const EdgeInsets.only(left: 3),
                          width: 100,
                          decoration: BoxDecoration(
                              color: Colors.deepPurple.shade300,
                              borderRadius: BorderRadius.circular(20)),
                          child: Row(
                            children: [
                              Container(
                                width: 30,
                                padding: const EdgeInsets.all(5),
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.deepPurple.shade400,
                                ),
                                child: Image.asset(
                                  "assets/images/user.png",
                                  color: Colors.white,
                                  fit: BoxFit.cover,
                                ),
                              ),
                              const SizedBox(width: 3),
                              SizedBox(
                                width: 64,
                                child: Text(
                                  auth
                                      ? isLoading
                                          ? "Loading..."
                                          : userData!["email"]
                                      : "Sign Up",
                                  maxLines: 1,
                                  style: const TextStyle(color: Colors.white),
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Expanded(
                flex: 11,
                child: isLoading
                    ? const Center(
                        child: CircularProgressIndicator(),
                      )
                    : !auth
                        ? const Center(
                            child: Text("You should sign up"),
                          )
                        : Container(
                            width: 960,
                            alignment: Alignment.center,
                            color: Theme.of(context).colorScheme.background,
                            child: SizedBox(
                              width: 400,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  TextFormField(
                                    controller: feedbackController,
                                    decoration: InputDecoration(
                                      floatingLabelBehavior:
                                          FloatingLabelBehavior.never,
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          color: Colors.deepPurple.shade200,
                                        ),
                                        borderRadius: const BorderRadius.all(
                                          Radius.circular(20),
                                        ),
                                      ),
                                      border: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          color: Colors.deepPurple.shade200,
                                        ),
                                        borderRadius: const BorderRadius.all(
                                          Radius.circular(20),
                                        ),
                                      ),
                                      label: Text(
                                        'Write Feedback',
                                        style: TextStyle(
                                          color: Colors.deepPurple.shade200,
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      InkWell(
                                          onTap: () async {
                                            await Provider.of<FeedbackProvider>(
                                                    context,
                                                    listen: false)
                                                .addFeedbackGeneral(
                                                    feedbackController.text,
                                                    token!)
                                                .then((value) {
                                              if (Provider.of<FeedbackProvider>(
                                                      context,
                                                      listen: false)
                                                  .isError!) {
                                                showSnackBar(context,
                                                    "Something went wrong");
                                              } else {
                                                showSnackBar(
                                                    context,
                                                    "Feedback added Successfully",
                                                    Colors.green.shade300);
                                                feedbackController.clear();
                                              }
                                            });
                                          },
                                          child: button("Send", 40, 120, 16)),
                                    ],
                                  ),
                                  space(),
                                  details(userData!["full_name"], "Full Name"),
                                  space(),
                                  details(userData!["email"], "Email"),
                                  space(),
                                  const SizedBox(height: 20),
                                  if (userData!["is_company"]) ...{
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        const Text("Your page:"),
                                        InkWell(
                                          onTap: () async {
                                            await Provider.of<ProfileProvider>(
                                                    context,
                                                    listen: false)
                                                .fetchDataForEmployer(token!)
                                                .then((value) {
                                              Navigator.of(context).pushNamed(
                                                  FillingExtraDetailsForExmployee
                                                      .routeName,
                                                  arguments: Provider.of<
                                                              ProfileProvider>(
                                                          context,
                                                          listen: false)
                                                      .data);
                                            });
                                          },
                                          child: Container(
                                            height: 35,
                                            width: 120,
                                            alignment: Alignment.center,
                                            decoration: BoxDecoration(
                                                color:
                                                    Colors.deepPurple.shade300,
                                                borderRadius:
                                                    BorderRadius.circular(15)),
                                            child: isLoading
                                                ? const CircularProgressIndicator()
                                                : const Text(
                                                    "Edit",
                                                    style: TextStyle(
                                                      color: Colors.white,
                                                      fontSize: 20,
                                                    ),
                                                  ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 20),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        const Text("Scheduled Interviews:"),
                                        InkWell(
                                          onTap: () async {
                                            Navigator.of(context).pushNamed(InterviewsScreen.routeName);
                                          },
                                          child: Container(
                                            height: 35,
                                            width: 120,
                                            alignment: Alignment.center,
                                            decoration: BoxDecoration(
                                                color:
                                                    Colors.deepPurple.shade300,
                                                borderRadius:
                                                    BorderRadius.circular(15)),
                                            child: isLoading
                                                ? const CircularProgressIndicator()
                                                : const Text(
                                                    "Edit",
                                                    style: TextStyle(
                                                      color: Colors.white,
                                                      fontSize: 20,
                                                    ),
                                                  ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  },
                                  if (userData!["is_worker"]) ...{
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        const Text("Your page:"),
                                        InkWell(
                                          onTap: () {
                                            Navigator.of(context).pushNamed(
                                                EditWorkerPage.routeName);
                                          },
                                          child: Container(
                                            height: 35,
                                            width: 120,
                                            alignment: Alignment.center,
                                            decoration: BoxDecoration(
                                                color:
                                                    Colors.deepPurple.shade300,
                                                borderRadius:
                                                    BorderRadius.circular(15)),
                                            child: isLoading
                                                ? const CircularProgressIndicator()
                                                : const Text(
                                                    "Edit",
                                                    style: TextStyle(
                                                      color: Colors.white,
                                                      fontSize: 20,
                                                    ),
                                                  ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 20),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        const Text("Add Some details:"),
                                        InkWell(
                                          onTap: () {
                                            Navigator.of(context).pushNamed(
                                                AddSomeDetailesForWorker
                                                    .routeName);
                                          },
                                          child: Container(
                                            height: 35,
                                            width: 120,
                                            alignment: Alignment.center,
                                            decoration: BoxDecoration(
                                                color:
                                                    Colors.deepPurple.shade300,
                                                borderRadius:
                                                    BorderRadius.circular(15)),
                                            child: isLoading
                                                ? const CircularProgressIndicator()
                                                : const Text(
                                                    "Add",
                                                    style: TextStyle(
                                                      color: Colors.white,
                                                      fontSize: 20,
                                                    ),
                                                  ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 19.9),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        const Text("Interviews:"),
                                        InkWell(
                                          onTap: () {
                                            Navigator.of(context).pushNamed(
                                                InterviewsScreen.routeName);
                                          },
                                          child: Container(
                                            height: 35,
                                            width: 120,
                                            alignment: Alignment.center,
                                            decoration: BoxDecoration(
                                                color:
                                                    Colors.deepPurple.shade300,
                                                borderRadius:
                                                    BorderRadius.circular(15)),
                                            child: isLoading
                                                ? const CircularProgressIndicator()
                                                : const Text(
                                                    "Go to Page",
                                                    style: TextStyle(
                                                      color: Colors.white,
                                                      fontSize: 20,
                                                    ),
                                                  ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  },
                                  const SizedBox(height: 19.9),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Text("Feedbacs To You:"),
                                      InkWell(
                                        onTap: () async {
                                          if (userType == UserType.employee) {
                                            await Provider.of<FeedbackProvider>(
                                                    context,
                                                    listen: false)
                                                .fetchData(token!)
                                                .then((value) {
                                              shoDialogForFeedback(
                                                  context,
                                                  Provider.of<FeedbackProvider>(
                                                          context,
                                                          listen: false)
                                                      .data!);
                                            });
                                          } else {
                                            await Provider.of<FeedbackProvider>(
                                                    context,
                                                    listen: false)
                                                .fetchDataForEmployer(token!)
                                                .then((value) {
                                              shoDialogForFeedback(
                                                  context,
                                                  Provider.of<FeedbackProvider>(
                                                          context,
                                                          listen: false)
                                                      .data!);
                                            });
                                          }
                                        },
                                        child: Container(
                                          height: 35,
                                          width: 120,
                                          alignment: Alignment.center,
                                          decoration: BoxDecoration(
                                              color: Colors.deepPurple.shade300,
                                              borderRadius:
                                                  BorderRadius.circular(15)),
                                          child: isLoading
                                              ? const CircularProgressIndicator()
                                              : const Text(
                                                  "Go to Page",
                                                  style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 20,
                                                  ),
                                                ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
              ),
            ],
          );
  }
}

void shoDialogForFeedback(BuildContext context, List<dynamic> data) {
  showDialog(
    context: context,
    builder: (context) => AlertDialog(
      backgroundColor: Theme.of(context).colorScheme.background,
      contentPadding: const EdgeInsets.all(0),
      content: Container(
        width: 300,
        height: 400,
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
        child: Column(
          children: [
            Expanded(
                child: Text(
              "Feedbacks",
              style: TextStyle(color: Colors.deepPurple.shade400, fontSize: 24),
            )),
            Expanded(
              flex: 8,
              child: ListView.builder(
                itemCount: data.length,
                itemBuilder: (context, index) {
                  return Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.deepPurple.shade100,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          data[index]["text"],
                        ),
                        Text(
                          data[index]["rating"].toString(),
                          style: const TextStyle(
                              color: Colors.green, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

Widget space() {
  return Column(
    children: [
      const SizedBox(height: 10),
      Divider(
        color: Colors.grey.shade300,
        height: 1,
      ),
      const SizedBox(height: 10),
    ],
  );
}

Widget details(String textOne, String text) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text("$text:"),
      Text(textOne,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
    ],
  );
}
