import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:term_project/providers/language_provider.dart';
import 'package:term_project/screens/signup_for_employee.dart';

import '../providers/profile_provider.dart';
import '../providers/shared_pref_profider.dart';
import 'add_some_details_for_worker.dart';

class AddNewLanguage extends StatefulWidget {
  static const routeName = "/add-new-language";
  const AddNewLanguage({super.key});

  @override
  State<AddNewLanguage> createState() => _AddNewLanguageState();
}

class _AddNewLanguageState extends State<AddNewLanguage> {
  String? language;

  List<String> list = ["Uzbek", "Russian", "English"];

  String? languageLevel;

  List<String> languages = ["A1", "A2", "B1", "B2", "C1", "C2"];

  String? token;
  int? id;

  bool? isLoading = false;

  Map<String, dynamic>? data;

  bool isInit = true;

  @override
  void initState() {
    super.initState();
    token =
        Provider.of<SharedPreferencesProvider>(context, listen: false).token;
  }

  @override
  void didChangeDependencies() async {
    super.didChangeDependencies();
    if (isInit) {
      setState(() {
        isLoading = true;
      });
      data =
          ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>?;

      if (data != null) {
        language = data!["language"];
        languageLevel = data!["level"];
      }
      Map<String, dynamic>? dataOne;
      try {
        await Provider.of<ProfileProvider>(context, listen: false)
            .getWorkerPage(token!)
            .then((value) =>
                Provider.of<ProfileProvider>(context, listen: false)
                    .workerData);
        setState(() {
          isLoading = false;
        });
      } finally {
        id = dataOne!["id"];
      }
    }
    setState(() {
      isInit = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        width: 1200,
        height: 800,
        child: Column(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      style: const ButtonStyle(
                          overlayColor:
                              MaterialStatePropertyAll(Colors.transparent)),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: Icon(
                        Icons.arrow_back_ios,
                        color: Colors.deepPurple.shade300,
                      ),
                    ),
                    Text(
                      "Add new language",
                      style: TextStyle(
                        color: Colors.deepPurple.shade400,
                        fontSize: 24,
                      ),
                    ),
                    const SizedBox()
                  ],
                ),
              ),
            ),
            Expanded(
              flex: 11,
              child: isLoading!
                  ? const Center(
                      child: CircularProgressIndicator(),
                    )
                  : Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        const SizedBox(height: 100),
                        Container(
                          height: 40,
                          width: 500,
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.deepPurple),
                              borderRadius: BorderRadius.circular(10)),
                          child: DropdownButton<String>(
                            hint: Text(
                              "Select Language",
                              style: TextStyle(
                                color: Colors.deepPurple.shade400,
                                fontSize: 20,
                              ),
                            ),
                            focusColor: Colors.deepPurple.shade100,
                            borderRadius: BorderRadius.circular(10),
                            underline: const SizedBox(
                              height: 0,
                            ),
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            isExpanded: true,
                            icon: Icon(
                              Icons.more_horiz,
                              color: Colors.deepPurple.shade300,
                            ),
                            value: language,
                            onChanged: (String? value) {
                              setState(() {
                                language = value!;
                              });
                            },
                            items: list
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value,
                                      style: TextStyle(
                                          color: Colors.deepPurple.shade400)));
                            }).toList(),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Container(
                          height: 40,
                          width: 400,
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.deepPurple),
                              borderRadius: BorderRadius.circular(10)),
                          child: DropdownButton<String>(
                            focusColor: Colors.deepPurple.shade200,
                            borderRadius: BorderRadius.circular(10),
                            underline: const SizedBox(
                              height: 0,
                            ),
                            hint: Text(
                              "Select Language Level",
                              style: TextStyle(
                                color: Colors.deepPurple.shade400,
                                fontSize: 20,
                              ),
                            ),
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            isExpanded: true,
                            icon: Icon(
                              Icons.more_horiz,
                              color: Colors.deepPurple.shade300,
                            ),
                            value: languageLevel,
                            onChanged: (String? value) {
                              setState(() {
                                languageLevel = value!;
                              });
                            },
                            items: languages
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value,
                                      style: TextStyle(
                                          color: Colors.deepPurple.shade400)));
                            }).toList(),
                          ),
                        ),
                        const SizedBox(height: 20),
                        InkWell(
                          onTap: () async {
                            if (language == null) {
                              showSnackBar(context, "Select Language");
                              return;
                            }
                            if (languageLevel == null) {
                              showSnackBar(context, "Select Language Level");
                              return;
                            }
                            Map<String, dynamic> theData = {
                              "language": language,
                              "level": languageLevel!.substring(0, 2),
                              "worker": id.toString()
                            };
                            if (data == null) {
                              await Provider.of<LanguageProvider>(context,
                                      listen: false)
                                  .addData(token!, theData);
                            } else {
                              await Provider.of<LanguageProvider>(context,
                                      listen: false)
                                  .updateData(token!, theData, data!["id"]!)
                                  .then((value) {
                                if (Provider.of<LanguageProvider>(context,
                                        listen: false)
                                    .isError!) {
                                  showSnackBar(context, "Something went wrong");
                                } else {
                                  showSnackBar(context, "Successfully change",
                                      Colors.green.shade300);
                                  Navigator.of(context).pushNamed("/");
                                }
                              });
                            }
                          },
                          child: button("Submit"),
                        ),
                      ],
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
