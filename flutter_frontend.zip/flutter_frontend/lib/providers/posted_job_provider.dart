import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:term_project/providers/jobs_provider.dart';
import 'package:term_project/providers/profile_provider.dart';
import 'package:term_project/static_const.dart';
import 'package:http/http.dart' as http;

class PostedJobsProvider extends ChangeNotifier {
  List<Job>? _postedJobsList;
  List<Job>? get postedJobList => _postedJobsList;

  bool? _isError;
  bool? get isError => _isError;

  Future fetchData(String token) async {
    final url = Uri.parse('$staticUrl/api/company/vacancy');
    final response = await http.get(url, headers: getHeaders(token));
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
    List<dynamic> theJobs = json.decode(response.body);
    _postedJobsList = List.empty(growable: true);
    for (int i = 0; i < theJobs.length; i++) {
      String employementTypeAndSchedule = "";
      if (theJobs[i]["is_remote"]) {
        employementTypeAndSchedule = "Remote";
      } else {
        employementTypeAndSchedule = "On-Site";
      }
      _postedJobsList!.add(Job(
          isActive: theJobs[i]["is_active"] as bool,
          id: theJobs[i]["id"] as int,
          title: "${theJobs[i]["title"]}/${theJobs[i]["job"]["name"]}",
          companyId: theJobs[i]["company"]["id"] as int,
          companyName: theJobs[i]["company"]["title"] as String?,
          employementTypeAndSchedule: employementTypeAndSchedule,
          salary: "${theJobs[i]["min_salary"]}~${theJobs[i]["max_salary"]}",
          isFavorite: theJobs[i]["created_at"] as bool?,
          description: theJobs[i]["description"] as String?,
          region: theJobs[i]["region"] as String?));
    }
  }

  Future addData(String token, Map<String, dynamic> data) async {
    _isError = false;
    final url = Uri.parse('$staticUrl/api/company/vacancy');
    final response =
        await http.post(url, headers: getHeaders(token), body: data);
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
  }

  Future updateData(String token, Map<String, dynamic> data, int id) async {
    _isError = false;
    final url = Uri.parse('$staticUrl/api/company/vacancy/$id/');
    final response =
        await http.put(url, headers: getHeaders(token), body: data);
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
  }

  Future delete(String token, int id) async {
    _isError = false;
    final url = Uri.parse('$staticUrl/api/company/vacancy/$id/');
    final response = await http.delete(url, headers: getHeaders(token));
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
    postedJobList!.remove(postedJobList!.firstWhere((element) => element.id == id));
    notifyListeners();
  }
}
