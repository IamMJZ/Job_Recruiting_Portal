import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:term_project/providers/shared_pref_profider.dart';
import 'package:term_project/providers/sign_up_provider.dart';
import 'package:term_project/region.dart';

import '../main.dart';

class SignUpForEmployer extends StatefulWidget {
  static const String routeName = "/singup-for-employer";
  const SignUpForEmployer({super.key});

  @override
  State<SignUpForEmployer> createState() => _SignUpForEmployerState();
}

List<Region> list = [
  Region("Tashkent", "Toshkent"),
  Region("Fergana", "Farg'ona"),
  Region("Andizhan", "Andijon"),
  Region("Samarkand", "Samarqand"),
  Region("Bukhara", "Buxoro"),
  Region("Navoi", "Navoiy"),
  Region("Karshi", "Qarshi"),
  Region("Nukus", "Nukus"),
  Region("Khorezm", "Xorazm"),
];

class _SignUpForEmployerState extends State<SignUpForEmployer> {
  final key = GlobalKey<FormState>();
  TextEditingController descriptionController = TextEditingController();
  TextEditingController telegramController = TextEditingController();
  TextEditingController contactController = TextEditingController();
  DateTime? birthDate;

  FocusNode nameNode = FocusNode();
  FocusNode contactNode = FocusNode();
  FocusNode passwordNode = FocusNode();

  List<String> languages = ["Uzbek", "Russian", "English"];

  Region? dropdownValue;
  String? language;

  bool isLoading = false;

  String? token;

  @override
  void dispose() {
    super.dispose();
    descriptionController.dispose();
    passwordNode.dispose();
  }

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration.zero, () async {
      try {
        await Provider.of<SharedPreferencesProvider>(context, listen: false)
            .fetchData();
      } finally {
        setState(() {
          isLoading = false;
        });
      }
    }).then((value) => {
          token = Provider.of<SharedPreferencesProvider>(context, listen: false)
              .token
        });
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      onPopInvoked: (_) => false,
      child: Scaffold(
        body: SizedBox(
          width: 1200,
          height: 800,
          child: Column(
            children: [
              Expanded(
                  child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    IconButton(
                      style: const ButtonStyle(
                          overlayColor:
                              MaterialStatePropertyAll(Colors.transparent)),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: Icon(
                        Icons.arrow_back_ios,
                        color: Colors.deepPurple.shade300,
                      ),
                    ),
                  ],
                ),
              )),
              Expanded(
                flex: 11,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Form(
                        key: key,
                        child: SizedBox(
                          width: 400,
                          child: Column(
                            children: [
                              TextFormField(
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return "Please Fill Forms";
                                  }
                                  return null;
                                },
                                controller: descriptionController,
                                decoration: InputDecoration(
                                  floatingLabelBehavior:
                                      FloatingLabelBehavior.never,
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Colors.deepPurple.shade200),
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(20))),
                                  border: const OutlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.white),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(20))),
                                  label: Text(
                                    'Summary',
                                    style: TextStyle(
                                        color: Colors.deepPurple.shade200),
                                  ),
                                ),
                                onFieldSubmitted: (value) {
                                  FocusScope.of(context).requestFocus(nameNode);
                                },
                              ),
                              const SizedBox(height: 10),
                              TextFormField(
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return "Please Fill Forms";
                                  }
                                  return null;
                                },
                                focusNode: nameNode,
                                controller: telegramController,
                                decoration: InputDecoration(
                                  floatingLabelBehavior:
                                      FloatingLabelBehavior.never,
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Colors.deepPurple.shade200),
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(20))),
                                  border: const OutlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.white),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(20))),
                                  label: Text(
                                    'Telegram Account',
                                    style: TextStyle(
                                        color: Colors.deepPurple.shade200),
                                  ),
                                ),
                                onFieldSubmitted: (value) {
                                  FocusScope.of(context)
                                      .requestFocus(contactNode);
                                },
                              ),
                              const SizedBox(height: 10),
                              TextFormField(
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return "Please Fill Forms";
                                  }
                                  return null;
                                },
                                focusNode: contactNode,
                                controller: contactController,
                                decoration: InputDecoration(
                                  floatingLabelBehavior:
                                      FloatingLabelBehavior.never,
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Colors.deepPurple.shade200),
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(20))),
                                  border: const OutlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.white),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(20))),
                                  label: Text(
                                    'Phone Number',
                                    style: TextStyle(
                                        color: Colors.deepPurple.shade200),
                                  ),
                                ),
                                onFieldSubmitted: (value) {
                                  FocusScope.of(context)
                                      .requestFocus(passwordNode);
                                },
                              ),
                              const SizedBox(height: 20),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 20),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    birthDate == null
                                        ? Text("Birthdate",
                                            style: TextStyle(
                                                color:
                                                    Colors.deepPurple.shade400))
                                        : Text(
                                            DateFormat.yMMMEd()
                                                .format(birthDate!)
                                                .toString(),
                                            style: TextStyle(
                                                color: Colors
                                                    .deepPurple.shade400)),
                                    InkWell(
                                      onTap: () async {
                                        DateTime? temp = await showDatePicker(
                                            context: context,
                                            initialDate: DateTime(2023, 12),
                                            firstDate: DateTime(1900),
                                            lastDate: DateTime(2030));
                                        setState(() {
                                          birthDate = temp;
                                        });
                                      },
                                      child: Container(
                                        height: 40,
                                        width: 70,
                                        alignment: Alignment.center,
                                        decoration: BoxDecoration(
                                            color: Colors.deepPurple.shade200,
                                            borderRadius:
                                                BorderRadius.circular(12)),
                                        child: const Text(
                                          "Select",
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              const SizedBox(height: 10),
                              SizedBox(
                                height: 40,
                                child: DropdownButton<Region>(
                                  focusColor: Colors.deepPurple.shade100,
                                  borderRadius: BorderRadius.circular(10),
                                  underline: const SizedBox(
                                    height: 0,
                                  ),
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 20),
                                  isExpanded: true,
                                  icon: Icon(
                                    Icons.more_horiz,
                                    color: Colors.deepPurple.shade300,
                                  ),
                                  value: dropdownValue,
                                  hint: Text(
                                    "Region",
                                    style: TextStyle(
                                        color: Colors.deepPurple.shade400),
                                  ),
                                  onChanged: (Region? value) {
                                    setState(() {
                                      dropdownValue = value!;
                                    });
                                  },
                                  items: list.map<DropdownMenuItem<Region>>(
                                      (Region value) {
                                    return DropdownMenuItem<Region>(
                                        value: value,
                                        child: Text(value.name,
                                            style: TextStyle(
                                                color: Colors
                                                    .deepPurple.shade400)));
                                  }).toList(),
                                ),
                              ),
                              const SizedBox(height: 10),
                              SizedBox(
                                height: 40,
                                child: DropdownButton<String>(
                                  focusColor: Colors.deepPurple.shade200,
                                  borderRadius: BorderRadius.circular(10),
                                  underline: const SizedBox(
                                    height: 0,
                                  ),
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 20),
                                  isExpanded: true,
                                  icon: Icon(
                                    Icons.more_horiz,
                                    color: Colors.deepPurple.shade300,
                                  ),
                                  value: language,
                                  hint: Text(
                                    "Language",
                                    style: TextStyle(
                                        color: Colors.deepPurple.shade400),
                                  ),
                                  onChanged: (String? value) {
                                    setState(() {
                                      language = value!;
                                    });
                                  },
                                  items: languages
                                      .map<DropdownMenuItem<String>>(
                                          (String value) {
                                    return DropdownMenuItem<String>(
                                        value: value,
                                        child: Text(value,
                                            style: TextStyle(
                                                color: Colors
                                                    .deepPurple.shade400)));
                                  }).toList(),
                                ),
                              ),
                              const SizedBox(height: 20),
                              InkWell(
                                onTap: isLoading
                                    ? null
                                    : () async {
                                        if (!key.currentState!.validate()) {
                                          return;
                                        }
                                        if (birthDate == null) {
                                          showSnackBar(
                                              context, "Select your birthdate");
                                          return;
                                        }
                                        if (language == null) {
                                          showSnackBar(
                                              context, "Select your language");
                                          return;
                                        }
                                        if (dropdownValue == null) {
                                          showSnackBar(
                                              context, "Select your region");
                                          return;
                                        }
                                        DateFormat dateFormat =
                                            DateFormat("yyyy-MM-dd");
                                        String birthDateOne = dateFormat
                                            .format(birthDate!)
                                            .toString();

                                        Map<String, dynamic> data = {
                                          "description":
                                              descriptionController.text,
                                          "birthdate": birthDateOne,
                                          "phone_number":
                                              contactController.text,
                                          "telegram": telegramController.text,
                                          "region": dropdownValue!.value,
                                          "native_language": language,
                                          "status": "active"
                                        };
                                        if (token == null) {
                                          return;
                                        }
                                        setState(() {
                                          isLoading = true;
                                        });
                                        await Provider.of<SignUpProvider>(
                                                context,
                                                listen: false)
                                            .addWorkerDetails(data, token)
                                            .then((value) async {
                                          if (Provider.of<SignUpProvider>(
                                                  context,
                                                  listen: false)
                                              .isError!) {
                                            setState(() {
                                              isLoading = false;
                                            });
                                            showSnackBar(context,
                                                "Something went wrong");
                                          } else {
                                            setState(() {
                                              isLoading = false;
                                            });
                                            Navigator.of(context)
                                                .pushNamed("/");
                                            final pref = await SharedPreferences
                                                .getInstance();
                                            pref.setBool("auth", true);
                                            pref.setString("userType",
                                                UserType.employee.name);
                                          }
                                        });
                                      },
                                child: Container(
                                  height: 50,
                                  width: 200,
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                      color: Colors.deepPurple.shade300,
                                      borderRadius: BorderRadius.circular(15)),
                                  child: isLoading
                                      ? const CircularProgressIndicator()
                                      : const Text(
                                          "Sign Up",
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 24),
                                        ),
                                ),
                              )
                            ],
                          ),
                        ))
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

void showSnackBar(BuildContext context, String text,
    [Color? color = Colors.red]) {
  SnackBar snackBar = SnackBar(
    content: Text(text),
    backgroundColor: color,
  );
  ScaffoldMessenger.of(context).showSnackBar(snackBar);
}
