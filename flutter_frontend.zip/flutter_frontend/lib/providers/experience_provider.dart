import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:term_project/providers/profile_provider.dart';
import 'package:term_project/static_const.dart';
import 'package:http/http.dart' as http;

class ExperienceProvider extends ChangeNotifier {
  List<dynamic>? _data;
  List<dynamic>? get data => _data;

  bool? _isError;
  bool? get isError => _isError;

  Future getData(String token) async {
    _isError = false;
    _data = [];
    final url = Uri.parse("$staticUrl/api/worker/experience");
    final response = await http.get(url, headers: getHeaders(token));
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
    _data = json.decode(response.body);
  }

  Future addData(String token, Map<String, dynamic> data) async {
    _isError = false;
    final url = Uri.parse("$staticUrl/api/worker/experience");
    final response =
        await http.post(url, headers: getHeaders(token), body: data);
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
  }

  Future deleteData(String token, int id) async {
    _isError = false;
    final url = Uri.parse("$staticUrl/api/worker/experience/$id");
    final response = await http.delete(url, headers: getHeaders(token));
    if (response.statusCode >= 400) {
      _isError = true;
      return;
    }
  }
}
