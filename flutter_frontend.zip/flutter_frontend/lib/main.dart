import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:term_project/providers/experience_provider.dart';
import 'package:term_project/providers/feedback_provider.dart';
import 'package:term_project/providers/interviews_provider.dart';
import 'package:term_project/providers/language_provider.dart';
import 'package:term_project/providers/notifications_provider.dart';
import 'package:term_project/providers/portfolio_provider.dart';
import 'package:term_project/providers/applicants_provider.dart';
import 'package:term_project/providers/company_provider.dart';
import 'package:term_project/providers/jobs_provider.dart';
import 'package:term_project/providers/posted_job_provider.dart';
import 'package:term_project/providers/profile_provider.dart';
import 'package:term_project/providers/shared_pref_profider.dart';
import 'package:term_project/providers/sign_up_provider.dart';
import 'package:term_project/screens/add_new_experience.dart';
import 'package:term_project/screens/add_new_language.dart';
import 'package:term_project/screens/add_new_portfolio.dart';
import 'package:term_project/screens/add_some_details_for_worker.dart';
import 'package:term_project/screens/create_job.dart';
import 'package:term_project/screens/edit_worker_page.dart';
import 'package:term_project/screens/filling_extra_details_for_employee.dart';
import 'package:term_project/screens/home_page.dart';
import 'package:term_project/screens/interviews_screen.dart';
import 'package:term_project/screens/jobs_full_details.dart';
import 'package:term_project/screens/sign_up_page.dart';
import 'package:term_project/screens/signup_for_employee.dart';
import 'package:term_project/screens/view_all_experience.dart';
import 'package:term_project/screens/view_all_portfolio.dart';
import 'package:window_manager/window_manager.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await windowManager.ensureInitialized();

  WindowOptions windowOptions = const WindowOptions(
      fullScreen: false,
      size: Size(1200, 800),
      maximumSize: Size(1200, 800),
      minimumSize: Size(1200, 800),
      center: true,
      backgroundColor: Colors.deepPurple,
      titleBarStyle: TitleBarStyle.normal,
      title: "We are bitches");
  windowManager.waitUntilReadyToShow(windowOptions, () async {
    await windowManager.show();
    await windowManager.focus();
  });
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => JobsProvider()),
        ChangeNotifierProvider(create: (_) => ProfileProvider()),
        ChangeNotifierProvider(create: (_) => SharedPreferencesProvider()),
        ChangeNotifierProvider(create: (_) => ApplicantsProvider()),
        ChangeNotifierProvider(create: (_) => PostedJobsProvider()),
        ChangeNotifierProvider(create: (_) => SignUpProvider()),
        ChangeNotifierProvider(create: (_) => CompanyProvider()),
        ChangeNotifierProvider(create: (_) => PortFolioProvider()),
        ChangeNotifierProvider(create: (_) => LanguageProvider()),
        ChangeNotifierProvider(create: (context) => ExperienceProvider()),
        ChangeNotifierProvider(create: (context) => NotificationProvider()),
        ChangeNotifierProvider(create: (context) => FeedbackProvider()),
        ChangeNotifierProvider(create: (context) => InterviewProvider()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Flutter Demo',
        theme: ThemeData(
            colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
            useMaterial3: true,
            fontFamily: 'Montserrat'),
        home: const MyHomePage(),
        routes: {
          SignUpForEmployer.routeName: (_) => const SignUpForEmployer(),
          SignUpPage.routeName: (_) => const SignUpPage(),
          FillingExtraDetailsForExmployee.routeName: (context) =>
              const FillingExtraDetailsForExmployee(),
          CreateJob.routeName: (context) => const CreateJob(),
          JobFullDetailsScreen.routeName: (c) => const JobFullDetailsScreen(),
          EditWorkerPage.routeName: (context) => const EditWorkerPage(),
          AddSomeDetailesForWorker.routeName: (context) =>
              const AddSomeDetailesForWorker(),
          AddNewPortfolio.routeName: (context) => const AddNewPortfolio(),
          ViewAllPortfolioScreen.routeName: (context) =>
              const ViewAllPortfolioScreen(),
          AddNewLanguage.routeName: (context) => const AddNewLanguage(),
          AddNewExperience.routeName: (context) => const AddNewExperience(),
          ViewAllExperience.routeName: (context) => const ViewAllExperience(),
          InterviewsScreen.routeName: (context) => const InterviewsScreen()
        },
      ),
    );
  }
}

enum PageName {
  home,
  appliedJobs,
  profile,
  applicants,
  postedJobs,
  notifications,
  chat
}

enum UserType { employee, employer }

class Pages {
  Pages({required this.name}) {
    if (name == "profile") {
      _page = PageName.profile;
    } else if (name == "appliedJobs") {
      _page = PageName.appliedJobs;
    } else if (name == "applicants") {
      _page = PageName.applicants;
    } else if (name == "postedJobs") {
      _page = PageName.postedJobs;
    } else if (name == "notifications") {
      _page = PageName.notifications;
    } else if (name == "chat") {
      _page = PageName.chat;
    } else {
      _page = PageName.home;
    }
  }
  PageName? _page;
  String name;

  PageName? get page => _page;
}
