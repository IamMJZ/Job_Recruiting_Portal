import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:term_project/providers/jobs_provider.dart';
import 'package:term_project/providers/posted_job_provider.dart';
import 'package:term_project/providers/shared_pref_profider.dart';
import 'package:term_project/screens/create_job.dart';
import 'package:term_project/screens/jobs_full_details.dart';

class RightPostedJobsWidget extends StatefulWidget {
  const RightPostedJobsWidget({super.key, required this.title});
  final String title;

  @override
  State<RightPostedJobsWidget> createState() => _RightPostedJobsWidgetState();
}

class _RightPostedJobsWidgetState extends State<RightPostedJobsWidget> {
  List<Job>? postedJobs;
  String? token;
  bool isInit = true;
  bool? isLoading = false;

  @override
  void initState() {
    super.initState();
    token =
        Provider.of<SharedPreferencesProvider>(context, listen: false).token;

    postedJobs =
        Provider.of<PostedJobsProvider>(context, listen: false).postedJobList;
  }

  @override
  void didChangeDependencies() async {
    super.didChangeDependencies();
    if (isInit) {
      setState(() {
        isLoading = true;
      });
      await Provider.of<PostedJobsProvider>(context, listen: false)
          .fetchData(token!)
          .then((value) {
        postedJobs = Provider.of<PostedJobsProvider>(context, listen: false)
            .postedJobList;
      });
      isInit = false;
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: Container(
            width: 960,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            alignment: Alignment.center,
            color: Colors.deepPurple.shade100,
            child: Text(
              widget.title,
              style: const TextStyle(color: Colors.white, fontSize: 24),
            ),
          ),
        ),
        Expanded(
          flex: 11,
          child: isLoading!
              ? const Center(
                  child: CircularProgressIndicator(),
                )
              : ListView.builder(
                  itemCount: postedJobs!.length,
                  itemBuilder: (context, index) {
                    return InkWell(
                      onTap: () {
                        Navigator.of(context).pushNamed(
                            JobFullDetailsScreen.routeName,
                            arguments: {"job": postedJobs![index]});
                      },
                      child: Container(
                        height: 120,
                        margin: const EdgeInsets.symmetric(
                          vertical: 10,
                          horizontal: 20,
                        ),
                        padding: const EdgeInsets.symmetric(
                          vertical: 10,
                          horizontal: 20,
                        ),
                        decoration: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.shade300,
                              offset: const Offset(0, 5),
                              blurRadius: 10,
                            )
                          ],
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              flex: 4,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    postedJobs![index].isActive
                                        ? postedJobs![index].title!
                                        : "${postedJobs![index].title!} - is not Active",
                                    maxLines: 1,
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20,
                                        color: postedJobs![index].isActive
                                            ? Colors.black
                                            : Colors.grey),
                                  ),
                                  const SizedBox(height: 10),
                                  SingleChildScrollView(
                                    scrollDirection: Axis.horizontal,
                                    child: Row(
                                      children: [
                                        Text(postedJobs![index].companyName!),
                                        const SizedBox(width: 5),
                                        const Icon(
                                          Icons.verified_outlined,
                                          size: 15,
                                        )
                                      ],
                                    ),
                                  ),
                                  Text("${postedJobs![index].salary} \$"),
                                ],
                              ),
                            ),
                            Expanded(
                              flex: 1,
                              child: InkWell(
                                onTap: () async {
                                  Navigator.of(context).pushNamed(
                                      CreateJob.routeName,
                                      arguments: postedJobs![index]);
                                },
                                child: Container(
                                  height: 60,
                                  margin:
                                      const EdgeInsets.symmetric(vertical: 20),
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(20),
                                      color: Colors.green.shade50),
                                  child: const Text(
                                    "Edit",
                                    style: TextStyle(fontSize: 16),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}
