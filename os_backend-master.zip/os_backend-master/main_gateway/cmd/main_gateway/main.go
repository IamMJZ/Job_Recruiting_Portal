package main

import "github.com/aslon1213/os_backend/internal/pkg/app"

func main() {
	a := app.New()
	a.StartApplication()
}
